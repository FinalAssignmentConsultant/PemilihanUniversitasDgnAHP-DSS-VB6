﻿Public Class DisplayMatrix

    Public Sub ShowArray(ByRef array(,) As Single, ByVal length As Integer)
        Dim i As Integer
        Dim j As Integer

        txtMatrix.Text = ""
        For i = 0 To length
            For j = 0 To length
                txtMatrix.Text = txtMatrix.Text & array(i, j) & Space(10)
            Next
            txtMatrix.Text = txtMatrix.Text & vbCrLf
        Next
    End Sub
End Class