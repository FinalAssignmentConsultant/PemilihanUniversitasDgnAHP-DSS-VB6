﻿Module Module1
    Public Sub identity(ByRef array(,) As Single, ByVal length As Integer)
        Dim i As Integer
        Dim j As Integer

        For i = 0 To length - 1
            For j = 0 To length - 1
                If i = j Then array(i, j) = 1
            Next
        Next
    End Sub

    Public Function pair(ByRef Matrix(,) As Single, ByRef trckAthdB As Windows.Forms.TrackBar, ByVal i As Integer, ByVal j As Integer)
        Dim nilai As Integer
        Dim posisi As Integer
        If trckAthdB.Value <= 8 Then
            posisi = 0
            nilai = 10 - trckAthdB.Value
        ElseIf trckAthdB.Value = 9 Then
            posisi = 1
            nilai = 1
        ElseIf trckAthdB.Value >= 10 Then
            posisi = 2
            nilai = trckAthdB.Value - 8
        End If

        If posisi = 0 Then
            Matrix(i, j) = nilai
            Matrix(j, i) = 1 / nilai
        ElseIf posisi = 1 Then
            Matrix(i, j) = 1
            Matrix(j, i) = 1
        ElseIf posisi = 2 Then
            Matrix(j, i) = nilai
            Matrix(i, j) = 1 / nilai
        End If
        Return nilai
    End Function
End Module

