﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormUtama
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.txtAlternatif5 = New System.Windows.Forms.TextBox
        Me.txtAlternatif4 = New System.Windows.Forms.TextBox
        Me.txtAlternatif3 = New System.Windows.Forms.TextBox
        Me.txtAlternatif2 = New System.Windows.Forms.TextBox
        Me.txtAlternatif1 = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.txtKriteria5 = New System.Windows.Forms.TextBox
        Me.txtKriteria4 = New System.Windows.Forms.TextBox
        Me.txtKriteria3 = New System.Windows.Forms.TextBox
        Me.txtKriteria2 = New System.Windows.Forms.TextBox
        Me.txtKriteria1 = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.lblKriteria4Kriteria5 = New System.Windows.Forms.Label
        Me.lblKriteria3Kriteria5 = New System.Windows.Forms.Label
        Me.lblKriteria4 = New System.Windows.Forms.Label
        Me.trckKriteria4Kriteria5 = New System.Windows.Forms.TrackBar
        Me.lblKriteria2Kriteria5 = New System.Windows.Forms.Label
        Me.lblKriteria3Kriteria4 = New System.Windows.Forms.Label
        Me.lblKriteria2Kriteria4 = New System.Windows.Forms.Label
        Me.lblKriteria3 = New System.Windows.Forms.Label
        Me.trckKriteria2Kriteria5 = New System.Windows.Forms.TrackBar
        Me.trckKriteria3Kriteria5 = New System.Windows.Forms.TrackBar
        Me.Label11 = New System.Windows.Forms.Label
        Me.trckKriteria3Kriteria4 = New System.Windows.Forms.TrackBar
        Me.trckKriteria2Kriteria4 = New System.Windows.Forms.TrackBar
        Me.Label12 = New System.Windows.Forms.Label
        Me.trckKriteria2Kriteria3 = New System.Windows.Forms.TrackBar
        Me.lblKriteria1Kriteria5 = New System.Windows.Forms.Label
        Me.trckKriteria1Kriteria5 = New System.Windows.Forms.TrackBar
        Me.lblKriteria1Kriteria4 = New System.Windows.Forms.Label
        Me.trckKriteria1Kriteria4 = New System.Windows.Forms.TrackBar
        Me.Label4 = New System.Windows.Forms.Label
        Me.trckKriteria1Kriteria3 = New System.Windows.Forms.TrackBar
        Me.Label3 = New System.Windows.Forms.Label
        Me.trckKriteria1Kriteria2 = New System.Windows.Forms.TrackBar
        Me.Label1 = New System.Windows.Forms.Label
        Me.TabPage7 = New System.Windows.Forms.TabPage
        Me.tabCtlAlternatif = New System.Windows.Forms.TabControl
        Me.TabPage8 = New System.Windows.Forms.TabPage
        Me.lblKriteria1Alternatif4Alternatif5 = New System.Windows.Forms.Label
        Me.lblKriteria1Alternatif4 = New System.Windows.Forms.Label
        Me.trkKriteria1Alternatif4Alternatif5 = New System.Windows.Forms.TrackBar
        Me.lblKriteria1Alternatif3Alternatif5 = New System.Windows.Forms.Label
        Me.lblKriteria1Alternatif3Alternatif4 = New System.Windows.Forms.Label
        Me.lblKriteria1Alternatif3 = New System.Windows.Forms.Label
        Me.trkKriteria1Alternatif3Alternatif5 = New System.Windows.Forms.TrackBar
        Me.trkKriteria1Alternatif3Alternatif4 = New System.Windows.Forms.TrackBar
        Me.lblKriteria1Alternatif2Alternatif5 = New System.Windows.Forms.Label
        Me.lblKriteria1Alternatif2Alternatif4 = New System.Windows.Forms.Label
        Me.trkKriteria1Alternatif2Alternatif5 = New System.Windows.Forms.TrackBar
        Me.Label45 = New System.Windows.Forms.Label
        Me.trkKriteria1Alternatif2Alternatif4 = New System.Windows.Forms.TrackBar
        Me.Label46 = New System.Windows.Forms.Label
        Me.trkKriteria1Alternatif2Alternatif3 = New System.Windows.Forms.TrackBar
        Me.lblKriteria1Alternatif1Alternatif5 = New System.Windows.Forms.Label
        Me.trkKriteria1Alternatif1Alternatif5 = New System.Windows.Forms.TrackBar
        Me.lblKriteria1Alternatif1Alternatif4 = New System.Windows.Forms.Label
        Me.trkKriteria1Alternatif1Alternatif4 = New System.Windows.Forms.TrackBar
        Me.Label21 = New System.Windows.Forms.Label
        Me.trkKriteria1Alternatif1Alternatif3 = New System.Windows.Forms.TrackBar
        Me.Label19 = New System.Windows.Forms.Label
        Me.trkKriteria1Alternatif1Alternatif2 = New System.Windows.Forms.TrackBar
        Me.Label20 = New System.Windows.Forms.Label
        Me.TabPage9 = New System.Windows.Forms.TabPage
        Me.lblKriteria2Alternatif4Alternatif5 = New System.Windows.Forms.Label
        Me.lblKriteria2Alternatif4 = New System.Windows.Forms.Label
        Me.trkKriteria2Alternatif4Alternatif5 = New System.Windows.Forms.TrackBar
        Me.lblKriteria2Alternatif3Alternatif5 = New System.Windows.Forms.Label
        Me.lblKriteria2Alternatif3Alternatif4 = New System.Windows.Forms.Label
        Me.lblKriteria2Alternatif3 = New System.Windows.Forms.Label
        Me.trkKriteria2Alternatif3Alternatif5 = New System.Windows.Forms.TrackBar
        Me.trkKriteria2Alternatif3Alternatif4 = New System.Windows.Forms.TrackBar
        Me.lblKriteria2Alternatif2Alternatif5 = New System.Windows.Forms.Label
        Me.lblKriteria2Alternatif2Alternatif4 = New System.Windows.Forms.Label
        Me.trkKriteria2Alternatif2Alternatif5 = New System.Windows.Forms.TrackBar
        Me.Label60 = New System.Windows.Forms.Label
        Me.trkKriteria2Alternatif2Alternatif4 = New System.Windows.Forms.TrackBar
        Me.Label61 = New System.Windows.Forms.Label
        Me.trkKriteria2Alternatif2Alternatif3 = New System.Windows.Forms.TrackBar
        Me.lblKriteria2Alternatif1Alternatif5 = New System.Windows.Forms.Label
        Me.trkKriteria2Alternatif1Alternatif5 = New System.Windows.Forms.TrackBar
        Me.lblKriteria2Alternatif1Alternatif4 = New System.Windows.Forms.Label
        Me.trkKriteria2Alternatif1Alternatif4 = New System.Windows.Forms.TrackBar
        Me.Label26 = New System.Windows.Forms.Label
        Me.trkKriteria2Alternatif1Alternatif3 = New System.Windows.Forms.TrackBar
        Me.Label27 = New System.Windows.Forms.Label
        Me.trkKriteria2Alternatif1Alternatif2 = New System.Windows.Forms.TrackBar
        Me.Label28 = New System.Windows.Forms.Label
        Me.TabPage10 = New System.Windows.Forms.TabPage
        Me.lblKriteria3Alternatif4Alternatif5 = New System.Windows.Forms.Label
        Me.lblKriteria3Alternatif4 = New System.Windows.Forms.Label
        Me.trkKriteria3Alternatif4Alternatif5 = New System.Windows.Forms.TrackBar
        Me.lblKriteria3Alternatif3Alternatif5 = New System.Windows.Forms.Label
        Me.lblKriteria3Alternatif3Alternatif4 = New System.Windows.Forms.Label
        Me.lblKriteria3Alternatif3 = New System.Windows.Forms.Label
        Me.trkKriteria3Alternatif3Alternatif5 = New System.Windows.Forms.TrackBar
        Me.trkKriteria3Alternatif3Alternatif4 = New System.Windows.Forms.TrackBar
        Me.lblKriteria3Alternatif2Alternatif5 = New System.Windows.Forms.Label
        Me.lblKriteria3Alternatif2Alternatif4 = New System.Windows.Forms.Label
        Me.trkKriteria3Alternatif2Alternatif5 = New System.Windows.Forms.TrackBar
        Me.Label69 = New System.Windows.Forms.Label
        Me.trkKriteria3Alternatif2Alternatif4 = New System.Windows.Forms.TrackBar
        Me.Label70 = New System.Windows.Forms.Label
        Me.trkKriteria3Alternatif2Alternatif3 = New System.Windows.Forms.TrackBar
        Me.lblKriteria3Alternatif1Alternatif5 = New System.Windows.Forms.Label
        Me.trkKriteria3Alternatif1Alternatif5 = New System.Windows.Forms.TrackBar
        Me.lblKriteria3Alternatif1Alternatif4 = New System.Windows.Forms.Label
        Me.trkKriteria3Alternatif1Alternatif4 = New System.Windows.Forms.TrackBar
        Me.Label31 = New System.Windows.Forms.Label
        Me.trkKriteria3Alternatif1Alternatif3 = New System.Windows.Forms.TrackBar
        Me.Label32 = New System.Windows.Forms.Label
        Me.trkKriteria3Alternatif1Alternatif2 = New System.Windows.Forms.TrackBar
        Me.Label33 = New System.Windows.Forms.Label
        Me.tabKriteria4 = New System.Windows.Forms.TabPage
        Me.lblKriteria4Alternatif4Alternatif5 = New System.Windows.Forms.Label
        Me.lblKriteria4Alternatif4 = New System.Windows.Forms.Label
        Me.trkKriteria4Alternatif4Alternatif5 = New System.Windows.Forms.TrackBar
        Me.lblKriteria4Alternatif3Alternatif5 = New System.Windows.Forms.Label
        Me.lblKriteria4Alternatif3Alternatif4 = New System.Windows.Forms.Label
        Me.lblKriteria4Alternatif3 = New System.Windows.Forms.Label
        Me.trkKriteria4Alternatif3Alternatif5 = New System.Windows.Forms.TrackBar
        Me.trkKriteria4Alternatif3Alternatif4 = New System.Windows.Forms.TrackBar
        Me.lblKriteria4Alternatif2Alternatif5 = New System.Windows.Forms.Label
        Me.lblKriteria4Alternatif2Alternatif4 = New System.Windows.Forms.Label
        Me.trkKriteria4Alternatif2Alternatif5 = New System.Windows.Forms.TrackBar
        Me.Label78 = New System.Windows.Forms.Label
        Me.trkKriteria4Alternatif2Alternatif4 = New System.Windows.Forms.TrackBar
        Me.Label79 = New System.Windows.Forms.Label
        Me.trkKriteria4Alternatif2Alternatif3 = New System.Windows.Forms.TrackBar
        Me.lblKriteria4Alternatif1Alternatif5 = New System.Windows.Forms.Label
        Me.trkKriteria4Alternatif1Alternatif5 = New System.Windows.Forms.TrackBar
        Me.lblKriteria4Alternatif1Alternatif4 = New System.Windows.Forms.Label
        Me.trkKriteria4Alternatif1Alternatif4 = New System.Windows.Forms.TrackBar
        Me.Label36 = New System.Windows.Forms.Label
        Me.trkKriteria4Alternatif1Alternatif3 = New System.Windows.Forms.TrackBar
        Me.Label37 = New System.Windows.Forms.Label
        Me.trkKriteria4Alternatif1Alternatif2 = New System.Windows.Forms.TrackBar
        Me.Label38 = New System.Windows.Forms.Label
        Me.tabKriteria5 = New System.Windows.Forms.TabPage
        Me.lblKriteria5Alternatif4Alternatif5 = New System.Windows.Forms.Label
        Me.lblKriteria5Alternatif4 = New System.Windows.Forms.Label
        Me.trkKriteria5Alternatif4Alternatif5 = New System.Windows.Forms.TrackBar
        Me.lblKriteria5Alternatif3Alternatif5 = New System.Windows.Forms.Label
        Me.lblKriteria5Alternatif3Alternatif4 = New System.Windows.Forms.Label
        Me.lblKriteria5Alternatif3 = New System.Windows.Forms.Label
        Me.trkKriteria5Alternatif3Alternatif5 = New System.Windows.Forms.TrackBar
        Me.trkKriteria5Alternatif3Alternatif4 = New System.Windows.Forms.TrackBar
        Me.lblKriteria5Alternatif2Alternatif5 = New System.Windows.Forms.Label
        Me.lblKriteria5Alternatif2Alternatif4 = New System.Windows.Forms.Label
        Me.trkKriteria5Alternatif2Alternatif5 = New System.Windows.Forms.TrackBar
        Me.Label87 = New System.Windows.Forms.Label
        Me.trkKriteria5Alternatif2Alternatif4 = New System.Windows.Forms.TrackBar
        Me.Label88 = New System.Windows.Forms.Label
        Me.trkKriteria5Alternatif2Alternatif3 = New System.Windows.Forms.TrackBar
        Me.lblKriteria5Alternatif1Alternatif5 = New System.Windows.Forms.Label
        Me.trkKriteria5Alternatif1Alternatif5 = New System.Windows.Forms.TrackBar
        Me.lblKriteria5Alternatif1Alternatif4 = New System.Windows.Forms.Label
        Me.trkKriteria5Alternatif1Alternatif4 = New System.Windows.Forms.TrackBar
        Me.Label41 = New System.Windows.Forms.Label
        Me.trkKriteria5Alternatif1Alternatif3 = New System.Windows.Forms.TrackBar
        Me.Label42 = New System.Windows.Forms.Label
        Me.trkKriteria5Alternatif1Alternatif2 = New System.Windows.Forms.TrackBar
        Me.Label43 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.lblNilai = New System.Windows.Forms.Label
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.Label89 = New System.Windows.Forms.Label
        Me.updnJumlahAlternatif = New System.Windows.Forms.NumericUpDown
        Me.updnJumlahKriteria = New System.Windows.Forms.NumericUpDown
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Label90 = New System.Windows.Forms.Label
        Me.DataSet1 = New PemilihanUniversitasAHP.DataSet
        Me.MenuStrip1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.trckKriteria4Kriteria5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trckKriteria2Kriteria5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trckKriteria3Kriteria5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trckKriteria3Kriteria4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trckKriteria2Kriteria4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trckKriteria2Kriteria3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trckKriteria1Kriteria5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trckKriteria1Kriteria4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trckKriteria1Kriteria3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trckKriteria1Kriteria2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage7.SuspendLayout()
        Me.tabCtlAlternatif.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        CType(Me.trkKriteria1Alternatif4Alternatif5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria1Alternatif3Alternatif5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria1Alternatif3Alternatif4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria1Alternatif2Alternatif5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria1Alternatif2Alternatif4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria1Alternatif2Alternatif3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria1Alternatif1Alternatif5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria1Alternatif1Alternatif4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria1Alternatif1Alternatif3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria1Alternatif1Alternatif2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage9.SuspendLayout()
        CType(Me.trkKriteria2Alternatif4Alternatif5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria2Alternatif3Alternatif5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria2Alternatif3Alternatif4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria2Alternatif2Alternatif5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria2Alternatif2Alternatif4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria2Alternatif2Alternatif3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria2Alternatif1Alternatif5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria2Alternatif1Alternatif4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria2Alternatif1Alternatif3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria2Alternatif1Alternatif2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage10.SuspendLayout()
        CType(Me.trkKriteria3Alternatif4Alternatif5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria3Alternatif3Alternatif5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria3Alternatif3Alternatif4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria3Alternatif2Alternatif5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria3Alternatif2Alternatif4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria3Alternatif2Alternatif3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria3Alternatif1Alternatif5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria3Alternatif1Alternatif4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria3Alternatif1Alternatif3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria3Alternatif1Alternatif2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabKriteria4.SuspendLayout()
        CType(Me.trkKriteria4Alternatif4Alternatif5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria4Alternatif3Alternatif5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria4Alternatif3Alternatif4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria4Alternatif2Alternatif5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria4Alternatif2Alternatif4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria4Alternatif2Alternatif3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria4Alternatif1Alternatif5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria4Alternatif1Alternatif4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria4Alternatif1Alternatif3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria4Alternatif1Alternatif2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabKriteria5.SuspendLayout()
        CType(Me.trkKriteria5Alternatif4Alternatif5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria5Alternatif3Alternatif5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria5Alternatif3Alternatif4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria5Alternatif2Alternatif5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria5Alternatif2Alternatif4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria5Alternatif2Alternatif3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria5Alternatif1Alternatif5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria5Alternatif1Alternatif4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria5Alternatif1Alternatif3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkKriteria5Alternatif1Alternatif2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.updnJumlahAlternatif, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.updnJumlahKriteria, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.DataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(869, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(35, 20)
        Me.FileToolStripMenuItem.Text = "&File"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(91, 22)
        Me.ExitToolStripMenuItem.Text = "E&xit"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(41, 20)
        Me.HelpToolStripMenuItem.Text = "&Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(102, 22)
        Me.AboutToolStripMenuItem.Text = "A&bout"
        '
        'TabControl1
        '
        Me.TabControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage7)
        Me.TabControl1.Location = New System.Drawing.Point(0, 140)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(869, 376)
        Me.TabControl1.TabIndex = 6
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.GroupBox2)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(861, 350)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Konfigurasi Awal"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtAlternatif5)
        Me.GroupBox2.Controls.Add(Me.txtAlternatif4)
        Me.GroupBox2.Controls.Add(Me.txtAlternatif3)
        Me.GroupBox2.Controls.Add(Me.txtAlternatif2)
        Me.GroupBox2.Controls.Add(Me.txtAlternatif1)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.txtKriteria5)
        Me.GroupBox2.Controls.Add(Me.txtKriteria4)
        Me.GroupBox2.Controls.Add(Me.txtKriteria3)
        Me.GroupBox2.Controls.Add(Me.txtKriteria2)
        Me.GroupBox2.Controls.Add(Me.txtKriteria1)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Location = New System.Drawing.Point(8, 28)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(579, 177)
        Me.GroupBox2.TabIndex = 11
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Pengaturan Nama Kriteria dan Alternatif"
        '
        'txtAlternatif5
        '
        Me.txtAlternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.txtAlternatif5.Location = New System.Drawing.Point(375, 136)
        Me.txtAlternatif5.Name = "txtAlternatif5"
        Me.txtAlternatif5.Size = New System.Drawing.Size(186, 20)
        Me.txtAlternatif5.TabIndex = 12
        Me.txtAlternatif5.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif5
        '
        'txtAlternatif4
        '
        Me.txtAlternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.txtAlternatif4.Location = New System.Drawing.Point(375, 110)
        Me.txtAlternatif4.Name = "txtAlternatif4"
        Me.txtAlternatif4.Size = New System.Drawing.Size(186, 20)
        Me.txtAlternatif4.TabIndex = 11
        Me.txtAlternatif4.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif4
        '
        'txtAlternatif3
        '
        Me.txtAlternatif3.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.txtAlternatif3.Location = New System.Drawing.Point(375, 84)
        Me.txtAlternatif3.Name = "txtAlternatif3"
        Me.txtAlternatif3.Size = New System.Drawing.Size(186, 20)
        Me.txtAlternatif3.TabIndex = 10
        Me.txtAlternatif3.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif3
        '
        'txtAlternatif2
        '
        Me.txtAlternatif2.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif2", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.txtAlternatif2.Location = New System.Drawing.Point(375, 58)
        Me.txtAlternatif2.Name = "txtAlternatif2"
        Me.txtAlternatif2.Size = New System.Drawing.Size(186, 20)
        Me.txtAlternatif2.TabIndex = 9
        Me.txtAlternatif2.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif2
        '
        'txtAlternatif1
        '
        Me.txtAlternatif1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif1", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.txtAlternatif1.Location = New System.Drawing.Point(375, 32)
        Me.txtAlternatif1.Name = "txtAlternatif1"
        Me.txtAlternatif1.Size = New System.Drawing.Size(186, 20)
        Me.txtAlternatif1.TabIndex = 8
        Me.txtAlternatif1.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif1
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(321, 35)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(48, 13)
        Me.Label7.TabIndex = 7
        Me.Label7.Text = "Alternatif"
        '
        'txtKriteria5
        '
        Me.txtKriteria5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.txtKriteria5.Location = New System.Drawing.Point(69, 139)
        Me.txtKriteria5.Name = "txtKriteria5"
        Me.txtKriteria5.Size = New System.Drawing.Size(186, 20)
        Me.txtKriteria5.TabIndex = 6
        Me.txtKriteria5.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria5
        '
        'txtKriteria4
        '
        Me.txtKriteria4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.txtKriteria4.Location = New System.Drawing.Point(69, 113)
        Me.txtKriteria4.Name = "txtKriteria4"
        Me.txtKriteria4.Size = New System.Drawing.Size(186, 20)
        Me.txtKriteria4.TabIndex = 5
        Me.txtKriteria4.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria4
        '
        'txtKriteria3
        '
        Me.txtKriteria3.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.txtKriteria3.Location = New System.Drawing.Point(69, 87)
        Me.txtKriteria3.Name = "txtKriteria3"
        Me.txtKriteria3.Size = New System.Drawing.Size(186, 20)
        Me.txtKriteria3.TabIndex = 4
        Me.txtKriteria3.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria3
        '
        'txtKriteria2
        '
        Me.txtKriteria2.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria2", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.txtKriteria2.Location = New System.Drawing.Point(69, 61)
        Me.txtKriteria2.Name = "txtKriteria2"
        Me.txtKriteria2.Size = New System.Drawing.Size(186, 20)
        Me.txtKriteria2.TabIndex = 3
        Me.txtKriteria2.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria2
        '
        'txtKriteria1
        '
        Me.txtKriteria1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria1", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.txtKriteria1.Location = New System.Drawing.Point(69, 35)
        Me.txtKriteria1.Name = "txtKriteria1"
        Me.txtKriteria1.Size = New System.Drawing.Size(186, 20)
        Me.txtKriteria1.TabIndex = 2
        Me.txtKriteria1.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria1
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(24, 38)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(39, 13)
        Me.Label8.TabIndex = 1
        Me.Label8.Text = "Kriteria"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.lblKriteria4Kriteria5)
        Me.TabPage2.Controls.Add(Me.lblKriteria3Kriteria5)
        Me.TabPage2.Controls.Add(Me.lblKriteria4)
        Me.TabPage2.Controls.Add(Me.trckKriteria4Kriteria5)
        Me.TabPage2.Controls.Add(Me.lblKriteria2Kriteria5)
        Me.TabPage2.Controls.Add(Me.lblKriteria3Kriteria4)
        Me.TabPage2.Controls.Add(Me.lblKriteria2Kriteria4)
        Me.TabPage2.Controls.Add(Me.lblKriteria3)
        Me.TabPage2.Controls.Add(Me.trckKriteria2Kriteria5)
        Me.TabPage2.Controls.Add(Me.trckKriteria3Kriteria5)
        Me.TabPage2.Controls.Add(Me.Label11)
        Me.TabPage2.Controls.Add(Me.trckKriteria3Kriteria4)
        Me.TabPage2.Controls.Add(Me.trckKriteria2Kriteria4)
        Me.TabPage2.Controls.Add(Me.Label12)
        Me.TabPage2.Controls.Add(Me.trckKriteria2Kriteria3)
        Me.TabPage2.Controls.Add(Me.lblKriteria1Kriteria5)
        Me.TabPage2.Controls.Add(Me.trckKriteria1Kriteria5)
        Me.TabPage2.Controls.Add(Me.lblKriteria1Kriteria4)
        Me.TabPage2.Controls.Add(Me.trckKriteria1Kriteria4)
        Me.TabPage2.Controls.Add(Me.Label4)
        Me.TabPage2.Controls.Add(Me.trckKriteria1Kriteria3)
        Me.TabPage2.Controls.Add(Me.Label3)
        Me.TabPage2.Controls.Add(Me.trckKriteria1Kriteria2)
        Me.TabPage2.Controls.Add(Me.Label1)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(861, 350)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Penilaian Antar Kriteria"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'lblKriteria4Kriteria5
        '
        Me.lblKriteria4Kriteria5.AutoSize = True
        Me.lblKriteria4Kriteria5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria4Kriteria5.Location = New System.Drawing.Point(723, 244)
        Me.lblKriteria4Kriteria5.Name = "lblKriteria4Kriteria5"
        Me.lblKriteria4Kriteria5.Size = New System.Drawing.Size(107, 13)
        Me.lblKriteria4Kriteria5.TabIndex = 22
        Me.lblKriteria4Kriteria5.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria5
        '
        'lblKriteria3Kriteria5
        '
        Me.lblKriteria3Kriteria5.AutoSize = True
        Me.lblKriteria3Kriteria5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria3Kriteria5.Location = New System.Drawing.Point(309, 295)
        Me.lblKriteria3Kriteria5.Name = "lblKriteria3Kriteria5"
        Me.lblKriteria3Kriteria5.Size = New System.Drawing.Size(107, 13)
        Me.lblKriteria3Kriteria5.TabIndex = 19
        Me.lblKriteria3Kriteria5.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria5
        '
        'lblKriteria4
        '
        Me.lblKriteria4.AutoSize = True
        Me.lblKriteria4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria4.Location = New System.Drawing.Point(491, 244)
        Me.lblKriteria4.Name = "lblKriteria4"
        Me.lblKriteria4.Size = New System.Drawing.Size(33, 13)
        Me.lblKriteria4.TabIndex = 21
        Me.lblKriteria4.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria4
        '
        'trckKriteria4Kriteria5
        '
        Me.trckKriteria4Kriteria5.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria4kriteria5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trckKriteria4Kriteria5.Location = New System.Drawing.Point(530, 244)
        Me.trckKriteria4Kriteria5.Maximum = 17
        Me.trckKriteria4Kriteria5.Minimum = 1
        Me.trckKriteria4Kriteria5.Name = "trckKriteria4Kriteria5"
        Me.trckKriteria4Kriteria5.Size = New System.Drawing.Size(187, 42)
        Me.trckKriteria4Kriteria5.TabIndex = 20
        Me.trckKriteria4Kriteria5.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria4kriteria5
        '
        'lblKriteria2Kriteria5
        '
        Me.lblKriteria2Kriteria5.AutoSize = True
        Me.lblKriteria2Kriteria5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria2Kriteria5.Location = New System.Drawing.Point(726, 116)
        Me.lblKriteria2Kriteria5.Name = "lblKriteria2Kriteria5"
        Me.lblKriteria2Kriteria5.Size = New System.Drawing.Size(107, 13)
        Me.lblKriteria2Kriteria5.TabIndex = 14
        Me.lblKriteria2Kriteria5.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria5
        '
        'lblKriteria3Kriteria4
        '
        Me.lblKriteria3Kriteria4.AutoSize = True
        Me.lblKriteria3Kriteria4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria3Kriteria4.Location = New System.Drawing.Point(309, 244)
        Me.lblKriteria3Kriteria4.Name = "lblKriteria3Kriteria4"
        Me.lblKriteria3Kriteria4.Size = New System.Drawing.Size(33, 13)
        Me.lblKriteria3Kriteria4.TabIndex = 18
        Me.lblKriteria3Kriteria4.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria4
        '
        'lblKriteria2Kriteria4
        '
        Me.lblKriteria2Kriteria4.AutoSize = True
        Me.lblKriteria2Kriteria4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria2Kriteria4.Location = New System.Drawing.Point(723, 65)
        Me.lblKriteria2Kriteria4.Name = "lblKriteria2Kriteria4"
        Me.lblKriteria2Kriteria4.Size = New System.Drawing.Size(33, 13)
        Me.lblKriteria2Kriteria4.TabIndex = 23
        Me.lblKriteria2Kriteria4.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria4
        '
        'lblKriteria3
        '
        Me.lblKriteria3.AutoSize = True
        Me.lblKriteria3.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria3.Location = New System.Drawing.Point(10, 244)
        Me.lblKriteria3.Name = "lblKriteria3"
        Me.lblKriteria3.Size = New System.Drawing.Size(100, 13)
        Me.lblKriteria3.TabIndex = 17
        Me.lblKriteria3.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria3
        '
        'trckKriteria2Kriteria5
        '
        Me.trckKriteria2Kriteria5.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria2kriteria5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trckKriteria2Kriteria5.Location = New System.Drawing.Point(530, 116)
        Me.trckKriteria2Kriteria5.Maximum = 17
        Me.trckKriteria2Kriteria5.Minimum = 1
        Me.trckKriteria2Kriteria5.Name = "trckKriteria2Kriteria5"
        Me.trckKriteria2Kriteria5.Size = New System.Drawing.Size(187, 42)
        Me.trckKriteria2Kriteria5.TabIndex = 22
        Me.trckKriteria2Kriteria5.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria2kriteria5
        '
        'trckKriteria3Kriteria5
        '
        Me.trckKriteria3Kriteria5.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria3kriteria5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trckKriteria3Kriteria5.Location = New System.Drawing.Point(116, 295)
        Me.trckKriteria3Kriteria5.Maximum = 17
        Me.trckKriteria3Kriteria5.Minimum = 1
        Me.trckKriteria3Kriteria5.Name = "trckKriteria3Kriteria5"
        Me.trckKriteria3Kriteria5.Size = New System.Drawing.Size(187, 42)
        Me.trckKriteria3Kriteria5.TabIndex = 16
        Me.trckKriteria3Kriteria5.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria3kriteria5
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label11.Location = New System.Drawing.Point(723, 14)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(100, 13)
        Me.Label11.TabIndex = 21
        Me.Label11.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria3
        '
        'trckKriteria3Kriteria4
        '
        Me.trckKriteria3Kriteria4.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria3kriteria4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trckKriteria3Kriteria4.Location = New System.Drawing.Point(116, 244)
        Me.trckKriteria3Kriteria4.Maximum = 17
        Me.trckKriteria3Kriteria4.Minimum = 1
        Me.trckKriteria3Kriteria4.Name = "trckKriteria3Kriteria4"
        Me.trckKriteria3Kriteria4.Size = New System.Drawing.Size(187, 42)
        Me.trckKriteria3Kriteria4.TabIndex = 14
        Me.trckKriteria3Kriteria4.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria3kriteria4
        '
        'trckKriteria2Kriteria4
        '
        Me.trckKriteria2Kriteria4.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria2kriteria4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trckKriteria2Kriteria4.Location = New System.Drawing.Point(530, 65)
        Me.trckKriteria2Kriteria4.Maximum = 17
        Me.trckKriteria2Kriteria4.Minimum = 1
        Me.trckKriteria2Kriteria4.Name = "trckKriteria2Kriteria4"
        Me.trckKriteria2Kriteria4.Size = New System.Drawing.Size(187, 42)
        Me.trckKriteria2Kriteria4.TabIndex = 20
        Me.trckKriteria2Kriteria4.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria2kriteria4
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria2", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label12.Location = New System.Drawing.Point(450, 14)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(74, 13)
        Me.Label12.TabIndex = 19
        Me.Label12.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria2
        '
        'trckKriteria2Kriteria3
        '
        Me.trckKriteria2Kriteria3.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria2kriteria3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trckKriteria2Kriteria3.Location = New System.Drawing.Point(530, 14)
        Me.trckKriteria2Kriteria3.Maximum = 17
        Me.trckKriteria2Kriteria3.Minimum = 1
        Me.trckKriteria2Kriteria3.Name = "trckKriteria2Kriteria3"
        Me.trckKriteria2Kriteria3.Size = New System.Drawing.Size(187, 42)
        Me.trckKriteria2Kriteria3.TabIndex = 18
        Me.trckKriteria2Kriteria3.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria2kriteria3
        '
        'lblKriteria1Kriteria5
        '
        Me.lblKriteria1Kriteria5.AutoSize = True
        Me.lblKriteria1Kriteria5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria1Kriteria5.Location = New System.Drawing.Point(320, 167)
        Me.lblKriteria1Kriteria5.Name = "lblKriteria1Kriteria5"
        Me.lblKriteria1Kriteria5.Size = New System.Drawing.Size(107, 13)
        Me.lblKriteria1Kriteria5.TabIndex = 17
        Me.lblKriteria1Kriteria5.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria5
        '
        'trckKriteria1Kriteria5
        '
        Me.trckKriteria1Kriteria5.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria1kriteria5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trckKriteria1Kriteria5.Location = New System.Drawing.Point(116, 167)
        Me.trckKriteria1Kriteria5.Maximum = 17
        Me.trckKriteria1Kriteria5.Minimum = 1
        Me.trckKriteria1Kriteria5.Name = "trckKriteria1Kriteria5"
        Me.trckKriteria1Kriteria5.Size = New System.Drawing.Size(187, 42)
        Me.trckKriteria1Kriteria5.TabIndex = 16
        Me.trckKriteria1Kriteria5.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria1kriteria5
        '
        'lblKriteria1Kriteria4
        '
        Me.lblKriteria1Kriteria4.AutoSize = True
        Me.lblKriteria1Kriteria4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria1Kriteria4.Location = New System.Drawing.Point(320, 116)
        Me.lblKriteria1Kriteria4.Name = "lblKriteria1Kriteria4"
        Me.lblKriteria1Kriteria4.Size = New System.Drawing.Size(33, 13)
        Me.lblKriteria1Kriteria4.TabIndex = 15
        Me.lblKriteria1Kriteria4.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria4
        '
        'trckKriteria1Kriteria4
        '
        Me.trckKriteria1Kriteria4.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria1kriteria4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trckKriteria1Kriteria4.Location = New System.Drawing.Point(116, 116)
        Me.trckKriteria1Kriteria4.Maximum = 17
        Me.trckKriteria1Kriteria4.Minimum = 1
        Me.trckKriteria1Kriteria4.Name = "trckKriteria1Kriteria4"
        Me.trckKriteria1Kriteria4.Size = New System.Drawing.Size(187, 42)
        Me.trckKriteria1Kriteria4.TabIndex = 14
        Me.trckKriteria1Kriteria4.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria1kriteria4
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label4.Location = New System.Drawing.Point(320, 65)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(100, 13)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria3
        '
        'trckKriteria1Kriteria3
        '
        Me.trckKriteria1Kriteria3.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria1kriteria3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trckKriteria1Kriteria3.Location = New System.Drawing.Point(116, 65)
        Me.trckKriteria1Kriteria3.Maximum = 17
        Me.trckKriteria1Kriteria3.Minimum = 1
        Me.trckKriteria1Kriteria3.Name = "trckKriteria1Kriteria3"
        Me.trckKriteria1Kriteria3.Size = New System.Drawing.Size(187, 42)
        Me.trckKriteria1Kriteria3.TabIndex = 12
        Me.trckKriteria1Kriteria3.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria1kriteria3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria2", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label3.Location = New System.Drawing.Point(320, 14)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(74, 13)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria2
        '
        'trckKriteria1Kriteria2
        '
        Me.trckKriteria1Kriteria2.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria1kriteria2", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trckKriteria1Kriteria2.Location = New System.Drawing.Point(116, 14)
        Me.trckKriteria1Kriteria2.Maximum = 17
        Me.trckKriteria1Kriteria2.Minimum = 1
        Me.trckKriteria1Kriteria2.Name = "trckKriteria1Kriteria2"
        Me.trckKriteria1Kriteria2.Size = New System.Drawing.Size(187, 42)
        Me.trckKriteria1Kriteria2.TabIndex = 10
        Me.trckKriteria1Kriteria2.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria1kriteria2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria1", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label1.Location = New System.Drawing.Point(10, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(53, 13)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria1
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.tabCtlAlternatif)
        Me.TabPage7.Location = New System.Drawing.Point(4, 22)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(861, 350)
        Me.TabPage7.TabIndex = 2
        Me.TabPage7.Text = "Penilaian Alternatif pada Kriteria"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'tabCtlAlternatif
        '
        Me.tabCtlAlternatif.Controls.Add(Me.TabPage8)
        Me.tabCtlAlternatif.Controls.Add(Me.TabPage9)
        Me.tabCtlAlternatif.Controls.Add(Me.TabPage10)
        Me.tabCtlAlternatif.Controls.Add(Me.tabKriteria4)
        Me.tabCtlAlternatif.Controls.Add(Me.tabKriteria5)
        Me.tabCtlAlternatif.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tabCtlAlternatif.Location = New System.Drawing.Point(3, 3)
        Me.tabCtlAlternatif.Name = "tabCtlAlternatif"
        Me.tabCtlAlternatif.SelectedIndex = 0
        Me.tabCtlAlternatif.Size = New System.Drawing.Size(855, 344)
        Me.tabCtlAlternatif.TabIndex = 0
        '
        'TabPage8
        '
        Me.TabPage8.Controls.Add(Me.lblKriteria1Alternatif4Alternatif5)
        Me.TabPage8.Controls.Add(Me.lblKriteria1Alternatif4)
        Me.TabPage8.Controls.Add(Me.trkKriteria1Alternatif4Alternatif5)
        Me.TabPage8.Controls.Add(Me.lblKriteria1Alternatif3Alternatif5)
        Me.TabPage8.Controls.Add(Me.lblKriteria1Alternatif3Alternatif4)
        Me.TabPage8.Controls.Add(Me.lblKriteria1Alternatif3)
        Me.TabPage8.Controls.Add(Me.trkKriteria1Alternatif3Alternatif5)
        Me.TabPage8.Controls.Add(Me.trkKriteria1Alternatif3Alternatif4)
        Me.TabPage8.Controls.Add(Me.lblKriteria1Alternatif2Alternatif5)
        Me.TabPage8.Controls.Add(Me.lblKriteria1Alternatif2Alternatif4)
        Me.TabPage8.Controls.Add(Me.trkKriteria1Alternatif2Alternatif5)
        Me.TabPage8.Controls.Add(Me.Label45)
        Me.TabPage8.Controls.Add(Me.trkKriteria1Alternatif2Alternatif4)
        Me.TabPage8.Controls.Add(Me.Label46)
        Me.TabPage8.Controls.Add(Me.trkKriteria1Alternatif2Alternatif3)
        Me.TabPage8.Controls.Add(Me.lblKriteria1Alternatif1Alternatif5)
        Me.TabPage8.Controls.Add(Me.trkKriteria1Alternatif1Alternatif5)
        Me.TabPage8.Controls.Add(Me.lblKriteria1Alternatif1Alternatif4)
        Me.TabPage8.Controls.Add(Me.trkKriteria1Alternatif1Alternatif4)
        Me.TabPage8.Controls.Add(Me.Label21)
        Me.TabPage8.Controls.Add(Me.trkKriteria1Alternatif1Alternatif3)
        Me.TabPage8.Controls.Add(Me.Label19)
        Me.TabPage8.Controls.Add(Me.trkKriteria1Alternatif1Alternatif2)
        Me.TabPage8.Controls.Add(Me.Label20)
        Me.TabPage8.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria1", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.TabPage8.Location = New System.Drawing.Point(4, 22)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage8.Size = New System.Drawing.Size(847, 318)
        Me.TabPage8.TabIndex = 0
        Me.TabPage8.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria1
        Me.TabPage8.UseVisualStyleBackColor = True
        '
        'lblKriteria1Alternatif4Alternatif5
        '
        Me.lblKriteria1Alternatif4Alternatif5.AutoSize = True
        Me.lblKriteria1Alternatif4Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria1Alternatif4Alternatif5.Location = New System.Drawing.Point(597, 249)
        Me.lblKriteria1Alternatif4Alternatif5.Name = "lblKriteria1Alternatif4Alternatif5"
        Me.lblKriteria1Alternatif4Alternatif5.Size = New System.Drawing.Size(21, 13)
        Me.lblKriteria1Alternatif4Alternatif5.TabIndex = 29
        Me.lblKriteria1Alternatif4Alternatif5.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif5
        '
        'lblKriteria1Alternatif4
        '
        Me.lblKriteria1Alternatif4.AutoSize = True
        Me.lblKriteria1Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria1Alternatif4.Location = New System.Drawing.Point(374, 249)
        Me.lblKriteria1Alternatif4.Name = "lblKriteria1Alternatif4"
        Me.lblKriteria1Alternatif4.Size = New System.Drawing.Size(24, 13)
        Me.lblKriteria1Alternatif4.TabIndex = 28
        Me.lblKriteria1Alternatif4.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif4
        '
        'trkKriteria1Alternatif4Alternatif5
        '
        Me.trkKriteria1Alternatif4Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria1alternatif4alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria1Alternatif4Alternatif5.Location = New System.Drawing.Point(404, 249)
        Me.trkKriteria1Alternatif4Alternatif5.Maximum = 17
        Me.trkKriteria1Alternatif4Alternatif5.Minimum = 1
        Me.trkKriteria1Alternatif4Alternatif5.Name = "trkKriteria1Alternatif4Alternatif5"
        Me.trkKriteria1Alternatif4Alternatif5.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria1Alternatif4Alternatif5.TabIndex = 27
        Me.trkKriteria1Alternatif4Alternatif5.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria1alternatif4alternatif5
        '
        'lblKriteria1Alternatif3Alternatif5
        '
        Me.lblKriteria1Alternatif3Alternatif5.AutoSize = True
        Me.lblKriteria1Alternatif3Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria1Alternatif3Alternatif5.Location = New System.Drawing.Point(279, 300)
        Me.lblKriteria1Alternatif3Alternatif5.Name = "lblKriteria1Alternatif3Alternatif5"
        Me.lblKriteria1Alternatif3Alternatif5.Size = New System.Drawing.Size(21, 13)
        Me.lblKriteria1Alternatif3Alternatif5.TabIndex = 26
        Me.lblKriteria1Alternatif3Alternatif5.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif5
        '
        'lblKriteria1Alternatif3Alternatif4
        '
        Me.lblKriteria1Alternatif3Alternatif4.AutoSize = True
        Me.lblKriteria1Alternatif3Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria1Alternatif3Alternatif4.Location = New System.Drawing.Point(279, 249)
        Me.lblKriteria1Alternatif3Alternatif4.Name = "lblKriteria1Alternatif3Alternatif4"
        Me.lblKriteria1Alternatif3Alternatif4.Size = New System.Drawing.Size(24, 13)
        Me.lblKriteria1Alternatif3Alternatif4.TabIndex = 25
        Me.lblKriteria1Alternatif3Alternatif4.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif4
        '
        'lblKriteria1Alternatif3
        '
        Me.lblKriteria1Alternatif3.AutoSize = True
        Me.lblKriteria1Alternatif3.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria1Alternatif3.Location = New System.Drawing.Point(6, 249)
        Me.lblKriteria1Alternatif3.Name = "lblKriteria1Alternatif3"
        Me.lblKriteria1Alternatif3.Size = New System.Drawing.Size(32, 13)
        Me.lblKriteria1Alternatif3.TabIndex = 24
        Me.lblKriteria1Alternatif3.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif3
        '
        'trkKriteria1Alternatif3Alternatif5
        '
        Me.trkKriteria1Alternatif3Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria1alternatif3alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria1Alternatif3Alternatif5.Location = New System.Drawing.Point(75, 300)
        Me.trkKriteria1Alternatif3Alternatif5.Maximum = 17
        Me.trkKriteria1Alternatif3Alternatif5.Minimum = 1
        Me.trkKriteria1Alternatif3Alternatif5.Name = "trkKriteria1Alternatif3Alternatif5"
        Me.trkKriteria1Alternatif3Alternatif5.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria1Alternatif3Alternatif5.TabIndex = 23
        Me.trkKriteria1Alternatif3Alternatif5.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria1alternatif3alternatif5
        '
        'trkKriteria1Alternatif3Alternatif4
        '
        Me.trkKriteria1Alternatif3Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria1alternatif3alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria1Alternatif3Alternatif4.Location = New System.Drawing.Point(75, 249)
        Me.trkKriteria1Alternatif3Alternatif4.Maximum = 17
        Me.trkKriteria1Alternatif3Alternatif4.Minimum = 1
        Me.trkKriteria1Alternatif3Alternatif4.Name = "trkKriteria1Alternatif3Alternatif4"
        Me.trkKriteria1Alternatif3Alternatif4.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria1Alternatif3Alternatif4.TabIndex = 22
        Me.trkKriteria1Alternatif3Alternatif4.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria1alternatif3alternatif4
        '
        'lblKriteria1Alternatif2Alternatif5
        '
        Me.lblKriteria1Alternatif2Alternatif5.AutoSize = True
        Me.lblKriteria1Alternatif2Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria1Alternatif2Alternatif5.Location = New System.Drawing.Point(597, 116)
        Me.lblKriteria1Alternatif2Alternatif5.Name = "lblKriteria1Alternatif2Alternatif5"
        Me.lblKriteria1Alternatif2Alternatif5.Size = New System.Drawing.Size(21, 13)
        Me.lblKriteria1Alternatif2Alternatif5.TabIndex = 21
        Me.lblKriteria1Alternatif2Alternatif5.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif5
        '
        'lblKriteria1Alternatif2Alternatif4
        '
        Me.lblKriteria1Alternatif2Alternatif4.AutoSize = True
        Me.lblKriteria1Alternatif2Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria1Alternatif2Alternatif4.Location = New System.Drawing.Point(597, 65)
        Me.lblKriteria1Alternatif2Alternatif4.Name = "lblKriteria1Alternatif2Alternatif4"
        Me.lblKriteria1Alternatif2Alternatif4.Size = New System.Drawing.Size(24, 13)
        Me.lblKriteria1Alternatif2Alternatif4.TabIndex = 20
        Me.lblKriteria1Alternatif2Alternatif4.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif4
        '
        'trkKriteria1Alternatif2Alternatif5
        '
        Me.trkKriteria1Alternatif2Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria1alternatif2alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria1Alternatif2Alternatif5.Location = New System.Drawing.Point(404, 116)
        Me.trkKriteria1Alternatif2Alternatif5.Maximum = 17
        Me.trkKriteria1Alternatif2Alternatif5.Minimum = 1
        Me.trkKriteria1Alternatif2Alternatif5.Name = "trkKriteria1Alternatif2Alternatif5"
        Me.trkKriteria1Alternatif2Alternatif5.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria1Alternatif2Alternatif5.TabIndex = 19
        Me.trkKriteria1Alternatif2Alternatif5.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria1alternatif2alternatif5
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label45.Location = New System.Drawing.Point(597, 14)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(32, 13)
        Me.Label45.TabIndex = 18
        Me.Label45.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif3
        '
        'trkKriteria1Alternatif2Alternatif4
        '
        Me.trkKriteria1Alternatif2Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria1alternatif2alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria1Alternatif2Alternatif4.Location = New System.Drawing.Point(404, 65)
        Me.trkKriteria1Alternatif2Alternatif4.Maximum = 17
        Me.trkKriteria1Alternatif2Alternatif4.Minimum = 1
        Me.trkKriteria1Alternatif2Alternatif4.Name = "trkKriteria1Alternatif2Alternatif4"
        Me.trkKriteria1Alternatif2Alternatif4.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria1Alternatif2Alternatif4.TabIndex = 17
        Me.trkKriteria1Alternatif2Alternatif4.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria1alternatif2alternatif4
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif2", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label46.Location = New System.Drawing.Point(380, 14)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(18, 13)
        Me.Label46.TabIndex = 16
        Me.Label46.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif2
        '
        'trkKriteria1Alternatif2Alternatif3
        '
        Me.trkKriteria1Alternatif2Alternatif3.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria1alternatif2alternatif3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria1Alternatif2Alternatif3.Location = New System.Drawing.Point(404, 14)
        Me.trkKriteria1Alternatif2Alternatif3.Maximum = 17
        Me.trkKriteria1Alternatif2Alternatif3.Minimum = 1
        Me.trkKriteria1Alternatif2Alternatif3.Name = "trkKriteria1Alternatif2Alternatif3"
        Me.trkKriteria1Alternatif2Alternatif3.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria1Alternatif2Alternatif3.TabIndex = 15
        Me.trkKriteria1Alternatif2Alternatif3.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria1alternatif2alternatif3
        '
        'lblKriteria1Alternatif1Alternatif5
        '
        Me.lblKriteria1Alternatif1Alternatif5.AutoSize = True
        Me.lblKriteria1Alternatif1Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria1Alternatif1Alternatif5.Location = New System.Drawing.Point(279, 167)
        Me.lblKriteria1Alternatif1Alternatif5.Name = "lblKriteria1Alternatif1Alternatif5"
        Me.lblKriteria1Alternatif1Alternatif5.Size = New System.Drawing.Size(21, 13)
        Me.lblKriteria1Alternatif1Alternatif5.TabIndex = 14
        Me.lblKriteria1Alternatif1Alternatif5.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif5
        '
        'trkKriteria1Alternatif1Alternatif5
        '
        Me.trkKriteria1Alternatif1Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria1alternatif1alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria1Alternatif1Alternatif5.Location = New System.Drawing.Point(75, 167)
        Me.trkKriteria1Alternatif1Alternatif5.Maximum = 17
        Me.trkKriteria1Alternatif1Alternatif5.Minimum = 1
        Me.trkKriteria1Alternatif1Alternatif5.Name = "trkKriteria1Alternatif1Alternatif5"
        Me.trkKriteria1Alternatif1Alternatif5.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria1Alternatif1Alternatif5.TabIndex = 13
        Me.trkKriteria1Alternatif1Alternatif5.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria1alternatif1alternatif5
        '
        'lblKriteria1Alternatif1Alternatif4
        '
        Me.lblKriteria1Alternatif1Alternatif4.AutoSize = True
        Me.lblKriteria1Alternatif1Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria1Alternatif1Alternatif4.Location = New System.Drawing.Point(279, 116)
        Me.lblKriteria1Alternatif1Alternatif4.Name = "lblKriteria1Alternatif1Alternatif4"
        Me.lblKriteria1Alternatif1Alternatif4.Size = New System.Drawing.Size(24, 13)
        Me.lblKriteria1Alternatif1Alternatif4.TabIndex = 11
        Me.lblKriteria1Alternatif1Alternatif4.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif4
        '
        'trkKriteria1Alternatif1Alternatif4
        '
        Me.trkKriteria1Alternatif1Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria1alternatif1alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria1Alternatif1Alternatif4.Location = New System.Drawing.Point(75, 116)
        Me.trkKriteria1Alternatif1Alternatif4.Maximum = 17
        Me.trkKriteria1Alternatif1Alternatif4.Minimum = 1
        Me.trkKriteria1Alternatif1Alternatif4.Name = "trkKriteria1Alternatif1Alternatif4"
        Me.trkKriteria1Alternatif1Alternatif4.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria1Alternatif1Alternatif4.TabIndex = 10
        Me.trkKriteria1Alternatif1Alternatif4.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria1alternatif1alternatif4
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label21.Location = New System.Drawing.Point(279, 65)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(32, 13)
        Me.Label21.TabIndex = 8
        Me.Label21.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif3
        '
        'trkKriteria1Alternatif1Alternatif3
        '
        Me.trkKriteria1Alternatif1Alternatif3.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria1alternatif1alternatif3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria1Alternatif1Alternatif3.Location = New System.Drawing.Point(75, 65)
        Me.trkKriteria1Alternatif1Alternatif3.Maximum = 17
        Me.trkKriteria1Alternatif1Alternatif3.Minimum = 1
        Me.trkKriteria1Alternatif1Alternatif3.Name = "trkKriteria1Alternatif1Alternatif3"
        Me.trkKriteria1Alternatif1Alternatif3.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria1Alternatif1Alternatif3.TabIndex = 7
        Me.trkKriteria1Alternatif1Alternatif3.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria1alternatif1alternatif3
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif2", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label19.Location = New System.Drawing.Point(279, 14)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(18, 13)
        Me.Label19.TabIndex = 5
        Me.Label19.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif2
        '
        'trkKriteria1Alternatif1Alternatif2
        '
        Me.trkKriteria1Alternatif1Alternatif2.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria1alternatif1alternatif2", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria1Alternatif1Alternatif2.Location = New System.Drawing.Point(75, 14)
        Me.trkKriteria1Alternatif1Alternatif2.Maximum = 17
        Me.trkKriteria1Alternatif1Alternatif2.Minimum = 1
        Me.trkKriteria1Alternatif1Alternatif2.Name = "trkKriteria1Alternatif1Alternatif2"
        Me.trkKriteria1Alternatif1Alternatif2.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria1Alternatif1Alternatif2.TabIndex = 4
        Me.trkKriteria1Alternatif1Alternatif2.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria1alternatif1alternatif2
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif1", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label20.Location = New System.Drawing.Point(6, 14)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(24, 13)
        Me.Label20.TabIndex = 3
        Me.Label20.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif1
        '
        'TabPage9
        '
        Me.TabPage9.Controls.Add(Me.lblKriteria2Alternatif4Alternatif5)
        Me.TabPage9.Controls.Add(Me.lblKriteria2Alternatif4)
        Me.TabPage9.Controls.Add(Me.trkKriteria2Alternatif4Alternatif5)
        Me.TabPage9.Controls.Add(Me.lblKriteria2Alternatif3Alternatif5)
        Me.TabPage9.Controls.Add(Me.lblKriteria2Alternatif3Alternatif4)
        Me.TabPage9.Controls.Add(Me.lblKriteria2Alternatif3)
        Me.TabPage9.Controls.Add(Me.trkKriteria2Alternatif3Alternatif5)
        Me.TabPage9.Controls.Add(Me.trkKriteria2Alternatif3Alternatif4)
        Me.TabPage9.Controls.Add(Me.lblKriteria2Alternatif2Alternatif5)
        Me.TabPage9.Controls.Add(Me.lblKriteria2Alternatif2Alternatif4)
        Me.TabPage9.Controls.Add(Me.trkKriteria2Alternatif2Alternatif5)
        Me.TabPage9.Controls.Add(Me.Label60)
        Me.TabPage9.Controls.Add(Me.trkKriteria2Alternatif2Alternatif4)
        Me.TabPage9.Controls.Add(Me.Label61)
        Me.TabPage9.Controls.Add(Me.trkKriteria2Alternatif2Alternatif3)
        Me.TabPage9.Controls.Add(Me.lblKriteria2Alternatif1Alternatif5)
        Me.TabPage9.Controls.Add(Me.trkKriteria2Alternatif1Alternatif5)
        Me.TabPage9.Controls.Add(Me.lblKriteria2Alternatif1Alternatif4)
        Me.TabPage9.Controls.Add(Me.trkKriteria2Alternatif1Alternatif4)
        Me.TabPage9.Controls.Add(Me.Label26)
        Me.TabPage9.Controls.Add(Me.trkKriteria2Alternatif1Alternatif3)
        Me.TabPage9.Controls.Add(Me.Label27)
        Me.TabPage9.Controls.Add(Me.trkKriteria2Alternatif1Alternatif2)
        Me.TabPage9.Controls.Add(Me.Label28)
        Me.TabPage9.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria2", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.TabPage9.Location = New System.Drawing.Point(4, 22)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage9.Size = New System.Drawing.Size(847, 318)
        Me.TabPage9.TabIndex = 1
        Me.TabPage9.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria2
        Me.TabPage9.UseVisualStyleBackColor = True
        '
        'lblKriteria2Alternatif4Alternatif5
        '
        Me.lblKriteria2Alternatif4Alternatif5.AutoSize = True
        Me.lblKriteria2Alternatif4Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria2Alternatif4Alternatif5.Location = New System.Drawing.Point(597, 249)
        Me.lblKriteria2Alternatif4Alternatif5.Name = "lblKriteria2Alternatif4Alternatif5"
        Me.lblKriteria2Alternatif4Alternatif5.Size = New System.Drawing.Size(21, 13)
        Me.lblKriteria2Alternatif4Alternatif5.TabIndex = 44
        Me.lblKriteria2Alternatif4Alternatif5.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif5
        '
        'lblKriteria2Alternatif4
        '
        Me.lblKriteria2Alternatif4.AutoSize = True
        Me.lblKriteria2Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria2Alternatif4.Location = New System.Drawing.Point(374, 249)
        Me.lblKriteria2Alternatif4.Name = "lblKriteria2Alternatif4"
        Me.lblKriteria2Alternatif4.Size = New System.Drawing.Size(24, 13)
        Me.lblKriteria2Alternatif4.TabIndex = 43
        Me.lblKriteria2Alternatif4.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif4
        '
        'trkKriteria2Alternatif4Alternatif5
        '
        Me.trkKriteria2Alternatif4Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria2alternatif4alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria2Alternatif4Alternatif5.Location = New System.Drawing.Point(404, 249)
        Me.trkKriteria2Alternatif4Alternatif5.Maximum = 17
        Me.trkKriteria2Alternatif4Alternatif5.Minimum = 1
        Me.trkKriteria2Alternatif4Alternatif5.Name = "trkKriteria2Alternatif4Alternatif5"
        Me.trkKriteria2Alternatif4Alternatif5.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria2Alternatif4Alternatif5.TabIndex = 42
        Me.trkKriteria2Alternatif4Alternatif5.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria2alternatif4alternatif5
        '
        'lblKriteria2Alternatif3Alternatif5
        '
        Me.lblKriteria2Alternatif3Alternatif5.AutoSize = True
        Me.lblKriteria2Alternatif3Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria2Alternatif3Alternatif5.Location = New System.Drawing.Point(279, 300)
        Me.lblKriteria2Alternatif3Alternatif5.Name = "lblKriteria2Alternatif3Alternatif5"
        Me.lblKriteria2Alternatif3Alternatif5.Size = New System.Drawing.Size(21, 13)
        Me.lblKriteria2Alternatif3Alternatif5.TabIndex = 41
        Me.lblKriteria2Alternatif3Alternatif5.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif5
        '
        'lblKriteria2Alternatif3Alternatif4
        '
        Me.lblKriteria2Alternatif3Alternatif4.AutoSize = True
        Me.lblKriteria2Alternatif3Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria2Alternatif3Alternatif4.Location = New System.Drawing.Point(279, 249)
        Me.lblKriteria2Alternatif3Alternatif4.Name = "lblKriteria2Alternatif3Alternatif4"
        Me.lblKriteria2Alternatif3Alternatif4.Size = New System.Drawing.Size(24, 13)
        Me.lblKriteria2Alternatif3Alternatif4.TabIndex = 40
        Me.lblKriteria2Alternatif3Alternatif4.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif4
        '
        'lblKriteria2Alternatif3
        '
        Me.lblKriteria2Alternatif3.AutoSize = True
        Me.lblKriteria2Alternatif3.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria2Alternatif3.Location = New System.Drawing.Point(6, 249)
        Me.lblKriteria2Alternatif3.Name = "lblKriteria2Alternatif3"
        Me.lblKriteria2Alternatif3.Size = New System.Drawing.Size(32, 13)
        Me.lblKriteria2Alternatif3.TabIndex = 39
        Me.lblKriteria2Alternatif3.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif3
        '
        'trkKriteria2Alternatif3Alternatif5
        '
        Me.trkKriteria2Alternatif3Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria2alternatif3alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria2Alternatif3Alternatif5.Location = New System.Drawing.Point(75, 300)
        Me.trkKriteria2Alternatif3Alternatif5.Maximum = 17
        Me.trkKriteria2Alternatif3Alternatif5.Minimum = 1
        Me.trkKriteria2Alternatif3Alternatif5.Name = "trkKriteria2Alternatif3Alternatif5"
        Me.trkKriteria2Alternatif3Alternatif5.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria2Alternatif3Alternatif5.TabIndex = 38
        Me.trkKriteria2Alternatif3Alternatif5.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria2alternatif3alternatif5
        '
        'trkKriteria2Alternatif3Alternatif4
        '
        Me.trkKriteria2Alternatif3Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria2alternatif3alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria2Alternatif3Alternatif4.Location = New System.Drawing.Point(75, 249)
        Me.trkKriteria2Alternatif3Alternatif4.Maximum = 17
        Me.trkKriteria2Alternatif3Alternatif4.Minimum = 1
        Me.trkKriteria2Alternatif3Alternatif4.Name = "trkKriteria2Alternatif3Alternatif4"
        Me.trkKriteria2Alternatif3Alternatif4.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria2Alternatif3Alternatif4.TabIndex = 37
        Me.trkKriteria2Alternatif3Alternatif4.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria2alternatif3alternatif4
        '
        'lblKriteria2Alternatif2Alternatif5
        '
        Me.lblKriteria2Alternatif2Alternatif5.AutoSize = True
        Me.lblKriteria2Alternatif2Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria2Alternatif2Alternatif5.Location = New System.Drawing.Point(597, 116)
        Me.lblKriteria2Alternatif2Alternatif5.Name = "lblKriteria2Alternatif2Alternatif5"
        Me.lblKriteria2Alternatif2Alternatif5.Size = New System.Drawing.Size(21, 13)
        Me.lblKriteria2Alternatif2Alternatif5.TabIndex = 36
        Me.lblKriteria2Alternatif2Alternatif5.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif5
        '
        'lblKriteria2Alternatif2Alternatif4
        '
        Me.lblKriteria2Alternatif2Alternatif4.AutoSize = True
        Me.lblKriteria2Alternatif2Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria2Alternatif2Alternatif4.Location = New System.Drawing.Point(597, 65)
        Me.lblKriteria2Alternatif2Alternatif4.Name = "lblKriteria2Alternatif2Alternatif4"
        Me.lblKriteria2Alternatif2Alternatif4.Size = New System.Drawing.Size(24, 13)
        Me.lblKriteria2Alternatif2Alternatif4.TabIndex = 35
        Me.lblKriteria2Alternatif2Alternatif4.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif4
        '
        'trkKriteria2Alternatif2Alternatif5
        '
        Me.trkKriteria2Alternatif2Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria2alternatif2alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria2Alternatif2Alternatif5.Location = New System.Drawing.Point(404, 116)
        Me.trkKriteria2Alternatif2Alternatif5.Maximum = 17
        Me.trkKriteria2Alternatif2Alternatif5.Minimum = 1
        Me.trkKriteria2Alternatif2Alternatif5.Name = "trkKriteria2Alternatif2Alternatif5"
        Me.trkKriteria2Alternatif2Alternatif5.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria2Alternatif2Alternatif5.TabIndex = 34
        Me.trkKriteria2Alternatif2Alternatif5.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria2alternatif2alternatif5
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label60.Location = New System.Drawing.Point(597, 14)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(32, 13)
        Me.Label60.TabIndex = 33
        Me.Label60.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif3
        '
        'trkKriteria2Alternatif2Alternatif4
        '
        Me.trkKriteria2Alternatif2Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria2alternatif2alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria2Alternatif2Alternatif4.Location = New System.Drawing.Point(404, 65)
        Me.trkKriteria2Alternatif2Alternatif4.Maximum = 17
        Me.trkKriteria2Alternatif2Alternatif4.Minimum = 1
        Me.trkKriteria2Alternatif2Alternatif4.Name = "trkKriteria2Alternatif2Alternatif4"
        Me.trkKriteria2Alternatif2Alternatif4.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria2Alternatif2Alternatif4.TabIndex = 32
        Me.trkKriteria2Alternatif2Alternatif4.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria2alternatif2alternatif4
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif2", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label61.Location = New System.Drawing.Point(380, 14)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(18, 13)
        Me.Label61.TabIndex = 31
        Me.Label61.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif2
        '
        'trkKriteria2Alternatif2Alternatif3
        '
        Me.trkKriteria2Alternatif2Alternatif3.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria2alternatif2alternatif3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria2Alternatif2Alternatif3.Location = New System.Drawing.Point(404, 14)
        Me.trkKriteria2Alternatif2Alternatif3.Maximum = 17
        Me.trkKriteria2Alternatif2Alternatif3.Minimum = 1
        Me.trkKriteria2Alternatif2Alternatif3.Name = "trkKriteria2Alternatif2Alternatif3"
        Me.trkKriteria2Alternatif2Alternatif3.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria2Alternatif2Alternatif3.TabIndex = 30
        Me.trkKriteria2Alternatif2Alternatif3.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria2alternatif2alternatif3
        '
        'lblKriteria2Alternatif1Alternatif5
        '
        Me.lblKriteria2Alternatif1Alternatif5.AutoSize = True
        Me.lblKriteria2Alternatif1Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria2Alternatif1Alternatif5.Location = New System.Drawing.Point(279, 167)
        Me.lblKriteria2Alternatif1Alternatif5.Name = "lblKriteria2Alternatif1Alternatif5"
        Me.lblKriteria2Alternatif1Alternatif5.Size = New System.Drawing.Size(21, 13)
        Me.lblKriteria2Alternatif1Alternatif5.TabIndex = 23
        Me.lblKriteria2Alternatif1Alternatif5.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif5
        '
        'trkKriteria2Alternatif1Alternatif5
        '
        Me.trkKriteria2Alternatif1Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria2alternatif1alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria2Alternatif1Alternatif5.Location = New System.Drawing.Point(75, 167)
        Me.trkKriteria2Alternatif1Alternatif5.Maximum = 17
        Me.trkKriteria2Alternatif1Alternatif5.Minimum = 1
        Me.trkKriteria2Alternatif1Alternatif5.Name = "trkKriteria2Alternatif1Alternatif5"
        Me.trkKriteria2Alternatif1Alternatif5.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria2Alternatif1Alternatif5.TabIndex = 22
        Me.trkKriteria2Alternatif1Alternatif5.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria2alternatif1alternatif5
        '
        'lblKriteria2Alternatif1Alternatif4
        '
        Me.lblKriteria2Alternatif1Alternatif4.AutoSize = True
        Me.lblKriteria2Alternatif1Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria2Alternatif1Alternatif4.Location = New System.Drawing.Point(279, 116)
        Me.lblKriteria2Alternatif1Alternatif4.Name = "lblKriteria2Alternatif1Alternatif4"
        Me.lblKriteria2Alternatif1Alternatif4.Size = New System.Drawing.Size(24, 13)
        Me.lblKriteria2Alternatif1Alternatif4.TabIndex = 21
        Me.lblKriteria2Alternatif1Alternatif4.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif4
        '
        'trkKriteria2Alternatif1Alternatif4
        '
        Me.trkKriteria2Alternatif1Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria2alternatif1alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria2Alternatif1Alternatif4.Location = New System.Drawing.Point(75, 116)
        Me.trkKriteria2Alternatif1Alternatif4.Maximum = 17
        Me.trkKriteria2Alternatif1Alternatif4.Minimum = 1
        Me.trkKriteria2Alternatif1Alternatif4.Name = "trkKriteria2Alternatif1Alternatif4"
        Me.trkKriteria2Alternatif1Alternatif4.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria2Alternatif1Alternatif4.TabIndex = 20
        Me.trkKriteria2Alternatif1Alternatif4.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria2alternatif1alternatif4
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label26.Location = New System.Drawing.Point(279, 65)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(32, 13)
        Me.Label26.TabIndex = 19
        Me.Label26.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif3
        '
        'trkKriteria2Alternatif1Alternatif3
        '
        Me.trkKriteria2Alternatif1Alternatif3.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria2alternatif1alternatif3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria2Alternatif1Alternatif3.Location = New System.Drawing.Point(75, 65)
        Me.trkKriteria2Alternatif1Alternatif3.Maximum = 17
        Me.trkKriteria2Alternatif1Alternatif3.Minimum = 1
        Me.trkKriteria2Alternatif1Alternatif3.Name = "trkKriteria2Alternatif1Alternatif3"
        Me.trkKriteria2Alternatif1Alternatif3.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria2Alternatif1Alternatif3.TabIndex = 18
        Me.trkKriteria2Alternatif1Alternatif3.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria2alternatif1alternatif3
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif2", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label27.Location = New System.Drawing.Point(279, 14)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(18, 13)
        Me.Label27.TabIndex = 17
        Me.Label27.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif2
        '
        'trkKriteria2Alternatif1Alternatif2
        '
        Me.trkKriteria2Alternatif1Alternatif2.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria2alternatif1alternatif2", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria2Alternatif1Alternatif2.Location = New System.Drawing.Point(75, 14)
        Me.trkKriteria2Alternatif1Alternatif2.Maximum = 17
        Me.trkKriteria2Alternatif1Alternatif2.Minimum = 1
        Me.trkKriteria2Alternatif1Alternatif2.Name = "trkKriteria2Alternatif1Alternatif2"
        Me.trkKriteria2Alternatif1Alternatif2.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria2Alternatif1Alternatif2.TabIndex = 16
        Me.trkKriteria2Alternatif1Alternatif2.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria2alternatif1alternatif2
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif1", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label28.Location = New System.Drawing.Point(6, 14)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(24, 13)
        Me.Label28.TabIndex = 15
        Me.Label28.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif1
        '
        'TabPage10
        '
        Me.TabPage10.Controls.Add(Me.lblKriteria3Alternatif4Alternatif5)
        Me.TabPage10.Controls.Add(Me.lblKriteria3Alternatif4)
        Me.TabPage10.Controls.Add(Me.trkKriteria3Alternatif4Alternatif5)
        Me.TabPage10.Controls.Add(Me.lblKriteria3Alternatif3Alternatif5)
        Me.TabPage10.Controls.Add(Me.lblKriteria3Alternatif3Alternatif4)
        Me.TabPage10.Controls.Add(Me.lblKriteria3Alternatif3)
        Me.TabPage10.Controls.Add(Me.trkKriteria3Alternatif3Alternatif5)
        Me.TabPage10.Controls.Add(Me.trkKriteria3Alternatif3Alternatif4)
        Me.TabPage10.Controls.Add(Me.lblKriteria3Alternatif2Alternatif5)
        Me.TabPage10.Controls.Add(Me.lblKriteria3Alternatif2Alternatif4)
        Me.TabPage10.Controls.Add(Me.trkKriteria3Alternatif2Alternatif5)
        Me.TabPage10.Controls.Add(Me.Label69)
        Me.TabPage10.Controls.Add(Me.trkKriteria3Alternatif2Alternatif4)
        Me.TabPage10.Controls.Add(Me.Label70)
        Me.TabPage10.Controls.Add(Me.trkKriteria3Alternatif2Alternatif3)
        Me.TabPage10.Controls.Add(Me.lblKriteria3Alternatif1Alternatif5)
        Me.TabPage10.Controls.Add(Me.trkKriteria3Alternatif1Alternatif5)
        Me.TabPage10.Controls.Add(Me.lblKriteria3Alternatif1Alternatif4)
        Me.TabPage10.Controls.Add(Me.trkKriteria3Alternatif1Alternatif4)
        Me.TabPage10.Controls.Add(Me.Label31)
        Me.TabPage10.Controls.Add(Me.trkKriteria3Alternatif1Alternatif3)
        Me.TabPage10.Controls.Add(Me.Label32)
        Me.TabPage10.Controls.Add(Me.trkKriteria3Alternatif1Alternatif2)
        Me.TabPage10.Controls.Add(Me.Label33)
        Me.TabPage10.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.TabPage10.Location = New System.Drawing.Point(4, 22)
        Me.TabPage10.Name = "TabPage10"
        Me.TabPage10.Size = New System.Drawing.Size(847, 318)
        Me.TabPage10.TabIndex = 2
        Me.TabPage10.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria3
        Me.TabPage10.UseVisualStyleBackColor = True
        '
        'lblKriteria3Alternatif4Alternatif5
        '
        Me.lblKriteria3Alternatif4Alternatif5.AutoSize = True
        Me.lblKriteria3Alternatif4Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria3Alternatif4Alternatif5.Location = New System.Drawing.Point(597, 249)
        Me.lblKriteria3Alternatif4Alternatif5.Name = "lblKriteria3Alternatif4Alternatif5"
        Me.lblKriteria3Alternatif4Alternatif5.Size = New System.Drawing.Size(21, 13)
        Me.lblKriteria3Alternatif4Alternatif5.TabIndex = 44
        Me.lblKriteria3Alternatif4Alternatif5.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif5
        '
        'lblKriteria3Alternatif4
        '
        Me.lblKriteria3Alternatif4.AutoSize = True
        Me.lblKriteria3Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria3Alternatif4.Location = New System.Drawing.Point(374, 249)
        Me.lblKriteria3Alternatif4.Name = "lblKriteria3Alternatif4"
        Me.lblKriteria3Alternatif4.Size = New System.Drawing.Size(24, 13)
        Me.lblKriteria3Alternatif4.TabIndex = 43
        Me.lblKriteria3Alternatif4.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif4
        '
        'trkKriteria3Alternatif4Alternatif5
        '
        Me.trkKriteria3Alternatif4Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria3alternatif4alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria3Alternatif4Alternatif5.Location = New System.Drawing.Point(404, 249)
        Me.trkKriteria3Alternatif4Alternatif5.Maximum = 17
        Me.trkKriteria3Alternatif4Alternatif5.Minimum = 1
        Me.trkKriteria3Alternatif4Alternatif5.Name = "trkKriteria3Alternatif4Alternatif5"
        Me.trkKriteria3Alternatif4Alternatif5.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria3Alternatif4Alternatif5.TabIndex = 42
        Me.trkKriteria3Alternatif4Alternatif5.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria3alternatif4alternatif5
        '
        'lblKriteria3Alternatif3Alternatif5
        '
        Me.lblKriteria3Alternatif3Alternatif5.AutoSize = True
        Me.lblKriteria3Alternatif3Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria3Alternatif3Alternatif5.Location = New System.Drawing.Point(279, 300)
        Me.lblKriteria3Alternatif3Alternatif5.Name = "lblKriteria3Alternatif3Alternatif5"
        Me.lblKriteria3Alternatif3Alternatif5.Size = New System.Drawing.Size(21, 13)
        Me.lblKriteria3Alternatif3Alternatif5.TabIndex = 41
        Me.lblKriteria3Alternatif3Alternatif5.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif5
        '
        'lblKriteria3Alternatif3Alternatif4
        '
        Me.lblKriteria3Alternatif3Alternatif4.AutoSize = True
        Me.lblKriteria3Alternatif3Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria3Alternatif3Alternatif4.Location = New System.Drawing.Point(279, 249)
        Me.lblKriteria3Alternatif3Alternatif4.Name = "lblKriteria3Alternatif3Alternatif4"
        Me.lblKriteria3Alternatif3Alternatif4.Size = New System.Drawing.Size(24, 13)
        Me.lblKriteria3Alternatif3Alternatif4.TabIndex = 40
        Me.lblKriteria3Alternatif3Alternatif4.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif4
        '
        'lblKriteria3Alternatif3
        '
        Me.lblKriteria3Alternatif3.AutoSize = True
        Me.lblKriteria3Alternatif3.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria3Alternatif3.Location = New System.Drawing.Point(6, 249)
        Me.lblKriteria3Alternatif3.Name = "lblKriteria3Alternatif3"
        Me.lblKriteria3Alternatif3.Size = New System.Drawing.Size(32, 13)
        Me.lblKriteria3Alternatif3.TabIndex = 39
        Me.lblKriteria3Alternatif3.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif3
        '
        'trkKriteria3Alternatif3Alternatif5
        '
        Me.trkKriteria3Alternatif3Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria3alternatif3alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria3Alternatif3Alternatif5.Location = New System.Drawing.Point(75, 300)
        Me.trkKriteria3Alternatif3Alternatif5.Maximum = 17
        Me.trkKriteria3Alternatif3Alternatif5.Minimum = 1
        Me.trkKriteria3Alternatif3Alternatif5.Name = "trkKriteria3Alternatif3Alternatif5"
        Me.trkKriteria3Alternatif3Alternatif5.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria3Alternatif3Alternatif5.TabIndex = 38
        Me.trkKriteria3Alternatif3Alternatif5.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria3alternatif3alternatif5
        '
        'trkKriteria3Alternatif3Alternatif4
        '
        Me.trkKriteria3Alternatif3Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria3alternatif3alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria3Alternatif3Alternatif4.Location = New System.Drawing.Point(75, 249)
        Me.trkKriteria3Alternatif3Alternatif4.Maximum = 17
        Me.trkKriteria3Alternatif3Alternatif4.Minimum = 1
        Me.trkKriteria3Alternatif3Alternatif4.Name = "trkKriteria3Alternatif3Alternatif4"
        Me.trkKriteria3Alternatif3Alternatif4.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria3Alternatif3Alternatif4.TabIndex = 37
        Me.trkKriteria3Alternatif3Alternatif4.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria3alternatif3alternatif4
        '
        'lblKriteria3Alternatif2Alternatif5
        '
        Me.lblKriteria3Alternatif2Alternatif5.AutoSize = True
        Me.lblKriteria3Alternatif2Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria3Alternatif2Alternatif5.Location = New System.Drawing.Point(597, 116)
        Me.lblKriteria3Alternatif2Alternatif5.Name = "lblKriteria3Alternatif2Alternatif5"
        Me.lblKriteria3Alternatif2Alternatif5.Size = New System.Drawing.Size(21, 13)
        Me.lblKriteria3Alternatif2Alternatif5.TabIndex = 36
        Me.lblKriteria3Alternatif2Alternatif5.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif5
        '
        'lblKriteria3Alternatif2Alternatif4
        '
        Me.lblKriteria3Alternatif2Alternatif4.AutoSize = True
        Me.lblKriteria3Alternatif2Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria3Alternatif2Alternatif4.Location = New System.Drawing.Point(597, 65)
        Me.lblKriteria3Alternatif2Alternatif4.Name = "lblKriteria3Alternatif2Alternatif4"
        Me.lblKriteria3Alternatif2Alternatif4.Size = New System.Drawing.Size(24, 13)
        Me.lblKriteria3Alternatif2Alternatif4.TabIndex = 35
        Me.lblKriteria3Alternatif2Alternatif4.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif4
        '
        'trkKriteria3Alternatif2Alternatif5
        '
        Me.trkKriteria3Alternatif2Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria3alternatif2alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria3Alternatif2Alternatif5.Location = New System.Drawing.Point(404, 116)
        Me.trkKriteria3Alternatif2Alternatif5.Maximum = 17
        Me.trkKriteria3Alternatif2Alternatif5.Minimum = 1
        Me.trkKriteria3Alternatif2Alternatif5.Name = "trkKriteria3Alternatif2Alternatif5"
        Me.trkKriteria3Alternatif2Alternatif5.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria3Alternatif2Alternatif5.TabIndex = 34
        Me.trkKriteria3Alternatif2Alternatif5.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria3alternatif2alternatif5
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label69.Location = New System.Drawing.Point(597, 14)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(32, 13)
        Me.Label69.TabIndex = 33
        Me.Label69.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif3
        '
        'trkKriteria3Alternatif2Alternatif4
        '
        Me.trkKriteria3Alternatif2Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria3alternatif2alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria3Alternatif2Alternatif4.Location = New System.Drawing.Point(404, 65)
        Me.trkKriteria3Alternatif2Alternatif4.Maximum = 17
        Me.trkKriteria3Alternatif2Alternatif4.Minimum = 1
        Me.trkKriteria3Alternatif2Alternatif4.Name = "trkKriteria3Alternatif2Alternatif4"
        Me.trkKriteria3Alternatif2Alternatif4.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria3Alternatif2Alternatif4.TabIndex = 32
        Me.trkKriteria3Alternatif2Alternatif4.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria3alternatif2alternatif4
        '
        'Label70
        '
        Me.Label70.AutoSize = True
        Me.Label70.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif2", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label70.Location = New System.Drawing.Point(380, 14)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(18, 13)
        Me.Label70.TabIndex = 31
        Me.Label70.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif2
        '
        'trkKriteria3Alternatif2Alternatif3
        '
        Me.trkKriteria3Alternatif2Alternatif3.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria3alternatif2alternatif3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria3Alternatif2Alternatif3.Location = New System.Drawing.Point(404, 14)
        Me.trkKriteria3Alternatif2Alternatif3.Maximum = 17
        Me.trkKriteria3Alternatif2Alternatif3.Minimum = 1
        Me.trkKriteria3Alternatif2Alternatif3.Name = "trkKriteria3Alternatif2Alternatif3"
        Me.trkKriteria3Alternatif2Alternatif3.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria3Alternatif2Alternatif3.TabIndex = 30
        Me.trkKriteria3Alternatif2Alternatif3.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria3alternatif2alternatif3
        '
        'lblKriteria3Alternatif1Alternatif5
        '
        Me.lblKriteria3Alternatif1Alternatif5.AutoSize = True
        Me.lblKriteria3Alternatif1Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria3Alternatif1Alternatif5.Location = New System.Drawing.Point(279, 167)
        Me.lblKriteria3Alternatif1Alternatif5.Name = "lblKriteria3Alternatif1Alternatif5"
        Me.lblKriteria3Alternatif1Alternatif5.Size = New System.Drawing.Size(21, 13)
        Me.lblKriteria3Alternatif1Alternatif5.TabIndex = 23
        Me.lblKriteria3Alternatif1Alternatif5.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif5
        '
        'trkKriteria3Alternatif1Alternatif5
        '
        Me.trkKriteria3Alternatif1Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria3alternatif1alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria3Alternatif1Alternatif5.Location = New System.Drawing.Point(75, 167)
        Me.trkKriteria3Alternatif1Alternatif5.Maximum = 17
        Me.trkKriteria3Alternatif1Alternatif5.Minimum = 1
        Me.trkKriteria3Alternatif1Alternatif5.Name = "trkKriteria3Alternatif1Alternatif5"
        Me.trkKriteria3Alternatif1Alternatif5.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria3Alternatif1Alternatif5.TabIndex = 22
        Me.trkKriteria3Alternatif1Alternatif5.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria3alternatif1alternatif5
        '
        'lblKriteria3Alternatif1Alternatif4
        '
        Me.lblKriteria3Alternatif1Alternatif4.AutoSize = True
        Me.lblKriteria3Alternatif1Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria3Alternatif1Alternatif4.Location = New System.Drawing.Point(279, 116)
        Me.lblKriteria3Alternatif1Alternatif4.Name = "lblKriteria3Alternatif1Alternatif4"
        Me.lblKriteria3Alternatif1Alternatif4.Size = New System.Drawing.Size(24, 13)
        Me.lblKriteria3Alternatif1Alternatif4.TabIndex = 21
        Me.lblKriteria3Alternatif1Alternatif4.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif4
        '
        'trkKriteria3Alternatif1Alternatif4
        '
        Me.trkKriteria3Alternatif1Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria3alternatif1alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria3Alternatif1Alternatif4.Location = New System.Drawing.Point(75, 116)
        Me.trkKriteria3Alternatif1Alternatif4.Maximum = 17
        Me.trkKriteria3Alternatif1Alternatif4.Minimum = 1
        Me.trkKriteria3Alternatif1Alternatif4.Name = "trkKriteria3Alternatif1Alternatif4"
        Me.trkKriteria3Alternatif1Alternatif4.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria3Alternatif1Alternatif4.TabIndex = 20
        Me.trkKriteria3Alternatif1Alternatif4.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria3alternatif1alternatif4
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label31.Location = New System.Drawing.Point(279, 65)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(32, 13)
        Me.Label31.TabIndex = 19
        Me.Label31.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif3
        '
        'trkKriteria3Alternatif1Alternatif3
        '
        Me.trkKriteria3Alternatif1Alternatif3.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria3alternatif1alternatif3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria3Alternatif1Alternatif3.Location = New System.Drawing.Point(75, 65)
        Me.trkKriteria3Alternatif1Alternatif3.Maximum = 17
        Me.trkKriteria3Alternatif1Alternatif3.Minimum = 1
        Me.trkKriteria3Alternatif1Alternatif3.Name = "trkKriteria3Alternatif1Alternatif3"
        Me.trkKriteria3Alternatif1Alternatif3.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria3Alternatif1Alternatif3.TabIndex = 18
        Me.trkKriteria3Alternatif1Alternatif3.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria3alternatif1alternatif3
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif2", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label32.Location = New System.Drawing.Point(279, 14)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(18, 13)
        Me.Label32.TabIndex = 17
        Me.Label32.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif2
        '
        'trkKriteria3Alternatif1Alternatif2
        '
        Me.trkKriteria3Alternatif1Alternatif2.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria3alternatif1alternatif2", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria3Alternatif1Alternatif2.Location = New System.Drawing.Point(75, 14)
        Me.trkKriteria3Alternatif1Alternatif2.Maximum = 17
        Me.trkKriteria3Alternatif1Alternatif2.Minimum = 1
        Me.trkKriteria3Alternatif1Alternatif2.Name = "trkKriteria3Alternatif1Alternatif2"
        Me.trkKriteria3Alternatif1Alternatif2.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria3Alternatif1Alternatif2.TabIndex = 16
        Me.trkKriteria3Alternatif1Alternatif2.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria3alternatif1alternatif2
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif1", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label33.Location = New System.Drawing.Point(6, 14)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(24, 13)
        Me.Label33.TabIndex = 15
        Me.Label33.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif1
        '
        'tabKriteria4
        '
        Me.tabKriteria4.Controls.Add(Me.lblKriteria4Alternatif4Alternatif5)
        Me.tabKriteria4.Controls.Add(Me.lblKriteria4Alternatif4)
        Me.tabKriteria4.Controls.Add(Me.trkKriteria4Alternatif4Alternatif5)
        Me.tabKriteria4.Controls.Add(Me.lblKriteria4Alternatif3Alternatif5)
        Me.tabKriteria4.Controls.Add(Me.lblKriteria4Alternatif3Alternatif4)
        Me.tabKriteria4.Controls.Add(Me.lblKriteria4Alternatif3)
        Me.tabKriteria4.Controls.Add(Me.trkKriteria4Alternatif3Alternatif5)
        Me.tabKriteria4.Controls.Add(Me.trkKriteria4Alternatif3Alternatif4)
        Me.tabKriteria4.Controls.Add(Me.lblKriteria4Alternatif2Alternatif5)
        Me.tabKriteria4.Controls.Add(Me.lblKriteria4Alternatif2Alternatif4)
        Me.tabKriteria4.Controls.Add(Me.trkKriteria4Alternatif2Alternatif5)
        Me.tabKriteria4.Controls.Add(Me.Label78)
        Me.tabKriteria4.Controls.Add(Me.trkKriteria4Alternatif2Alternatif4)
        Me.tabKriteria4.Controls.Add(Me.Label79)
        Me.tabKriteria4.Controls.Add(Me.trkKriteria4Alternatif2Alternatif3)
        Me.tabKriteria4.Controls.Add(Me.lblKriteria4Alternatif1Alternatif5)
        Me.tabKriteria4.Controls.Add(Me.trkKriteria4Alternatif1Alternatif5)
        Me.tabKriteria4.Controls.Add(Me.lblKriteria4Alternatif1Alternatif4)
        Me.tabKriteria4.Controls.Add(Me.trkKriteria4Alternatif1Alternatif4)
        Me.tabKriteria4.Controls.Add(Me.Label36)
        Me.tabKriteria4.Controls.Add(Me.trkKriteria4Alternatif1Alternatif3)
        Me.tabKriteria4.Controls.Add(Me.Label37)
        Me.tabKriteria4.Controls.Add(Me.trkKriteria4Alternatif1Alternatif2)
        Me.tabKriteria4.Controls.Add(Me.Label38)
        Me.tabKriteria4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.tabKriteria4.Location = New System.Drawing.Point(4, 22)
        Me.tabKriteria4.Name = "tabKriteria4"
        Me.tabKriteria4.Size = New System.Drawing.Size(847, 318)
        Me.tabKriteria4.TabIndex = 3
        Me.tabKriteria4.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria4
        Me.tabKriteria4.UseVisualStyleBackColor = True
        '
        'lblKriteria4Alternatif4Alternatif5
        '
        Me.lblKriteria4Alternatif4Alternatif5.AutoSize = True
        Me.lblKriteria4Alternatif4Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria4Alternatif4Alternatif5.Location = New System.Drawing.Point(597, 249)
        Me.lblKriteria4Alternatif4Alternatif5.Name = "lblKriteria4Alternatif4Alternatif5"
        Me.lblKriteria4Alternatif4Alternatif5.Size = New System.Drawing.Size(21, 13)
        Me.lblKriteria4Alternatif4Alternatif5.TabIndex = 44
        Me.lblKriteria4Alternatif4Alternatif5.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif5
        '
        'lblKriteria4Alternatif4
        '
        Me.lblKriteria4Alternatif4.AutoSize = True
        Me.lblKriteria4Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria4Alternatif4.Location = New System.Drawing.Point(374, 249)
        Me.lblKriteria4Alternatif4.Name = "lblKriteria4Alternatif4"
        Me.lblKriteria4Alternatif4.Size = New System.Drawing.Size(24, 13)
        Me.lblKriteria4Alternatif4.TabIndex = 43
        Me.lblKriteria4Alternatif4.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif4
        '
        'trkKriteria4Alternatif4Alternatif5
        '
        Me.trkKriteria4Alternatif4Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria4alternatif4alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria4Alternatif4Alternatif5.Location = New System.Drawing.Point(404, 249)
        Me.trkKriteria4Alternatif4Alternatif5.Maximum = 17
        Me.trkKriteria4Alternatif4Alternatif5.Minimum = 1
        Me.trkKriteria4Alternatif4Alternatif5.Name = "trkKriteria4Alternatif4Alternatif5"
        Me.trkKriteria4Alternatif4Alternatif5.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria4Alternatif4Alternatif5.TabIndex = 42
        Me.trkKriteria4Alternatif4Alternatif5.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria4alternatif4alternatif5
        '
        'lblKriteria4Alternatif3Alternatif5
        '
        Me.lblKriteria4Alternatif3Alternatif5.AutoSize = True
        Me.lblKriteria4Alternatif3Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria4Alternatif3Alternatif5.Location = New System.Drawing.Point(279, 300)
        Me.lblKriteria4Alternatif3Alternatif5.Name = "lblKriteria4Alternatif3Alternatif5"
        Me.lblKriteria4Alternatif3Alternatif5.Size = New System.Drawing.Size(21, 13)
        Me.lblKriteria4Alternatif3Alternatif5.TabIndex = 41
        Me.lblKriteria4Alternatif3Alternatif5.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif5
        '
        'lblKriteria4Alternatif3Alternatif4
        '
        Me.lblKriteria4Alternatif3Alternatif4.AutoSize = True
        Me.lblKriteria4Alternatif3Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria4Alternatif3Alternatif4.Location = New System.Drawing.Point(279, 249)
        Me.lblKriteria4Alternatif3Alternatif4.Name = "lblKriteria4Alternatif3Alternatif4"
        Me.lblKriteria4Alternatif3Alternatif4.Size = New System.Drawing.Size(24, 13)
        Me.lblKriteria4Alternatif3Alternatif4.TabIndex = 40
        Me.lblKriteria4Alternatif3Alternatif4.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif4
        '
        'lblKriteria4Alternatif3
        '
        Me.lblKriteria4Alternatif3.AutoSize = True
        Me.lblKriteria4Alternatif3.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria4Alternatif3.Location = New System.Drawing.Point(6, 249)
        Me.lblKriteria4Alternatif3.Name = "lblKriteria4Alternatif3"
        Me.lblKriteria4Alternatif3.Size = New System.Drawing.Size(32, 13)
        Me.lblKriteria4Alternatif3.TabIndex = 39
        Me.lblKriteria4Alternatif3.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif3
        '
        'trkKriteria4Alternatif3Alternatif5
        '
        Me.trkKriteria4Alternatif3Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria4alternatif3alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria4Alternatif3Alternatif5.Location = New System.Drawing.Point(75, 300)
        Me.trkKriteria4Alternatif3Alternatif5.Maximum = 17
        Me.trkKriteria4Alternatif3Alternatif5.Minimum = 1
        Me.trkKriteria4Alternatif3Alternatif5.Name = "trkKriteria4Alternatif3Alternatif5"
        Me.trkKriteria4Alternatif3Alternatif5.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria4Alternatif3Alternatif5.TabIndex = 38
        Me.trkKriteria4Alternatif3Alternatif5.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria4alternatif3alternatif5
        '
        'trkKriteria4Alternatif3Alternatif4
        '
        Me.trkKriteria4Alternatif3Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria4alternatif3alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria4Alternatif3Alternatif4.Location = New System.Drawing.Point(75, 249)
        Me.trkKriteria4Alternatif3Alternatif4.Maximum = 17
        Me.trkKriteria4Alternatif3Alternatif4.Minimum = 1
        Me.trkKriteria4Alternatif3Alternatif4.Name = "trkKriteria4Alternatif3Alternatif4"
        Me.trkKriteria4Alternatif3Alternatif4.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria4Alternatif3Alternatif4.TabIndex = 37
        Me.trkKriteria4Alternatif3Alternatif4.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria4alternatif3alternatif4
        '
        'lblKriteria4Alternatif2Alternatif5
        '
        Me.lblKriteria4Alternatif2Alternatif5.AutoSize = True
        Me.lblKriteria4Alternatif2Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria4Alternatif2Alternatif5.Location = New System.Drawing.Point(597, 116)
        Me.lblKriteria4Alternatif2Alternatif5.Name = "lblKriteria4Alternatif2Alternatif5"
        Me.lblKriteria4Alternatif2Alternatif5.Size = New System.Drawing.Size(21, 13)
        Me.lblKriteria4Alternatif2Alternatif5.TabIndex = 36
        Me.lblKriteria4Alternatif2Alternatif5.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif5
        '
        'lblKriteria4Alternatif2Alternatif4
        '
        Me.lblKriteria4Alternatif2Alternatif4.AutoSize = True
        Me.lblKriteria4Alternatif2Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria4Alternatif2Alternatif4.Location = New System.Drawing.Point(597, 65)
        Me.lblKriteria4Alternatif2Alternatif4.Name = "lblKriteria4Alternatif2Alternatif4"
        Me.lblKriteria4Alternatif2Alternatif4.Size = New System.Drawing.Size(24, 13)
        Me.lblKriteria4Alternatif2Alternatif4.TabIndex = 35
        Me.lblKriteria4Alternatif2Alternatif4.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif4
        '
        'trkKriteria4Alternatif2Alternatif5
        '
        Me.trkKriteria4Alternatif2Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria4alternatif2alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria4Alternatif2Alternatif5.Location = New System.Drawing.Point(404, 116)
        Me.trkKriteria4Alternatif2Alternatif5.Maximum = 17
        Me.trkKriteria4Alternatif2Alternatif5.Minimum = 1
        Me.trkKriteria4Alternatif2Alternatif5.Name = "trkKriteria4Alternatif2Alternatif5"
        Me.trkKriteria4Alternatif2Alternatif5.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria4Alternatif2Alternatif5.TabIndex = 34
        Me.trkKriteria4Alternatif2Alternatif5.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria4alternatif2alternatif5
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label78.Location = New System.Drawing.Point(597, 14)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(32, 13)
        Me.Label78.TabIndex = 33
        Me.Label78.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif3
        '
        'trkKriteria4Alternatif2Alternatif4
        '
        Me.trkKriteria4Alternatif2Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria4alternatif2alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria4Alternatif2Alternatif4.Location = New System.Drawing.Point(404, 65)
        Me.trkKriteria4Alternatif2Alternatif4.Maximum = 17
        Me.trkKriteria4Alternatif2Alternatif4.Minimum = 1
        Me.trkKriteria4Alternatif2Alternatif4.Name = "trkKriteria4Alternatif2Alternatif4"
        Me.trkKriteria4Alternatif2Alternatif4.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria4Alternatif2Alternatif4.TabIndex = 32
        Me.trkKriteria4Alternatif2Alternatif4.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria4alternatif2alternatif4
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif2", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label79.Location = New System.Drawing.Point(380, 14)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(18, 13)
        Me.Label79.TabIndex = 31
        Me.Label79.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif2
        '
        'trkKriteria4Alternatif2Alternatif3
        '
        Me.trkKriteria4Alternatif2Alternatif3.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria4alternatif2alternatif3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria4Alternatif2Alternatif3.Location = New System.Drawing.Point(404, 14)
        Me.trkKriteria4Alternatif2Alternatif3.Maximum = 17
        Me.trkKriteria4Alternatif2Alternatif3.Minimum = 1
        Me.trkKriteria4Alternatif2Alternatif3.Name = "trkKriteria4Alternatif2Alternatif3"
        Me.trkKriteria4Alternatif2Alternatif3.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria4Alternatif2Alternatif3.TabIndex = 30
        Me.trkKriteria4Alternatif2Alternatif3.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria4alternatif2alternatif3
        '
        'lblKriteria4Alternatif1Alternatif5
        '
        Me.lblKriteria4Alternatif1Alternatif5.AutoSize = True
        Me.lblKriteria4Alternatif1Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria4Alternatif1Alternatif5.Location = New System.Drawing.Point(279, 167)
        Me.lblKriteria4Alternatif1Alternatif5.Name = "lblKriteria4Alternatif1Alternatif5"
        Me.lblKriteria4Alternatif1Alternatif5.Size = New System.Drawing.Size(21, 13)
        Me.lblKriteria4Alternatif1Alternatif5.TabIndex = 23
        Me.lblKriteria4Alternatif1Alternatif5.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif5
        '
        'trkKriteria4Alternatif1Alternatif5
        '
        Me.trkKriteria4Alternatif1Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria4alternatif1alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria4Alternatif1Alternatif5.Location = New System.Drawing.Point(75, 167)
        Me.trkKriteria4Alternatif1Alternatif5.Maximum = 17
        Me.trkKriteria4Alternatif1Alternatif5.Minimum = 1
        Me.trkKriteria4Alternatif1Alternatif5.Name = "trkKriteria4Alternatif1Alternatif5"
        Me.trkKriteria4Alternatif1Alternatif5.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria4Alternatif1Alternatif5.TabIndex = 22
        Me.trkKriteria4Alternatif1Alternatif5.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria4alternatif1alternatif5
        '
        'lblKriteria4Alternatif1Alternatif4
        '
        Me.lblKriteria4Alternatif1Alternatif4.AutoSize = True
        Me.lblKriteria4Alternatif1Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria4Alternatif1Alternatif4.Location = New System.Drawing.Point(279, 116)
        Me.lblKriteria4Alternatif1Alternatif4.Name = "lblKriteria4Alternatif1Alternatif4"
        Me.lblKriteria4Alternatif1Alternatif4.Size = New System.Drawing.Size(24, 13)
        Me.lblKriteria4Alternatif1Alternatif4.TabIndex = 21
        Me.lblKriteria4Alternatif1Alternatif4.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif4
        '
        'trkKriteria4Alternatif1Alternatif4
        '
        Me.trkKriteria4Alternatif1Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria4alternatif1alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria4Alternatif1Alternatif4.Location = New System.Drawing.Point(75, 116)
        Me.trkKriteria4Alternatif1Alternatif4.Maximum = 17
        Me.trkKriteria4Alternatif1Alternatif4.Minimum = 1
        Me.trkKriteria4Alternatif1Alternatif4.Name = "trkKriteria4Alternatif1Alternatif4"
        Me.trkKriteria4Alternatif1Alternatif4.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria4Alternatif1Alternatif4.TabIndex = 20
        Me.trkKriteria4Alternatif1Alternatif4.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria4alternatif1alternatif4
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label36.Location = New System.Drawing.Point(279, 65)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(32, 13)
        Me.Label36.TabIndex = 19
        Me.Label36.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif3
        '
        'trkKriteria4Alternatif1Alternatif3
        '
        Me.trkKriteria4Alternatif1Alternatif3.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria4alternatif1alternatif3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria4Alternatif1Alternatif3.Location = New System.Drawing.Point(75, 65)
        Me.trkKriteria4Alternatif1Alternatif3.Maximum = 17
        Me.trkKriteria4Alternatif1Alternatif3.Minimum = 1
        Me.trkKriteria4Alternatif1Alternatif3.Name = "trkKriteria4Alternatif1Alternatif3"
        Me.trkKriteria4Alternatif1Alternatif3.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria4Alternatif1Alternatif3.TabIndex = 18
        Me.trkKriteria4Alternatif1Alternatif3.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria4alternatif1alternatif3
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif2", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label37.Location = New System.Drawing.Point(279, 14)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(18, 13)
        Me.Label37.TabIndex = 17
        Me.Label37.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif2
        '
        'trkKriteria4Alternatif1Alternatif2
        '
        Me.trkKriteria4Alternatif1Alternatif2.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria4alternatif1alternatif2", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria4Alternatif1Alternatif2.Location = New System.Drawing.Point(75, 14)
        Me.trkKriteria4Alternatif1Alternatif2.Maximum = 17
        Me.trkKriteria4Alternatif1Alternatif2.Minimum = 1
        Me.trkKriteria4Alternatif1Alternatif2.Name = "trkKriteria4Alternatif1Alternatif2"
        Me.trkKriteria4Alternatif1Alternatif2.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria4Alternatif1Alternatif2.TabIndex = 16
        Me.trkKriteria4Alternatif1Alternatif2.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria4alternatif1alternatif2
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif1", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label38.Location = New System.Drawing.Point(6, 14)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(24, 13)
        Me.Label38.TabIndex = 15
        Me.Label38.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif1
        '
        'tabKriteria5
        '
        Me.tabKriteria5.Controls.Add(Me.lblKriteria5Alternatif4Alternatif5)
        Me.tabKriteria5.Controls.Add(Me.lblKriteria5Alternatif4)
        Me.tabKriteria5.Controls.Add(Me.trkKriteria5Alternatif4Alternatif5)
        Me.tabKriteria5.Controls.Add(Me.lblKriteria5Alternatif3Alternatif5)
        Me.tabKriteria5.Controls.Add(Me.lblKriteria5Alternatif3Alternatif4)
        Me.tabKriteria5.Controls.Add(Me.lblKriteria5Alternatif3)
        Me.tabKriteria5.Controls.Add(Me.trkKriteria5Alternatif3Alternatif5)
        Me.tabKriteria5.Controls.Add(Me.trkKriteria5Alternatif3Alternatif4)
        Me.tabKriteria5.Controls.Add(Me.lblKriteria5Alternatif2Alternatif5)
        Me.tabKriteria5.Controls.Add(Me.lblKriteria5Alternatif2Alternatif4)
        Me.tabKriteria5.Controls.Add(Me.trkKriteria5Alternatif2Alternatif5)
        Me.tabKriteria5.Controls.Add(Me.Label87)
        Me.tabKriteria5.Controls.Add(Me.trkKriteria5Alternatif2Alternatif4)
        Me.tabKriteria5.Controls.Add(Me.Label88)
        Me.tabKriteria5.Controls.Add(Me.trkKriteria5Alternatif2Alternatif3)
        Me.tabKriteria5.Controls.Add(Me.lblKriteria5Alternatif1Alternatif5)
        Me.tabKriteria5.Controls.Add(Me.trkKriteria5Alternatif1Alternatif5)
        Me.tabKriteria5.Controls.Add(Me.lblKriteria5Alternatif1Alternatif4)
        Me.tabKriteria5.Controls.Add(Me.trkKriteria5Alternatif1Alternatif4)
        Me.tabKriteria5.Controls.Add(Me.Label41)
        Me.tabKriteria5.Controls.Add(Me.trkKriteria5Alternatif1Alternatif3)
        Me.tabKriteria5.Controls.Add(Me.Label42)
        Me.tabKriteria5.Controls.Add(Me.trkKriteria5Alternatif1Alternatif2)
        Me.tabKriteria5.Controls.Add(Me.Label43)
        Me.tabKriteria5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.tabKriteria5.Location = New System.Drawing.Point(4, 22)
        Me.tabKriteria5.Name = "tabKriteria5"
        Me.tabKriteria5.Size = New System.Drawing.Size(847, 318)
        Me.tabKriteria5.TabIndex = 4
        Me.tabKriteria5.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria5
        Me.tabKriteria5.UseVisualStyleBackColor = True
        '
        'lblKriteria5Alternatif4Alternatif5
        '
        Me.lblKriteria5Alternatif4Alternatif5.AutoSize = True
        Me.lblKriteria5Alternatif4Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria5Alternatif4Alternatif5.Location = New System.Drawing.Point(597, 249)
        Me.lblKriteria5Alternatif4Alternatif5.Name = "lblKriteria5Alternatif4Alternatif5"
        Me.lblKriteria5Alternatif4Alternatif5.Size = New System.Drawing.Size(21, 13)
        Me.lblKriteria5Alternatif4Alternatif5.TabIndex = 44
        Me.lblKriteria5Alternatif4Alternatif5.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif5
        '
        'lblKriteria5Alternatif4
        '
        Me.lblKriteria5Alternatif4.AutoSize = True
        Me.lblKriteria5Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria5Alternatif4.Location = New System.Drawing.Point(374, 249)
        Me.lblKriteria5Alternatif4.Name = "lblKriteria5Alternatif4"
        Me.lblKriteria5Alternatif4.Size = New System.Drawing.Size(24, 13)
        Me.lblKriteria5Alternatif4.TabIndex = 43
        Me.lblKriteria5Alternatif4.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif4
        '
        'trkKriteria5Alternatif4Alternatif5
        '
        Me.trkKriteria5Alternatif4Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria5alternatif4alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria5Alternatif4Alternatif5.Location = New System.Drawing.Point(404, 249)
        Me.trkKriteria5Alternatif4Alternatif5.Maximum = 17
        Me.trkKriteria5Alternatif4Alternatif5.Minimum = 1
        Me.trkKriteria5Alternatif4Alternatif5.Name = "trkKriteria5Alternatif4Alternatif5"
        Me.trkKriteria5Alternatif4Alternatif5.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria5Alternatif4Alternatif5.TabIndex = 42
        Me.trkKriteria5Alternatif4Alternatif5.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria5alternatif4alternatif5
        '
        'lblKriteria5Alternatif3Alternatif5
        '
        Me.lblKriteria5Alternatif3Alternatif5.AutoSize = True
        Me.lblKriteria5Alternatif3Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria5Alternatif3Alternatif5.Location = New System.Drawing.Point(279, 300)
        Me.lblKriteria5Alternatif3Alternatif5.Name = "lblKriteria5Alternatif3Alternatif5"
        Me.lblKriteria5Alternatif3Alternatif5.Size = New System.Drawing.Size(21, 13)
        Me.lblKriteria5Alternatif3Alternatif5.TabIndex = 41
        Me.lblKriteria5Alternatif3Alternatif5.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif5
        '
        'lblKriteria5Alternatif3Alternatif4
        '
        Me.lblKriteria5Alternatif3Alternatif4.AutoSize = True
        Me.lblKriteria5Alternatif3Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria5Alternatif3Alternatif4.Location = New System.Drawing.Point(279, 249)
        Me.lblKriteria5Alternatif3Alternatif4.Name = "lblKriteria5Alternatif3Alternatif4"
        Me.lblKriteria5Alternatif3Alternatif4.Size = New System.Drawing.Size(24, 13)
        Me.lblKriteria5Alternatif3Alternatif4.TabIndex = 40
        Me.lblKriteria5Alternatif3Alternatif4.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif4
        '
        'lblKriteria5Alternatif3
        '
        Me.lblKriteria5Alternatif3.AutoSize = True
        Me.lblKriteria5Alternatif3.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria5Alternatif3.Location = New System.Drawing.Point(6, 249)
        Me.lblKriteria5Alternatif3.Name = "lblKriteria5Alternatif3"
        Me.lblKriteria5Alternatif3.Size = New System.Drawing.Size(32, 13)
        Me.lblKriteria5Alternatif3.TabIndex = 39
        Me.lblKriteria5Alternatif3.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif3
        '
        'trkKriteria5Alternatif3Alternatif5
        '
        Me.trkKriteria5Alternatif3Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria5alternatif3alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria5Alternatif3Alternatif5.Location = New System.Drawing.Point(75, 300)
        Me.trkKriteria5Alternatif3Alternatif5.Maximum = 17
        Me.trkKriteria5Alternatif3Alternatif5.Minimum = 1
        Me.trkKriteria5Alternatif3Alternatif5.Name = "trkKriteria5Alternatif3Alternatif5"
        Me.trkKriteria5Alternatif3Alternatif5.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria5Alternatif3Alternatif5.TabIndex = 38
        Me.trkKriteria5Alternatif3Alternatif5.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria5alternatif3alternatif5
        '
        'trkKriteria5Alternatif3Alternatif4
        '
        Me.trkKriteria5Alternatif3Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria5alternatif3alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria5Alternatif3Alternatif4.Location = New System.Drawing.Point(75, 249)
        Me.trkKriteria5Alternatif3Alternatif4.Maximum = 17
        Me.trkKriteria5Alternatif3Alternatif4.Minimum = 1
        Me.trkKriteria5Alternatif3Alternatif4.Name = "trkKriteria5Alternatif3Alternatif4"
        Me.trkKriteria5Alternatif3Alternatif4.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria5Alternatif3Alternatif4.TabIndex = 37
        Me.trkKriteria5Alternatif3Alternatif4.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria5alternatif3alternatif4
        '
        'lblKriteria5Alternatif2Alternatif5
        '
        Me.lblKriteria5Alternatif2Alternatif5.AutoSize = True
        Me.lblKriteria5Alternatif2Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria5Alternatif2Alternatif5.Location = New System.Drawing.Point(597, 116)
        Me.lblKriteria5Alternatif2Alternatif5.Name = "lblKriteria5Alternatif2Alternatif5"
        Me.lblKriteria5Alternatif2Alternatif5.Size = New System.Drawing.Size(21, 13)
        Me.lblKriteria5Alternatif2Alternatif5.TabIndex = 36
        Me.lblKriteria5Alternatif2Alternatif5.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif5
        '
        'lblKriteria5Alternatif2Alternatif4
        '
        Me.lblKriteria5Alternatif2Alternatif4.AutoSize = True
        Me.lblKriteria5Alternatif2Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria5Alternatif2Alternatif4.Location = New System.Drawing.Point(597, 65)
        Me.lblKriteria5Alternatif2Alternatif4.Name = "lblKriteria5Alternatif2Alternatif4"
        Me.lblKriteria5Alternatif2Alternatif4.Size = New System.Drawing.Size(24, 13)
        Me.lblKriteria5Alternatif2Alternatif4.TabIndex = 35
        Me.lblKriteria5Alternatif2Alternatif4.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif4
        '
        'trkKriteria5Alternatif2Alternatif5
        '
        Me.trkKriteria5Alternatif2Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria5alternatif2alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria5Alternatif2Alternatif5.Location = New System.Drawing.Point(404, 116)
        Me.trkKriteria5Alternatif2Alternatif5.Maximum = 17
        Me.trkKriteria5Alternatif2Alternatif5.Minimum = 1
        Me.trkKriteria5Alternatif2Alternatif5.Name = "trkKriteria5Alternatif2Alternatif5"
        Me.trkKriteria5Alternatif2Alternatif5.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria5Alternatif2Alternatif5.TabIndex = 34
        Me.trkKriteria5Alternatif2Alternatif5.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria5alternatif2alternatif5
        '
        'Label87
        '
        Me.Label87.AutoSize = True
        Me.Label87.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label87.Location = New System.Drawing.Point(597, 14)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(32, 13)
        Me.Label87.TabIndex = 33
        Me.Label87.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif3
        '
        'trkKriteria5Alternatif2Alternatif4
        '
        Me.trkKriteria5Alternatif2Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria5alternatif2alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria5Alternatif2Alternatif4.Location = New System.Drawing.Point(404, 65)
        Me.trkKriteria5Alternatif2Alternatif4.Maximum = 17
        Me.trkKriteria5Alternatif2Alternatif4.Minimum = 1
        Me.trkKriteria5Alternatif2Alternatif4.Name = "trkKriteria5Alternatif2Alternatif4"
        Me.trkKriteria5Alternatif2Alternatif4.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria5Alternatif2Alternatif4.TabIndex = 32
        Me.trkKriteria5Alternatif2Alternatif4.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria5alternatif2alternatif4
        '
        'Label88
        '
        Me.Label88.AutoSize = True
        Me.Label88.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif2", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label88.Location = New System.Drawing.Point(380, 14)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(18, 13)
        Me.Label88.TabIndex = 31
        Me.Label88.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif2
        '
        'trkKriteria5Alternatif2Alternatif3
        '
        Me.trkKriteria5Alternatif2Alternatif3.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria5alternatif2alternatif3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria5Alternatif2Alternatif3.Location = New System.Drawing.Point(404, 14)
        Me.trkKriteria5Alternatif2Alternatif3.Maximum = 17
        Me.trkKriteria5Alternatif2Alternatif3.Minimum = 1
        Me.trkKriteria5Alternatif2Alternatif3.Name = "trkKriteria5Alternatif2Alternatif3"
        Me.trkKriteria5Alternatif2Alternatif3.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria5Alternatif2Alternatif3.TabIndex = 30
        Me.trkKriteria5Alternatif2Alternatif3.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria5alternatif2alternatif3
        '
        'lblKriteria5Alternatif1Alternatif5
        '
        Me.lblKriteria5Alternatif1Alternatif5.AutoSize = True
        Me.lblKriteria5Alternatif1Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria5Alternatif1Alternatif5.Location = New System.Drawing.Point(279, 167)
        Me.lblKriteria5Alternatif1Alternatif5.Name = "lblKriteria5Alternatif1Alternatif5"
        Me.lblKriteria5Alternatif1Alternatif5.Size = New System.Drawing.Size(21, 13)
        Me.lblKriteria5Alternatif1Alternatif5.TabIndex = 23
        Me.lblKriteria5Alternatif1Alternatif5.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif5
        '
        'trkKriteria5Alternatif1Alternatif5
        '
        Me.trkKriteria5Alternatif1Alternatif5.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria5alternatif1alternatif5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria5Alternatif1Alternatif5.Location = New System.Drawing.Point(75, 167)
        Me.trkKriteria5Alternatif1Alternatif5.Maximum = 17
        Me.trkKriteria5Alternatif1Alternatif5.Minimum = 1
        Me.trkKriteria5Alternatif1Alternatif5.Name = "trkKriteria5Alternatif1Alternatif5"
        Me.trkKriteria5Alternatif1Alternatif5.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria5Alternatif1Alternatif5.TabIndex = 22
        Me.trkKriteria5Alternatif1Alternatif5.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria5alternatif1alternatif5
        '
        'lblKriteria5Alternatif1Alternatif4
        '
        Me.lblKriteria5Alternatif1Alternatif4.AutoSize = True
        Me.lblKriteria5Alternatif1Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblKriteria5Alternatif1Alternatif4.Location = New System.Drawing.Point(279, 116)
        Me.lblKriteria5Alternatif1Alternatif4.Name = "lblKriteria5Alternatif1Alternatif4"
        Me.lblKriteria5Alternatif1Alternatif4.Size = New System.Drawing.Size(24, 13)
        Me.lblKriteria5Alternatif1Alternatif4.TabIndex = 21
        Me.lblKriteria5Alternatif1Alternatif4.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif4
        '
        'trkKriteria5Alternatif1Alternatif4
        '
        Me.trkKriteria5Alternatif1Alternatif4.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria5alternatif1alternatif4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria5Alternatif1Alternatif4.Location = New System.Drawing.Point(75, 116)
        Me.trkKriteria5Alternatif1Alternatif4.Maximum = 17
        Me.trkKriteria5Alternatif1Alternatif4.Minimum = 1
        Me.trkKriteria5Alternatif1Alternatif4.Name = "trkKriteria5Alternatif1Alternatif4"
        Me.trkKriteria5Alternatif1Alternatif4.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria5Alternatif1Alternatif4.TabIndex = 20
        Me.trkKriteria5Alternatif1Alternatif4.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria5alternatif1alternatif4
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label41.Location = New System.Drawing.Point(279, 65)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(32, 13)
        Me.Label41.TabIndex = 19
        Me.Label41.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif3
        '
        'trkKriteria5Alternatif1Alternatif3
        '
        Me.trkKriteria5Alternatif1Alternatif3.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria5alternatif1alternatif3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria5Alternatif1Alternatif3.Location = New System.Drawing.Point(75, 65)
        Me.trkKriteria5Alternatif1Alternatif3.Maximum = 17
        Me.trkKriteria5Alternatif1Alternatif3.Minimum = 1
        Me.trkKriteria5Alternatif1Alternatif3.Name = "trkKriteria5Alternatif1Alternatif3"
        Me.trkKriteria5Alternatif1Alternatif3.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria5Alternatif1Alternatif3.TabIndex = 18
        Me.trkKriteria5Alternatif1Alternatif3.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria5alternatif1alternatif3
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif2", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label42.Location = New System.Drawing.Point(279, 14)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(18, 13)
        Me.Label42.TabIndex = 17
        Me.Label42.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif2
        '
        'trkKriteria5Alternatif1Alternatif2
        '
        Me.trkKriteria5Alternatif1Alternatif2.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "kriteria5alternatif1alternatif2", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.trkKriteria5Alternatif1Alternatif2.Location = New System.Drawing.Point(75, 14)
        Me.trkKriteria5Alternatif1Alternatif2.Maximum = 17
        Me.trkKriteria5Alternatif1Alternatif2.Minimum = 1
        Me.trkKriteria5Alternatif1Alternatif2.Name = "trkKriteria5Alternatif1Alternatif2"
        Me.trkKriteria5Alternatif1Alternatif2.Size = New System.Drawing.Size(187, 42)
        Me.trkKriteria5Alternatif1Alternatif2.TabIndex = 16
        Me.trkKriteria5Alternatif1Alternatif2.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.kriteria5alternatif1alternatif2
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "alternatif1", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Label43.Location = New System.Drawing.Point(6, 14)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(24, 13)
        Me.Label43.TabIndex = 15
        Me.Label43.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.alternatif1
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lblNilai)
        Me.GroupBox1.Controls.Add(Me.TextBox1)
        Me.GroupBox1.Controls.Add(Me.Label89)
        Me.GroupBox1.Controls.Add(Me.updnJumlahAlternatif)
        Me.GroupBox1.Controls.Add(Me.updnJumlahKriteria)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Top
        Me.GroupBox1.Location = New System.Drawing.Point(0, 24)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(869, 110)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Pengaturan Utama"
        '
        'lblNilai
        '
        Me.lblNilai.AutoSize = True
        Me.lblNilai.Location = New System.Drawing.Point(172, 56)
        Me.lblNilai.Name = "lblNilai"
        Me.lblNilai.Size = New System.Drawing.Size(39, 13)
        Me.lblNilai.TabIndex = 10
        Me.lblNilai.Text = "Label5"
        '
        'TextBox1
        '
        Me.TextBox1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "TitleModelAHP", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.TextBox1.Location = New System.Drawing.Point(112, 22)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(449, 20)
        Me.TextBox1.TabIndex = 9
        Me.TextBox1.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.TitleModelAHP
        '
        'Label89
        '
        Me.Label89.AutoSize = True
        Me.Label89.Location = New System.Drawing.Point(18, 22)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(87, 13)
        Me.Label89.TabIndex = 8
        Me.Label89.Text = "Titel Perhitungan"
        '
        'updnJumlahAlternatif
        '
        Me.updnJumlahAlternatif.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "jumlahAlternatif", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.updnJumlahAlternatif.Location = New System.Drawing.Point(111, 76)
        Me.updnJumlahAlternatif.Maximum = New Decimal(New Integer() {5, 0, 0, 0})
        Me.updnJumlahAlternatif.Minimum = New Decimal(New Integer() {3, 0, 0, 0})
        Me.updnJumlahAlternatif.Name = "updnJumlahAlternatif"
        Me.updnJumlahAlternatif.Size = New System.Drawing.Size(54, 20)
        Me.updnJumlahAlternatif.TabIndex = 7
        Me.updnJumlahAlternatif.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.jumlahAlternatif
        '
        'updnJumlahKriteria
        '
        Me.updnJumlahKriteria.DataBindings.Add(New System.Windows.Forms.Binding("Value", Global.PemilihanUniversitasAHP.My.MySettings.Default, "jumlahKriteria", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.updnJumlahKriteria.Location = New System.Drawing.Point(111, 50)
        Me.updnJumlahKriteria.Maximum = New Decimal(New Integer() {5, 0, 0, 0})
        Me.updnJumlahKriteria.Minimum = New Decimal(New Integer() {3, 0, 0, 0})
        Me.updnJumlahKriteria.Name = "updnJumlahKriteria"
        Me.updnJumlahKriteria.Size = New System.Drawing.Size(54, 20)
        Me.updnJumlahKriteria.TabIndex = 6
        Me.updnJumlahKriteria.Value = Global.PemilihanUniversitasAHP.My.MySettings.Default.jumlahKriteria
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(18, 78)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(84, 13)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "Jumlah Alternatif"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(18, 52)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(75, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Jumlah Kriteria"
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.Label90)
        Me.Panel1.Location = New System.Drawing.Point(0, 508)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(869, 88)
        Me.Panel1.TabIndex = 7
        '
        'Label90
        '
        Me.Label90.AutoSize = True
        Me.Label90.Location = New System.Drawing.Point(4, 12)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(91, 13)
        Me.Label90.TabIndex = 0
        Me.Label90.Text = "Ranking Alternatif"
        '
        'DataSet1
        '
        Me.DataSet1.DataSetName = "DataSet"
        Me.DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'FormUtama
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(869, 596)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.PemilihanUniversitasAHP.My.MySettings.Default, "TitleModelAHP", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "FormUtama"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = Global.PemilihanUniversitasAHP.My.MySettings.Default.TitleModelAHP
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.trckKriteria4Kriteria5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trckKriteria2Kriteria5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trckKriteria3Kriteria5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trckKriteria3Kriteria4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trckKriteria2Kriteria4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trckKriteria2Kriteria3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trckKriteria1Kriteria5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trckKriteria1Kriteria4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trckKriteria1Kriteria3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trckKriteria1Kriteria2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage7.ResumeLayout(False)
        Me.tabCtlAlternatif.ResumeLayout(False)
        Me.TabPage8.ResumeLayout(False)
        Me.TabPage8.PerformLayout()
        CType(Me.trkKriteria1Alternatif4Alternatif5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria1Alternatif3Alternatif5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria1Alternatif3Alternatif4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria1Alternatif2Alternatif5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria1Alternatif2Alternatif4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria1Alternatif2Alternatif3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria1Alternatif1Alternatif5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria1Alternatif1Alternatif4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria1Alternatif1Alternatif3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria1Alternatif1Alternatif2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage9.ResumeLayout(False)
        Me.TabPage9.PerformLayout()
        CType(Me.trkKriteria2Alternatif4Alternatif5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria2Alternatif3Alternatif5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria2Alternatif3Alternatif4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria2Alternatif2Alternatif5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria2Alternatif2Alternatif4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria2Alternatif2Alternatif3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria2Alternatif1Alternatif5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria2Alternatif1Alternatif4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria2Alternatif1Alternatif3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria2Alternatif1Alternatif2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage10.ResumeLayout(False)
        Me.TabPage10.PerformLayout()
        CType(Me.trkKriteria3Alternatif4Alternatif5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria3Alternatif3Alternatif5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria3Alternatif3Alternatif4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria3Alternatif2Alternatif5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria3Alternatif2Alternatif4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria3Alternatif2Alternatif3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria3Alternatif1Alternatif5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria3Alternatif1Alternatif4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria3Alternatif1Alternatif3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria3Alternatif1Alternatif2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabKriteria4.ResumeLayout(False)
        Me.tabKriteria4.PerformLayout()
        CType(Me.trkKriteria4Alternatif4Alternatif5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria4Alternatif3Alternatif5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria4Alternatif3Alternatif4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria4Alternatif2Alternatif5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria4Alternatif2Alternatif4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria4Alternatif2Alternatif3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria4Alternatif1Alternatif5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria4Alternatif1Alternatif4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria4Alternatif1Alternatif3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria4Alternatif1Alternatif2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabKriteria5.ResumeLayout(False)
        Me.tabKriteria5.PerformLayout()
        CType(Me.trkKriteria5Alternatif4Alternatif5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria5Alternatif3Alternatif5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria5Alternatif3Alternatif4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria5Alternatif2Alternatif5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria5Alternatif2Alternatif4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria5Alternatif2Alternatif3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria5Alternatif1Alternatif5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria5Alternatif1Alternatif4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria5Alternatif1Alternatif3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkKriteria5Alternatif1Alternatif2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.updnJumlahAlternatif, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.updnJumlahKriteria, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.DataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtAlternatif5 As System.Windows.Forms.TextBox
    Friend WithEvents txtAlternatif4 As System.Windows.Forms.TextBox
    Friend WithEvents txtAlternatif3 As System.Windows.Forms.TextBox
    Friend WithEvents txtAlternatif2 As System.Windows.Forms.TextBox
    Friend WithEvents txtAlternatif1 As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtKriteria5 As System.Windows.Forms.TextBox
    Friend WithEvents txtKriteria4 As System.Windows.Forms.TextBox
    Friend WithEvents txtKriteria3 As System.Windows.Forms.TextBox
    Friend WithEvents txtKriteria2 As System.Windows.Forms.TextBox
    Friend WithEvents txtKriteria1 As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents updnJumlahKriteria As System.Windows.Forms.NumericUpDown
    Friend WithEvents updnJumlahAlternatif As System.Windows.Forms.NumericUpDown
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents lblKriteria2Kriteria5 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria3Kriteria5 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria3Kriteria4 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria3 As System.Windows.Forms.Label
    Friend WithEvents trckKriteria3Kriteria5 As System.Windows.Forms.TrackBar
    Friend WithEvents trckKriteria3Kriteria4 As System.Windows.Forms.TrackBar
    Friend WithEvents lblKriteria4Kriteria5 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria4 As System.Windows.Forms.Label
    Friend WithEvents trckKriteria4Kriteria5 As System.Windows.Forms.TrackBar
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents tabCtlAlternatif As System.Windows.Forms.TabControl
    Friend WithEvents TabPage8 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage9 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage10 As System.Windows.Forms.TabPage
    Friend WithEvents tabKriteria4 As System.Windows.Forms.TabPage
    Friend WithEvents tabKriteria5 As System.Windows.Forms.TabPage
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria1Alternatif1Alternatif2 As System.Windows.Forms.TrackBar
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria1Alternatif1Alternatif5 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria1Alternatif1Alternatif5 As System.Windows.Forms.TrackBar
    Friend WithEvents lblKriteria1Alternatif1Alternatif4 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria1Alternatif1Alternatif4 As System.Windows.Forms.TrackBar
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria1Alternatif1Alternatif3 As System.Windows.Forms.TrackBar
    Friend WithEvents lblKriteria2Alternatif1Alternatif5 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria2Alternatif1Alternatif4 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria3Alternatif1Alternatif5 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria3Alternatif1Alternatif5 As System.Windows.Forms.TrackBar
    Friend WithEvents lblKriteria3Alternatif1Alternatif4 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria3Alternatif1Alternatif4 As System.Windows.Forms.TrackBar
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria3Alternatif1Alternatif3 As System.Windows.Forms.TrackBar
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria3Alternatif1Alternatif2 As System.Windows.Forms.TrackBar
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria4Alternatif1Alternatif5 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria4Alternatif1Alternatif5 As System.Windows.Forms.TrackBar
    Friend WithEvents lblKriteria4Alternatif1Alternatif4 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria4Alternatif1Alternatif4 As System.Windows.Forms.TrackBar
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria4Alternatif1Alternatif3 As System.Windows.Forms.TrackBar
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria4Alternatif1Alternatif2 As System.Windows.Forms.TrackBar
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria5Alternatif1Alternatif5 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria5Alternatif1Alternatif5 As System.Windows.Forms.TrackBar
    Friend WithEvents lblKriteria5Alternatif1Alternatif4 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria5Alternatif1Alternatif4 As System.Windows.Forms.TrackBar
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria5Alternatif1Alternatif3 As System.Windows.Forms.TrackBar
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria5Alternatif1Alternatif2 As System.Windows.Forms.TrackBar
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria2Alternatif1Alternatif5 As System.Windows.Forms.TrackBar
    Friend WithEvents trkKriteria2Alternatif1Alternatif4 As System.Windows.Forms.TrackBar
    Friend WithEvents trkKriteria2Alternatif1Alternatif3 As System.Windows.Forms.TrackBar
    Friend WithEvents trkKriteria2Alternatif1Alternatif2 As System.Windows.Forms.TrackBar
    Friend WithEvents lblKriteria1Kriteria5 As System.Windows.Forms.Label
    Friend WithEvents trckKriteria1Kriteria5 As System.Windows.Forms.TrackBar
    Friend WithEvents lblKriteria1Kriteria4 As System.Windows.Forms.Label
    Friend WithEvents trckKriteria1Kriteria4 As System.Windows.Forms.TrackBar
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents trckKriteria1Kriteria3 As System.Windows.Forms.TrackBar
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents trckKriteria1Kriteria2 As System.Windows.Forms.TrackBar
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria2Kriteria4 As System.Windows.Forms.Label
    Friend WithEvents trckKriteria2Kriteria5 As System.Windows.Forms.TrackBar
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents trckKriteria2Kriteria4 As System.Windows.Forms.TrackBar
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents trckKriteria2Kriteria3 As System.Windows.Forms.TrackBar
    Friend WithEvents lblKriteria1Alternatif2Alternatif5 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria1Alternatif2Alternatif4 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria1Alternatif2Alternatif5 As System.Windows.Forms.TrackBar
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria1Alternatif2Alternatif4 As System.Windows.Forms.TrackBar
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria1Alternatif2Alternatif3 As System.Windows.Forms.TrackBar
    Friend WithEvents lblKriteria1Alternatif4Alternatif5 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria1Alternatif4 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria1Alternatif4Alternatif5 As System.Windows.Forms.TrackBar
    Friend WithEvents lblKriteria1Alternatif3Alternatif5 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria1Alternatif3Alternatif4 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria1Alternatif3 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria1Alternatif3Alternatif5 As System.Windows.Forms.TrackBar
    Friend WithEvents trkKriteria1Alternatif3Alternatif4 As System.Windows.Forms.TrackBar
    Friend WithEvents lblKriteria2Alternatif4Alternatif5 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria2Alternatif4 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria2Alternatif4Alternatif5 As System.Windows.Forms.TrackBar
    Friend WithEvents lblKriteria2Alternatif3Alternatif5 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria2Alternatif3Alternatif4 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria2Alternatif3 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria2Alternatif3Alternatif5 As System.Windows.Forms.TrackBar
    Friend WithEvents trkKriteria2Alternatif3Alternatif4 As System.Windows.Forms.TrackBar
    Friend WithEvents lblKriteria2Alternatif2Alternatif5 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria2Alternatif2Alternatif4 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria2Alternatif2Alternatif5 As System.Windows.Forms.TrackBar
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria2Alternatif2Alternatif4 As System.Windows.Forms.TrackBar
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria2Alternatif2Alternatif3 As System.Windows.Forms.TrackBar
    Friend WithEvents lblKriteria3Alternatif4Alternatif5 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria3Alternatif4 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria3Alternatif4Alternatif5 As System.Windows.Forms.TrackBar
    Friend WithEvents lblKriteria3Alternatif3Alternatif5 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria3Alternatif3Alternatif4 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria3Alternatif3 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria3Alternatif3Alternatif5 As System.Windows.Forms.TrackBar
    Friend WithEvents trkKriteria3Alternatif3Alternatif4 As System.Windows.Forms.TrackBar
    Friend WithEvents lblKriteria3Alternatif2Alternatif5 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria3Alternatif2Alternatif4 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria3Alternatif2Alternatif5 As System.Windows.Forms.TrackBar
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria3Alternatif2Alternatif4 As System.Windows.Forms.TrackBar
    Friend WithEvents Label70 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria3Alternatif2Alternatif3 As System.Windows.Forms.TrackBar
    Friend WithEvents lblKriteria4Alternatif4Alternatif5 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria4Alternatif4 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria4Alternatif4Alternatif5 As System.Windows.Forms.TrackBar
    Friend WithEvents lblKriteria4Alternatif3Alternatif5 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria4Alternatif3Alternatif4 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria4Alternatif3 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria4Alternatif3Alternatif5 As System.Windows.Forms.TrackBar
    Friend WithEvents trkKriteria4Alternatif3Alternatif4 As System.Windows.Forms.TrackBar
    Friend WithEvents lblKriteria4Alternatif2Alternatif5 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria4Alternatif2Alternatif4 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria4Alternatif2Alternatif5 As System.Windows.Forms.TrackBar
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria4Alternatif2Alternatif4 As System.Windows.Forms.TrackBar
    Friend WithEvents Label79 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria4Alternatif2Alternatif3 As System.Windows.Forms.TrackBar
    Friend WithEvents lblKriteria5Alternatif4Alternatif5 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria5Alternatif4 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria5Alternatif4Alternatif5 As System.Windows.Forms.TrackBar
    Friend WithEvents lblKriteria5Alternatif3Alternatif5 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria5Alternatif3Alternatif4 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria5Alternatif3 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria5Alternatif3Alternatif5 As System.Windows.Forms.TrackBar
    Friend WithEvents trkKriteria5Alternatif3Alternatif4 As System.Windows.Forms.TrackBar
    Friend WithEvents lblKriteria5Alternatif2Alternatif5 As System.Windows.Forms.Label
    Friend WithEvents lblKriteria5Alternatif2Alternatif4 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria5Alternatif2Alternatif5 As System.Windows.Forms.TrackBar
    Friend WithEvents Label87 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria5Alternatif2Alternatif4 As System.Windows.Forms.TrackBar
    Friend WithEvents Label88 As System.Windows.Forms.Label
    Friend WithEvents trkKriteria5Alternatif2Alternatif3 As System.Windows.Forms.TrackBar
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label89 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label90 As System.Windows.Forms.Label
    Friend WithEvents lblNilai As System.Windows.Forms.Label
    Friend WithEvents DataSet1 As PemilihanUniversitasAHP.DataSet

End Class
