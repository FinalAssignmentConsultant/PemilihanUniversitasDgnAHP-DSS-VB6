﻿Public Class FormUtama
    Dim MatrixKriteria(,) As Single = New Single(4, 4) {}
    Dim MatrixKriteria1Alternatif(,) As Single = New Single(4, 4) {}
    Dim MatrixKriteria2Alternatif(,) As Single = New Single(4, 4) {}
    Dim MatrixKriteria3Alternatif(,) As Single = New Single(4, 4) {}
    Dim MatrixKriteria4Alternatif(,) As Single = New Single(4, 4) {}
    Dim MatrixKriteria5Alternatif(,) As Single = New Single(4, 4) {}

    Private Sub AboutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutToolStripMenuItem.Click
        AboutBox.ShowDialog()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        End
    End Sub
    Private Sub btnAturAHP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        FormPengaturan.ShowDialog()
    End Sub
    Private Sub updnJumlahKriteria_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles updnJumlahKriteria.ValueChanged

        prosesAhpModel()
    End Sub
    Private Sub validateIt()
        txtKriteria1.Visible = False
        txtKriteria2.Visible = False
        txtKriteria3.Visible = False
        txtKriteria4.Visible = False
        txtKriteria5.Visible = False
        Select Case updnJumlahKriteria.Value
            Case 3
                txtKriteria1.Visible = True
                txtKriteria2.Visible = True
                txtKriteria3.Visible = True
            Case 4
                txtKriteria1.Visible = True
                txtKriteria2.Visible = True
                txtKriteria3.Visible = True
                txtKriteria4.Visible = True
            Case 5
                txtKriteria1.Visible = True
                txtKriteria2.Visible = True
                txtKriteria3.Visible = True
                txtKriteria4.Visible = True
                txtKriteria5.Visible = True
        End Select

        txtAlternatif1.Visible = False
        txtAlternatif2.Visible = False
        txtAlternatif3.Visible = False
        txtAlternatif4.Visible = False
        txtAlternatif5.Visible = False

        lblKriteria1Alternatif4.Visible = False
        lblKriteria1Alternatif3.Visible = False
        lblKriteria1Alternatif4Alternatif5.Visible = False

        lblKriteria1Alternatif1Alternatif4.Visible = False
        lblKriteria1Alternatif2Alternatif4.Visible = False
        lblKriteria1Alternatif3Alternatif4.Visible = False

        lblKriteria1Alternatif1Alternatif5.Visible = False
        lblKriteria1Alternatif2Alternatif5.Visible = False
        lblKriteria1Alternatif3Alternatif5.Visible = False
        lblKriteria1Alternatif4Alternatif5.Visible = False

        'kriteria1
        trkKriteria1Alternatif1Alternatif4.Visible = False
        trkKriteria1Alternatif2Alternatif4.Visible = False
        trkKriteria1Alternatif3Alternatif4.Visible = False

        trkKriteria1Alternatif1Alternatif5.Visible = False
        trkKriteria1Alternatif2Alternatif5.Visible = False
        trkKriteria1Alternatif3Alternatif5.Visible = False
        trkKriteria1Alternatif4Alternatif5.Visible = False

        'kriteria2
        trkKriteria2Alternatif1Alternatif4.Visible = False
        trkKriteria2Alternatif2Alternatif4.Visible = False
        trkKriteria2Alternatif3Alternatif4.Visible = False

        trkKriteria2Alternatif1Alternatif5.Visible = False
        trkKriteria2Alternatif2Alternatif5.Visible = False
        trkKriteria2Alternatif3Alternatif5.Visible = False
        trkKriteria2Alternatif4Alternatif5.Visible = False

        lblKriteria2Alternatif1Alternatif4.Visible = False
        lblKriteria2Alternatif2Alternatif4.Visible = False
        lblKriteria2Alternatif3Alternatif4.Visible = False
        lblKriteria2Alternatif3.Visible = False


        lblKriteria2Alternatif4Alternatif5.Visible = False
        lblKriteria2Alternatif1Alternatif5.Visible = False
        lblKriteria2Alternatif2Alternatif5.Visible = False
        lblKriteria2Alternatif3Alternatif5.Visible = False
        lblKriteria2Alternatif4Alternatif5.Visible = False
        lblKriteria2Alternatif1Alternatif5.Visible = False
        lblKriteria2Alternatif4.Visible = False

        'kriteria3
        trkKriteria3Alternatif1Alternatif4.Visible = False
        trkKriteria3Alternatif2Alternatif4.Visible = False
        trkKriteria3Alternatif3Alternatif4.Visible = False

        trkKriteria3Alternatif1Alternatif5.Visible = False
        trkKriteria3Alternatif2Alternatif5.Visible = False
        trkKriteria3Alternatif3Alternatif5.Visible = False
        trkKriteria3Alternatif4Alternatif5.Visible = False

        lblKriteria3Alternatif1Alternatif4.Visible = False
        lblKriteria3Alternatif2Alternatif4.Visible = False
        lblKriteria3Alternatif3Alternatif4.Visible = False
        lblKriteria3Alternatif3.Visible = False


        lblKriteria3Alternatif4Alternatif5.Visible = False
        lblKriteria3Alternatif1Alternatif5.Visible = False
        lblKriteria3Alternatif2Alternatif5.Visible = False
        lblKriteria3Alternatif3Alternatif5.Visible = False
        lblKriteria3Alternatif4Alternatif5.Visible = False
        lblKriteria3Alternatif1Alternatif5.Visible = False
        lblKriteria3Alternatif4.Visible = False

        'kriteria4
        trkKriteria4Alternatif1Alternatif4.Visible = False
        trkKriteria4Alternatif2Alternatif4.Visible = False
        trkKriteria4Alternatif3Alternatif4.Visible = False

        trkKriteria4Alternatif1Alternatif5.Visible = False
        trkKriteria4Alternatif2Alternatif5.Visible = False
        trkKriteria4Alternatif3Alternatif5.Visible = False
        trkKriteria4Alternatif4Alternatif5.Visible = False

        lblKriteria4Alternatif1Alternatif4.Visible = False
        lblKriteria4Alternatif2Alternatif4.Visible = False
        lblKriteria4Alternatif3Alternatif4.Visible = False
        lblKriteria4Alternatif3.Visible = False

        lblKriteria4Alternatif4Alternatif5.Visible = False
        lblKriteria4Alternatif1Alternatif5.Visible = False
        lblKriteria4Alternatif2Alternatif5.Visible = False
        lblKriteria4Alternatif3Alternatif5.Visible = False
        lblKriteria4Alternatif4Alternatif5.Visible = False
        lblKriteria4Alternatif1Alternatif5.Visible = False
        lblKriteria4Alternatif4.Visible = False

        'kriteria5
        trkKriteria5Alternatif1Alternatif4.Visible = False
        trkKriteria5Alternatif2Alternatif4.Visible = False
        trkKriteria5Alternatif3Alternatif4.Visible = False

        trkKriteria5Alternatif1Alternatif5.Visible = False
        trkKriteria5Alternatif2Alternatif5.Visible = False
        trkKriteria5Alternatif3Alternatif5.Visible = False
        trkKriteria5Alternatif4Alternatif5.Visible = False

        lblKriteria5Alternatif1Alternatif4.Visible = False
        lblKriteria5Alternatif2Alternatif4.Visible = False
        lblKriteria5Alternatif3Alternatif4.Visible = False
        lblKriteria5Alternatif3.Visible = False

        lblKriteria5Alternatif4Alternatif5.Visible = False
        lblKriteria5Alternatif1Alternatif5.Visible = False
        lblKriteria5Alternatif2Alternatif5.Visible = False
        lblKriteria5Alternatif3Alternatif5.Visible = False
        lblKriteria5Alternatif4Alternatif5.Visible = False
        lblKriteria5Alternatif1Alternatif5.Visible = False
        lblKriteria5Alternatif4.Visible = False

        Select Case updnJumlahAlternatif.Value
            Case 3
                txtAlternatif1.Visible = True
                txtAlternatif2.Visible = True
                txtAlternatif3.Visible = True
            Case 4
                txtAlternatif1.Visible = True
                txtAlternatif2.Visible = True
                txtAlternatif3.Visible = True
                txtAlternatif4.Visible = True

                lblKriteria1Alternatif3.Visible = True




                'kriteria1
                trkKriteria1Alternatif1Alternatif4.Visible = True
                trkKriteria1Alternatif2Alternatif4.Visible = True
                trkKriteria1Alternatif3Alternatif4.Visible = True

                lblKriteria1Alternatif1Alternatif4.Visible = True
                lblKriteria1Alternatif2Alternatif4.Visible = True
                lblKriteria1Alternatif3Alternatif4.Visible = True

                'kriteria2
                trkKriteria2Alternatif1Alternatif4.Visible = True
                trkKriteria2Alternatif2Alternatif4.Visible = True
                trkKriteria2Alternatif3Alternatif4.Visible = True

                lblKriteria2Alternatif1Alternatif4.Visible = True
                lblKriteria2Alternatif2Alternatif4.Visible = True
                lblKriteria2Alternatif3Alternatif4.Visible = True
                lblKriteria2Alternatif3.Visible = True

                'kriteria3
                trkKriteria3Alternatif1Alternatif4.Visible = True
                trkKriteria3Alternatif2Alternatif4.Visible = True
                trkKriteria3Alternatif3Alternatif4.Visible = True

                lblKriteria3Alternatif1Alternatif4.Visible = True
                lblKriteria3Alternatif2Alternatif4.Visible = True
                lblKriteria3Alternatif3Alternatif4.Visible = True
                lblKriteria3Alternatif3.Visible = True

                'kriteria4
                trkKriteria4Alternatif1Alternatif4.Visible = True
                trkKriteria4Alternatif2Alternatif4.Visible = True
                trkKriteria4Alternatif3Alternatif4.Visible = True

                lblKriteria4Alternatif1Alternatif4.Visible = True
                lblKriteria4Alternatif2Alternatif4.Visible = True
                lblKriteria4Alternatif3Alternatif4.Visible = True
                lblKriteria4Alternatif3.Visible = True

                'kriteria 5
                trkKriteria5Alternatif1Alternatif4.Visible = True
                trkKriteria5Alternatif2Alternatif4.Visible = True
                lblKriteria5Alternatif2Alternatif4.Visible = True
                lblKriteria5Alternatif3Alternatif4.Visible = True
                trkKriteria5Alternatif3Alternatif4.Visible = True
                lblKriteria5Alternatif3.Visible = True
                lblKriteria5Alternatif1Alternatif4.Visible = True
            Case 5
                txtAlternatif1.Visible = True
                txtAlternatif2.Visible = True
                txtAlternatif3.Visible = True
                txtAlternatif4.Visible = True
                txtAlternatif5.Visible = True

                lblKriteria1Alternatif3.Visible = True
                lblKriteria1Alternatif4.Visible = True
                lblKriteria1Alternatif1Alternatif4.Visible = True
                lblKriteria1Alternatif2Alternatif4.Visible = True
                lblKriteria1Alternatif3Alternatif4.Visible = True

                lblKriteria1Alternatif4Alternatif5.Visible = True
                lblKriteria1Alternatif1Alternatif5.Visible = True
                lblKriteria1Alternatif2Alternatif5.Visible = True
                lblKriteria1Alternatif3Alternatif5.Visible = True
                lblKriteria1Alternatif4Alternatif5.Visible = True

                lblKriteria1Alternatif1Alternatif4.Visible = True
                lblKriteria1Alternatif2Alternatif4.Visible = True
                lblKriteria1Alternatif3Alternatif4.Visible = True

                trkKriteria1Alternatif1Alternatif4.Visible = True
                trkKriteria1Alternatif1Alternatif5.Visible = True
                trkKriteria1Alternatif2Alternatif5.Visible = True
                trkKriteria1Alternatif2Alternatif4.Visible = True
                trkKriteria1Alternatif3Alternatif4.Visible = True
                trkKriteria1Alternatif3Alternatif5.Visible = True
                trkKriteria1Alternatif4Alternatif5.Visible = True

                'kriteria2

                lblKriteria2Alternatif4Alternatif5.Visible = True
                lblKriteria2Alternatif1Alternatif5.Visible = True
                lblKriteria2Alternatif2Alternatif5.Visible = True
                lblKriteria2Alternatif3Alternatif5.Visible = True
                lblKriteria2Alternatif4Alternatif5.Visible = True
                lblKriteria2Alternatif1Alternatif5.Visible = True
                lblKriteria2Alternatif4.Visible = True

                trkKriteria2Alternatif1Alternatif5.Visible = True
                trkKriteria2Alternatif2Alternatif5.Visible = True
                trkKriteria2Alternatif3Alternatif5.Visible = True
                trkKriteria2Alternatif4Alternatif5.Visible = True
                trkKriteria2Alternatif1Alternatif4.Visible = True
                trkKriteria2Alternatif2Alternatif4.Visible = True
                lblKriteria2Alternatif2Alternatif4.Visible = True
                lblKriteria2Alternatif3Alternatif4.Visible = True
                trkKriteria2Alternatif3Alternatif4.Visible = True
                lblKriteria2Alternatif3.Visible = True

                'kriteria3

                lblKriteria3Alternatif4Alternatif5.Visible = True
                lblKriteria3Alternatif1Alternatif5.Visible = True
                lblKriteria3Alternatif2Alternatif5.Visible = True
                lblKriteria3Alternatif3Alternatif5.Visible = True
                lblKriteria3Alternatif4Alternatif5.Visible = True
                lblKriteria3Alternatif1Alternatif5.Visible = True
                lblKriteria3Alternatif4.Visible = True

                trkKriteria3Alternatif1Alternatif5.Visible = True
                trkKriteria3Alternatif2Alternatif5.Visible = True
                trkKriteria3Alternatif3Alternatif5.Visible = True
                trkKriteria3Alternatif4Alternatif5.Visible = True
                trkKriteria3Alternatif1Alternatif4.Visible = True
                trkKriteria3Alternatif2Alternatif4.Visible = True
                lblKriteria3Alternatif2Alternatif4.Visible = True
                lblKriteria3Alternatif3Alternatif4.Visible = True
                trkKriteria3Alternatif3Alternatif4.Visible = True
                lblKriteria3Alternatif3.Visible = True

                'kriteria4

                'kriteria4
                trkKriteria4Alternatif1Alternatif4.Visible = True
                trkKriteria4Alternatif2Alternatif4.Visible = True
                trkKriteria4Alternatif3Alternatif4.Visible = True

                lblKriteria4Alternatif1Alternatif4.Visible = True
                lblKriteria4Alternatif2Alternatif4.Visible = True
                lblKriteria4Alternatif3Alternatif4.Visible = True
                lblKriteria4Alternatif3.Visible = True

                lblKriteria4Alternatif4Alternatif5.Visible = True
                lblKriteria4Alternatif1Alternatif5.Visible = True
                lblKriteria4Alternatif2Alternatif5.Visible = True
                lblKriteria4Alternatif3Alternatif5.Visible = True
                lblKriteria4Alternatif4Alternatif5.Visible = True
                lblKriteria4Alternatif1Alternatif5.Visible = True
                lblKriteria4Alternatif4.Visible = True

                trkKriteria4Alternatif1Alternatif5.Visible = True
                trkKriteria4Alternatif2Alternatif5.Visible = True
                trkKriteria4Alternatif3Alternatif5.Visible = True
                trkKriteria4Alternatif4Alternatif5.Visible = True
                trkKriteria4Alternatif1Alternatif4.Visible = True
                trkKriteria4Alternatif2Alternatif4.Visible = True
                lblKriteria4Alternatif2Alternatif4.Visible = True
                lblKriteria4Alternatif3Alternatif4.Visible = True
                trkKriteria4Alternatif3Alternatif4.Visible = True
                lblKriteria4Alternatif3.Visible = True

                'kriteria5

                lblKriteria5Alternatif4Alternatif5.Visible = True
                lblKriteria5Alternatif1Alternatif5.Visible = True
                lblKriteria5Alternatif2Alternatif5.Visible = True
                lblKriteria5Alternatif3Alternatif5.Visible = True
                lblKriteria5Alternatif4Alternatif5.Visible = True
                lblKriteria5Alternatif1Alternatif5.Visible = True
                lblKriteria5Alternatif4.Visible = True

                trkKriteria5Alternatif1Alternatif5.Visible = True
                trkKriteria5Alternatif2Alternatif5.Visible = True
                trkKriteria5Alternatif3Alternatif5.Visible = True
                trkKriteria5Alternatif4Alternatif5.Visible = True
                trkKriteria5Alternatif1Alternatif4.Visible = True
                trkKriteria5Alternatif2Alternatif4.Visible = True
                lblKriteria5Alternatif2Alternatif4.Visible = True
                lblKriteria5Alternatif3Alternatif4.Visible = True
                trkKriteria5Alternatif3Alternatif4.Visible = True
                lblKriteria5Alternatif3.Visible = True
                lblKriteria5Alternatif1Alternatif4.Visible = True
        End Select
        'txtKriteria1.Focus()
    End Sub
    Private Sub updnJumlahAlternatif_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles updnJumlahAlternatif.ValueChanged

        prosesAhpModel()
    End Sub

    Private Sub prosesAhpModel()

        validateIt()

        trckKriteria1Kriteria4.Visible = False
        trckKriteria1Kriteria5.Visible = False

        trckKriteria2Kriteria4.Visible = False
        trckKriteria2Kriteria5.Visible = False

        trckKriteria3Kriteria4.Visible = False
        trckKriteria3Kriteria5.Visible = False

        trckKriteria4Kriteria5.Visible = False

        lblKriteria1Kriteria4.Visible = False
        lblKriteria1Kriteria5.Visible = False

        lblKriteria2Kriteria4.Visible = False
        lblKriteria2Kriteria5.Visible = False

        lblKriteria3.Visible = False
        lblKriteria3Kriteria4.Visible = False
        lblKriteria3Kriteria5.Visible = False

        lblKriteria4.Visible = False
        lblKriteria4Kriteria5.Visible = False


        tabCtlAlternatif.SizeMode = TabSizeMode.Normal
        tabCtlAlternatif.TabPages.Remove(tabKriteria5)
        tabCtlAlternatif.TabPages.Remove(tabKriteria4)
        Select Case updnJumlahKriteria.Value
            Case 4
                trckKriteria1Kriteria4.Visible = True
                trckKriteria2Kriteria4.Visible = True
                trckKriteria3Kriteria4.Visible = True

                lblKriteria3.Visible = True
                lblKriteria1Kriteria4.Visible = True
                lblKriteria2Kriteria4.Visible = True
                lblKriteria3Kriteria4.Visible = True

                tabCtlAlternatif.TabPages.Add(tabKriteria4)
            Case 5
                trckKriteria1Kriteria4.Visible = True
                trckKriteria2Kriteria4.Visible = True
                trckKriteria3Kriteria4.Visible = True

                trckKriteria1Kriteria5.Visible = True
                trckKriteria2Kriteria5.Visible = True
                trckKriteria3Kriteria5.Visible = True
                trckKriteria4Kriteria5.Visible = True

                lblKriteria1Kriteria4.Visible = True
                lblKriteria2Kriteria4.Visible = True
                lblKriteria3.Visible = True
                lblKriteria3Kriteria4.Visible = True

                lblKriteria1Kriteria5.Visible = True
                lblKriteria2Kriteria5.Visible = True
                lblKriteria3Kriteria5.Visible = True
                lblKriteria4.Visible = True
                lblKriteria4Kriteria5.Visible = True

                tabCtlAlternatif.TabPages.Add(tabKriteria4)
                tabCtlAlternatif.TabPages.Add(tabKriteria5)
        End Select

        'pair kriteria
        Module1.pair(MatrixKriteria, trckKriteria1Kriteria2, 0, 1)
        Module1.pair(MatrixKriteria, trckKriteria1Kriteria3, 0, 2)
        Module1.pair(MatrixKriteria, trckKriteria1Kriteria4, 0, 3)
        Module1.pair(MatrixKriteria, trckKriteria1Kriteria5, 0, 4)
        Module1.pair(MatrixKriteria, trckKriteria2Kriteria3, 1, 2)
        Module1.pair(MatrixKriteria, trckKriteria2Kriteria4, 1, 3)
        Module1.pair(MatrixKriteria, trckKriteria2Kriteria5, 1, 4)
        Module1.pair(MatrixKriteria, trckKriteria3Kriteria4, 2, 3)
        Module1.pair(MatrixKriteria, trckKriteria3Kriteria5, 2, 4)
        Module1.pair(MatrixKriteria, trckKriteria4Kriteria5, 2, 4)

        'pair alternatif pada kriteria1
        Module1.pair(MatrixKriteria1Alternatif, trkKriteria1Alternatif1Alternatif2, 0, 1)
        Module1.pair(MatrixKriteria1Alternatif, trkKriteria1Alternatif1Alternatif3, 0, 2)
        Module1.pair(MatrixKriteria1Alternatif, trkKriteria1Alternatif1Alternatif4, 0, 3)
        Module1.pair(MatrixKriteria1Alternatif, trkKriteria1Alternatif1Alternatif5, 0, 4)

        Module1.pair(MatrixKriteria1Alternatif, trkKriteria1Alternatif2Alternatif3, 1, 2)
        Module1.pair(MatrixKriteria1Alternatif, trkKriteria1Alternatif2Alternatif4, 1, 3)
        Module1.pair(MatrixKriteria1Alternatif, trkKriteria1Alternatif2Alternatif5, 1, 4)

        Module1.pair(MatrixKriteria1Alternatif, trkKriteria1Alternatif3Alternatif4, 2, 3)
        Module1.pair(MatrixKriteria1Alternatif, trkKriteria1Alternatif3Alternatif5, 2, 4)

        Module1.pair(MatrixKriteria1Alternatif, trkKriteria1Alternatif4Alternatif5, 3, 4)

        'pair alternatif pada kriteria2
        Module1.pair(MatrixKriteria2Alternatif, trkKriteria2Alternatif1Alternatif2, 0, 1)
        Module1.pair(MatrixKriteria2Alternatif, trkKriteria2Alternatif1Alternatif3, 0, 2)
        Module1.pair(MatrixKriteria2Alternatif, trkKriteria2Alternatif1Alternatif4, 0, 3)
        Module1.pair(MatrixKriteria2Alternatif, trkKriteria2Alternatif1Alternatif5, 0, 4)

        Module1.pair(MatrixKriteria2Alternatif, trkKriteria2Alternatif2Alternatif3, 1, 2)
        Module1.pair(MatrixKriteria2Alternatif, trkKriteria2Alternatif2Alternatif4, 1, 3)
        Module1.pair(MatrixKriteria2Alternatif, trkKriteria2Alternatif2Alternatif5, 1, 4)

        Module1.pair(MatrixKriteria2Alternatif, trkKriteria2Alternatif3Alternatif4, 2, 3)
        Module1.pair(MatrixKriteria2Alternatif, trkKriteria2Alternatif3Alternatif5, 2, 4)

        Module1.pair(MatrixKriteria2Alternatif, trkKriteria2Alternatif4Alternatif5, 3, 4)

        'pair alternatif pada kriteria3
        Module1.pair(MatrixKriteria3Alternatif, trkKriteria3Alternatif1Alternatif2, 0, 1)
        Module1.pair(MatrixKriteria3Alternatif, trkKriteria3Alternatif1Alternatif3, 0, 2)
        Module1.pair(MatrixKriteria3Alternatif, trkKriteria3Alternatif1Alternatif4, 0, 3)
        Module1.pair(MatrixKriteria3Alternatif, trkKriteria3Alternatif1Alternatif5, 0, 4)

        Module1.pair(MatrixKriteria3Alternatif, trkKriteria3Alternatif2Alternatif3, 1, 2)
        Module1.pair(MatrixKriteria3Alternatif, trkKriteria3Alternatif2Alternatif4, 1, 3)
        Module1.pair(MatrixKriteria3Alternatif, trkKriteria3Alternatif2Alternatif5, 1, 4)

        Module1.pair(MatrixKriteria3Alternatif, trkKriteria3Alternatif3Alternatif4, 2, 3)
        Module1.pair(MatrixKriteria3Alternatif, trkKriteria3Alternatif3Alternatif5, 2, 4)

        Module1.pair(MatrixKriteria3Alternatif, trkKriteria3Alternatif4Alternatif5, 3, 4)

        'pair alternatif pada kriteria4
        Module1.pair(MatrixKriteria4Alternatif, trkKriteria4Alternatif1Alternatif2, 0, 1)
        Module1.pair(MatrixKriteria4Alternatif, trkKriteria4Alternatif1Alternatif3, 0, 2)
        Module1.pair(MatrixKriteria4Alternatif, trkKriteria4Alternatif1Alternatif4, 0, 3)
        Module1.pair(MatrixKriteria4Alternatif, trkKriteria4Alternatif1Alternatif5, 0, 4)

        Module1.pair(MatrixKriteria4Alternatif, trkKriteria4Alternatif2Alternatif3, 1, 2)
        Module1.pair(MatrixKriteria4Alternatif, trkKriteria4Alternatif2Alternatif4, 1, 3)
        Module1.pair(MatrixKriteria4Alternatif, trkKriteria4Alternatif2Alternatif5, 1, 4)

        Module1.pair(MatrixKriteria4Alternatif, trkKriteria4Alternatif3Alternatif4, 2, 3)
        Module1.pair(MatrixKriteria4Alternatif, trkKriteria4Alternatif3Alternatif5, 2, 4)

        Module1.pair(MatrixKriteria4Alternatif, trkKriteria4Alternatif4Alternatif5, 3, 4)

        'pair alternatif pada kriteria5
        Module1.pair(MatrixKriteria5Alternatif, trkKriteria5Alternatif1Alternatif2, 0, 1)
        Module1.pair(MatrixKriteria5Alternatif, trkKriteria5Alternatif1Alternatif3, 0, 2)
        Module1.pair(MatrixKriteria5Alternatif, trkKriteria5Alternatif1Alternatif4, 0, 3)
        Module1.pair(MatrixKriteria5Alternatif, trkKriteria5Alternatif1Alternatif5, 0, 4)

        Module1.pair(MatrixKriteria5Alternatif, trkKriteria5Alternatif2Alternatif3, 1, 2)
        Module1.pair(MatrixKriteria5Alternatif, trkKriteria5Alternatif2Alternatif4, 1, 3)
        Module1.pair(MatrixKriteria5Alternatif, trkKriteria5Alternatif2Alternatif5, 1, 4)

        Module1.pair(MatrixKriteria5Alternatif, trkKriteria5Alternatif3Alternatif4, 2, 3)
        Module1.pair(MatrixKriteria5Alternatif, trkKriteria5Alternatif3Alternatif5, 2, 4)

        Module1.pair(MatrixKriteria5Alternatif, trkKriteria5Alternatif4Alternatif5, 3, 4)



        



    End Sub


    Private Sub FormUtama_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        identity(MatrixKriteria, 4)
        identity(MatrixKriteria1Alternatif, 4)
        identity(MatrixKriteria2Alternatif, 4)
        identity(MatrixKriteria3Alternatif, 4)
        identity(MatrixKriteria4Alternatif, 4)
        identity(MatrixKriteria5Alternatif, 4)
        prosesAhpModel()
    End Sub

    Private Sub trckKriteria1Kriteria2_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trckKriteria1Kriteria2.Scroll
        Module1.pair(MatrixKriteria, trckKriteria1Kriteria2, 0, 1)
    End Sub

    Private Sub lblNilai_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblNilai.Click
        DisplayMatrix.Show()
        DisplayMatrix.ShowArray(MatrixKriteria, updnJumlahKriteria.Value - 1)
    End Sub

    Private Sub trckKriteria1Kriteria3_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trckKriteria1Kriteria3.Scroll
        Module1.pair(MatrixKriteria, trckKriteria1Kriteria3, 0, 2)
    End Sub

    Private Sub trckKriteria1Kriteria4_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trckKriteria1Kriteria4.Scroll
        Module1.pair(MatrixKriteria, trckKriteria1Kriteria4, 0, 3)
    End Sub

    Private Sub trckKriteria1Kriteria5_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trckKriteria1Kriteria5.Scroll
        Module1.pair(MatrixKriteria, trckKriteria1Kriteria5, 0, 4)
    End Sub

    Private Sub trckKriteria2Kriteria3_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trckKriteria2Kriteria3.Scroll
        Module1.pair(MatrixKriteria, trckKriteria2Kriteria3, 1, 2)
    End Sub

    Private Sub trckKriteria2Kriteria4_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trckKriteria2Kriteria4.Scroll
        Module1.pair(MatrixKriteria, trckKriteria2Kriteria4, 1, 3)
    End Sub

    Private Sub trckKriteria2Kriteria5_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trckKriteria2Kriteria5.Scroll
        Module1.pair(MatrixKriteria, trckKriteria2Kriteria5, 1, 4)
    End Sub

    Private Sub trckKriteria3Kriteria4_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trckKriteria3Kriteria4.Scroll
        Module1.pair(MatrixKriteria, trckKriteria3Kriteria4, 2, 3)
    End Sub

    Private Sub trckKriteria3Kriteria5_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trckKriteria3Kriteria5.Scroll
        Module1.pair(MatrixKriteria, trckKriteria3Kriteria5, 2, 4)
    End Sub

    Private Sub trckKriteria4Kriteria5_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trckKriteria4Kriteria5.Scroll
        Module1.pair(MatrixKriteria, trckKriteria4Kriteria5, 2, 4)
    End Sub

    
    Private Sub trkKriteria1Alternatif1Alternatif2_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria1Alternatif1Alternatif2.Scroll

        Module1.pair(MatrixKriteria1Alternatif, trkKriteria1Alternatif1Alternatif2, 0, 1)
    End Sub

    Private Sub Label20_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label20.Click
        DisplayMatrix.Show()
        DisplayMatrix.ShowArray(MatrixKriteria1Alternatif, updnJumlahAlternatif.Value - 1)
    End Sub

    Private Sub trkKriteria1Alternatif1Alternatif3_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria1Alternatif1Alternatif3.Scroll
        Module1.pair(MatrixKriteria1Alternatif, trkKriteria1Alternatif1Alternatif3, 0, 2)
    End Sub

    Private Sub trkKriteria1Alternatif1Alternatif4_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria1Alternatif1Alternatif4.Scroll
        Module1.pair(MatrixKriteria1Alternatif, trkKriteria1Alternatif1Alternatif4, 0, 3)
    End Sub

    Private Sub trkKriteria1Alternatif1Alternatif5_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria1Alternatif1Alternatif5.Scroll
        Module1.pair(MatrixKriteria1Alternatif, trkKriteria1Alternatif1Alternatif5, 0, 4)
    End Sub

    Private Sub trkKriteria1Alternatif2Alternatif3_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria1Alternatif2Alternatif3.Scroll
        Module1.pair(MatrixKriteria1Alternatif, trkKriteria1Alternatif2Alternatif3, 1, 2)

    End Sub

    Private Sub trkKriteria1Alternatif2Alternatif4_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria1Alternatif2Alternatif4.Scroll
        Module1.pair(MatrixKriteria1Alternatif, trkKriteria1Alternatif2Alternatif4, 1, 3)
    End Sub

    Private Sub trkKriteria1Alternatif2Alternatif5_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria1Alternatif2Alternatif5.Scroll
        Module1.pair(MatrixKriteria1Alternatif, trkKriteria1Alternatif2Alternatif5, 1, 4)
    End Sub

    Private Sub trkKriteria1Alternatif3Alternatif4_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria1Alternatif3Alternatif4.Scroll
        Module1.pair(MatrixKriteria1Alternatif, trkKriteria1Alternatif3Alternatif4, 2, 3)
    End Sub

    Private Sub trkKriteria1Alternatif3Alternatif5_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria1Alternatif3Alternatif5.Scroll
        Module1.pair(MatrixKriteria1Alternatif, trkKriteria1Alternatif3Alternatif5, 2, 4)
    End Sub

    Private Sub trkKriteria1Alternatif4Alternatif5_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria1Alternatif4Alternatif5.Scroll
        Module1.pair(MatrixKriteria1Alternatif, trkKriteria1Alternatif4Alternatif5, 3, 4)
    End Sub

    Private Sub trkKriteria2Alternatif1Alternatif2_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria2Alternatif1Alternatif2.Scroll
        Module1.pair(MatrixKriteria2Alternatif, trkKriteria2Alternatif1Alternatif2, 0, 1)
    End Sub

    Private Sub trkKriteria2Alternatif1Alternatif3_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria2Alternatif1Alternatif3.Scroll
        Module1.pair(MatrixKriteria2Alternatif, trkKriteria2Alternatif1Alternatif3, 0, 2)
    End Sub

    Private Sub trkKriteria2Alternatif1Alternatif4_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria2Alternatif1Alternatif4.Scroll
        Module1.pair(MatrixKriteria2Alternatif, trkKriteria2Alternatif1Alternatif4, 0, 3)
    End Sub

    Private Sub trkKriteria2Alternatif1Alternatif5_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria2Alternatif1Alternatif5.Scroll
        Module1.pair(MatrixKriteria2Alternatif, trkKriteria2Alternatif1Alternatif5, 0, 4)
    End Sub

    Private Sub trkKriteria2Alternatif2Alternatif3_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria2Alternatif2Alternatif3.Scroll
        Module1.pair(MatrixKriteria2Alternatif, trkKriteria2Alternatif2Alternatif3, 1, 2)
    End Sub

    Private Sub trkKriteria2Alternatif2Alternatif4_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria2Alternatif2Alternatif4.Scroll
        Module1.pair(MatrixKriteria2Alternatif, trkKriteria2Alternatif2Alternatif4, 1, 3)
    End Sub

    Private Sub trkKriteria2Alternatif2Alternatif5_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria2Alternatif2Alternatif5.Scroll
        Module1.pair(MatrixKriteria2Alternatif, trkKriteria2Alternatif2Alternatif5, 1, 4)
    End Sub

    Private Sub trkKriteria2Alternatif3Alternatif4_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria2Alternatif3Alternatif4.Scroll
        Module1.pair(MatrixKriteria2Alternatif, trkKriteria2Alternatif3Alternatif4, 2, 3)
    End Sub

    Private Sub trkKriteria2Alternatif3Alternatif5_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria2Alternatif3Alternatif5.Scroll
        Module1.pair(MatrixKriteria2Alternatif, trkKriteria2Alternatif3Alternatif5, 2, 3)
    End Sub

    Private Sub trkKriteria2Alternatif4Alternatif5_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria2Alternatif4Alternatif5.Scroll
        Module1.pair(MatrixKriteria2Alternatif, trkKriteria2Alternatif4Alternatif5, 2, 4)
    End Sub

    Private Sub Label28_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label28.Click
        DisplayMatrix.Show()
        DisplayMatrix.ShowArray(MatrixKriteria2Alternatif, updnJumlahAlternatif.Value - 1)
    End Sub

    Private Sub trkKriteria3Alternatif1Alternatif2_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria3Alternatif1Alternatif2.Scroll
        Module1.pair(MatrixKriteria3Alternatif, trkKriteria3Alternatif1Alternatif2, 0, 1)
    End Sub

    Private Sub trkKriteria3Alternatif1Alternatif3_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria3Alternatif1Alternatif3.Scroll
        Module1.pair(MatrixKriteria3Alternatif, trkKriteria3Alternatif1Alternatif3, 0, 2)
    End Sub

    Private Sub trkKriteria3Alternatif1Alternatif4_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria3Alternatif1Alternatif4.Scroll
        Module1.pair(MatrixKriteria3Alternatif, trkKriteria3Alternatif1Alternatif4, 0, 3)
    End Sub

    Private Sub trkKriteria3Alternatif1Alternatif5_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria3Alternatif1Alternatif5.Scroll
        Module1.pair(MatrixKriteria3Alternatif, trkKriteria3Alternatif1Alternatif5, 0, 4)
    End Sub

    Private Sub trkKriteria3Alternatif2Alternatif3_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria3Alternatif2Alternatif3.Scroll
        Module1.pair(MatrixKriteria3Alternatif, trkKriteria3Alternatif2Alternatif3, 1, 2)
    End Sub

    Private Sub trkKriteria3Alternatif2Alternatif4_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria3Alternatif2Alternatif4.Scroll
        Module1.pair(MatrixKriteria3Alternatif, trkKriteria3Alternatif2Alternatif4, 1, 3)
    End Sub

    Private Sub trkKriteria3Alternatif2Alternatif5_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria3Alternatif2Alternatif5.Scroll
        Module1.pair(MatrixKriteria3Alternatif, trkKriteria3Alternatif2Alternatif5, 1, 4)
    End Sub

    Private Sub trkKriteria3Alternatif3Alternatif4_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria3Alternatif3Alternatif4.Scroll
        Module1.pair(MatrixKriteria3Alternatif, trkKriteria3Alternatif3Alternatif4, 2, 3)
    End Sub

    Private Sub trkKriteria3Alternatif3Alternatif5_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria3Alternatif3Alternatif5.Scroll
        Module1.pair(MatrixKriteria3Alternatif, trkKriteria3Alternatif3Alternatif5, 2, 4)
    End Sub

    Private Sub trkKriteria3Alternatif4Alternatif5_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria3Alternatif4Alternatif5.Scroll
        Module1.pair(MatrixKriteria3Alternatif, trkKriteria3Alternatif4Alternatif5, 3, 4)
    End Sub

    Private Sub Label33_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label33.Click
        DisplayMatrix.Show()
        DisplayMatrix.ShowArray(MatrixKriteria3Alternatif, updnJumlahAlternatif.Value - 1)
    End Sub

    Private Sub trkKriteria4Alternatif1Alternatif2_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria4Alternatif1Alternatif2.Scroll
        Module1.pair(MatrixKriteria4Alternatif, trkKriteria4Alternatif1Alternatif2, 0, 1)
    End Sub

    Private Sub trkKriteria4Alternatif1Alternatif3_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria4Alternatif1Alternatif3.Scroll
        Module1.pair(MatrixKriteria4Alternatif, trkKriteria4Alternatif1Alternatif3, 0, 2)
    End Sub

    Private Sub trkKriteria4Alternatif1Alternatif4_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria4Alternatif1Alternatif4.Scroll
        Module1.pair(MatrixKriteria4Alternatif, trkKriteria4Alternatif1Alternatif4, 0, 3)
    End Sub

    Private Sub trkKriteria4Alternatif1Alternatif5_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria4Alternatif1Alternatif5.Scroll
        Module1.pair(MatrixKriteria4Alternatif, trkKriteria4Alternatif1Alternatif5, 0, 4)
    End Sub

    Private Sub trkKriteria4Alternatif2Alternatif3_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria4Alternatif2Alternatif3.Scroll
        Module1.pair(MatrixKriteria4Alternatif, trkKriteria4Alternatif2Alternatif3, 1, 2)
    End Sub

    Private Sub trkKriteria4Alternatif2Alternatif4_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria4Alternatif2Alternatif4.Scroll
        Module1.pair(MatrixKriteria4Alternatif, trkKriteria4Alternatif2Alternatif4, 1, 3)
    End Sub

    Private Sub trkKriteria4Alternatif2Alternatif5_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria4Alternatif2Alternatif5.Scroll
        Module1.pair(MatrixKriteria4Alternatif, trkKriteria4Alternatif2Alternatif5, 1, 4)
    End Sub

    Private Sub trkKriteria4Alternatif3Alternatif4_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria4Alternatif3Alternatif4.Scroll
        Module1.pair(MatrixKriteria4Alternatif, trkKriteria4Alternatif3Alternatif4, 2, 3)
    End Sub

    Private Sub trkKriteria4Alternatif3Alternatif5_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria4Alternatif3Alternatif5.Scroll
        Module1.pair(MatrixKriteria4Alternatif, trkKriteria4Alternatif3Alternatif5, 2, 4)
    End Sub

    Private Sub trkKriteria4Alternatif4Alternatif5_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria4Alternatif4Alternatif5.Scroll
        Module1.pair(MatrixKriteria4Alternatif, trkKriteria4Alternatif4Alternatif5, 3, 4)
    End Sub

    Private Sub trkKriteria5Alternatif1Alternatif2_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria5Alternatif1Alternatif2.Scroll
        Module1.pair(MatrixKriteria5Alternatif, trkKriteria5Alternatif1Alternatif2, 0, 1)
    End Sub

    Private Sub trkKriteria5Alternatif1Alternatif3_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria5Alternatif1Alternatif3.Scroll
        Module1.pair(MatrixKriteria5Alternatif, trkKriteria5Alternatif1Alternatif3, 0, 2)
    End Sub

    Private Sub trkKriteria5Alternatif1Alternatif4_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria5Alternatif1Alternatif4.Scroll
        Module1.pair(MatrixKriteria5Alternatif, trkKriteria5Alternatif1Alternatif4, 0, 3)
    End Sub

    Private Sub trkKriteria5Alternatif1Alternatif5_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria5Alternatif1Alternatif5.Scroll
        Module1.pair(MatrixKriteria5Alternatif, trkKriteria5Alternatif1Alternatif5, 0, 4)
    End Sub

    Private Sub trkKriteria5Alternatif2Alternatif3_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria5Alternatif2Alternatif3.Scroll
        Module1.pair(MatrixKriteria5Alternatif, trkKriteria5Alternatif2Alternatif3, 1, 2)
    End Sub

    Private Sub trkKriteria5Alternatif2Alternatif4_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria5Alternatif2Alternatif4.Scroll
        Module1.pair(MatrixKriteria5Alternatif, trkKriteria5Alternatif2Alternatif4, 1, 3)
    End Sub

    Private Sub trkKriteria5Alternatif2Alternatif5_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria5Alternatif2Alternatif5.Scroll
        Module1.pair(MatrixKriteria5Alternatif, trkKriteria5Alternatif2Alternatif5, 1, 4)
    End Sub

    Private Sub trkKriteria5Alternatif3Alternatif4_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria5Alternatif3Alternatif4.Scroll
        Module1.pair(MatrixKriteria5Alternatif, trkKriteria5Alternatif3Alternatif4, 2, 3)
    End Sub

    Private Sub trkKriteria5Alternatif3Alternatif5_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria5Alternatif3Alternatif5.Scroll
        Module1.pair(MatrixKriteria5Alternatif, trkKriteria5Alternatif3Alternatif5, 2, 4)
    End Sub

    Private Sub trkKriteria5Alternatif4Alternatif5_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkKriteria5Alternatif4Alternatif5.Scroll
        Module1.pair(MatrixKriteria5Alternatif, trkKriteria5Alternatif4Alternatif5, 3, 4)
    End Sub

    Private Sub Label43_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label43.Click
        DisplayMatrix.Show()
        DisplayMatrix.ShowArray(MatrixKriteria5Alternatif, updnJumlahAlternatif.Value - 1)
    End Sub

    Private Sub Label38_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label38.Click
        DisplayMatrix.Show()
        DisplayMatrix.ShowArray(MatrixKriteria4Alternatif, updnJumlahAlternatif.Value - 1)
    End Sub
End Class
