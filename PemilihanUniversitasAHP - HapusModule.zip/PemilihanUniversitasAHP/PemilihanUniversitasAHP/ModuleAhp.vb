﻿Module ModuleAhp
    Dim cn As New ADODB.Connection()

    Public Sub Main()
        cn.Open("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Public\Documents\BimbinganSkripsi\AswanHalil-DSS-VB6\database\AHP.accdb")
    End Sub
    'todo : ubah ke standar MS u/ identify
    Public Function authenticate(ByVal userName As String, ByVal password As String) As Boolean
        Dim rs As New ADODB.Recordset()
        rs.Open("select * from pemakai where namapemakai='" & userName & "' and password='" & password & "'", cn)

        If rs.EOF Then
            Return False
        End If
        rs.Close()
        Return True
    End Function

End Module
