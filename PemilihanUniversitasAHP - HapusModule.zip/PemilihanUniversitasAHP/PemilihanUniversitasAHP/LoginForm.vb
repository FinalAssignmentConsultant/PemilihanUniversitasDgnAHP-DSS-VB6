﻿Public Class LoginForm

    ' TODO: Insert code to perform custom authentication using the provided username and password 
    ' (See http://go.microsoft.com/fwlink/?LinkId=35339).  
    ' The custom principal can then be attached to the current thread's principal as follows: 
    '     My.User.CurrentPrincipal = CustomPrincipal
    ' where CustomPrincipal is the IPrincipal implementation used to perform authentication. 
    ' Subsequently, My.User will return identity information encapsulated in the CustomPrincipal object
    ' such as the username, display name, etc.

    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click
        If ModuleAhp.authenticate(txtUsername.Text, txtPassword.Text) Then
            Me.Close()
        Else
            MsgBox("Maaf, Anda tidak dikenali oleh sistem", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Kesalahan Identifikasi")
        End If


    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        If MsgBox("Anda akan keluar dari sistem. Apakah Anda yakin?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Keluar dari sistem") = MsgBoxResult.Yes Then
            Me.Close()
            End
        End If

    End Sub

End Class
