﻿Public Class FormUtama
    Private Sub AboutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutToolStripMenuItem.Click
        AboutBox.ShowDialog()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        End
    End Sub
    Private Sub btnAturAHP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        FormPengaturan.ShowDialog()
    End Sub
    Private Sub updnJumlahKriteria_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles updnJumlahKriteria.ValueChanged

        prosesAhpModel()
    End Sub
    Private Sub validateIt()
        txtKriteria1.Visible = False
        txtKriteria2.Visible = False
        txtKriteria3.Visible = False
        txtKriteria4.Visible = False
        txtKriteria5.Visible = False
        Select Case updnJumlahKriteria.Value
            Case 3
                txtKriteria1.Visible = True
                txtKriteria2.Visible = True
                txtKriteria3.Visible = True
            Case 4
                txtKriteria1.Visible = True
                txtKriteria2.Visible = True
                txtKriteria3.Visible = True
                txtKriteria4.Visible = True
            Case 5
                txtKriteria1.Visible = True
                txtKriteria2.Visible = True
                txtKriteria3.Visible = True
                txtKriteria4.Visible = True
                txtKriteria5.Visible = True
        End Select

        txtAlternatif1.Visible = False
        txtAlternatif2.Visible = False
        txtAlternatif3.Visible = False
        txtAlternatif4.Visible = False
        txtAlternatif5.Visible = False

        lblKriteria1Alternatif4.Visible = False
        lblKriteria1Alternatif3.Visible = False
        lblKriteria1Alternatif4Alternatif5.Visible = False

        lblKriteria1Alternatif1Alternatif4.Visible = False
        lblKriteria1Alternatif2Alternatif4.Visible = False
        lblKriteria1Alternatif3Alternatif4.Visible = False

        lblKriteria1Alternatif1Alternatif5.Visible = False
        lblKriteria1Alternatif2Alternatif5.Visible = False
        lblKriteria1Alternatif3Alternatif5.Visible = False
        lblKriteria1Alternatif4Alternatif5.Visible = False

        'kriteria1
        trkKriteria1Alternatif1Alternatif4.Visible = False
        trkKriteria1Alternatif2Alternatif4.Visible = False
        trkKriteria1Alternatif3Alternatif4.Visible = False

        trkKriteria1Alternatif1Alternatif5.Visible = False
        trkKriteria1Alternatif2Alternatif5.Visible = False
        trkKriteria1Alternatif3Alternatif5.Visible = False
        trkKriteria1Alternatif4Alternatif5.Visible = False

        'kriteria2
        trkKriteria2Alternatif1Alternatif4.Visible = False
        trkKriteria2Alternatif2Alternatif4.Visible = False
        trkKriteria2Alternatif3Alternatif4.Visible = False

        trkKriteria2Alternatif1Alternatif5.Visible = False
        trkKriteria2Alternatif2Alternatif5.Visible = False
        trkKriteria2Alternatif3Alternatif5.Visible = False
        trkKriteria2Alternatif4Alternatif5.Visible = False

        lblKriteria2Alternatif1Alternatif4.Visible = False
        lblKriteria2Alternatif2Alternatif4.Visible = False
        lblKriteria2Alternatif3Alternatif4.Visible = False
        lblKriteria2Alternatif3.Visible = False


        lblKriteria2Alternatif4Alternatif5.Visible = False
        lblKriteria2Alternatif1Alternatif5.Visible = False
        lblKriteria2Alternatif2Alternatif5.Visible = False
        lblKriteria2Alternatif3Alternatif5.Visible = False
        lblKriteria2Alternatif4Alternatif5.Visible = False
        lblKriteria2Alternatif1Alternatif5.Visible = False
        lblKriteria2Alternatif4.Visible = False

        'kriteria3
        trkKriteria3Alternatif1Alternatif4.Visible = False
        trkKriteria3Alternatif2Alternatif4.Visible = False
        trkKriteria3Alternatif3Alternatif4.Visible = False

        trkKriteria3Alternatif1Alternatif5.Visible = False
        trkKriteria3Alternatif2Alternatif5.Visible = False
        trkKriteria3Alternatif3Alternatif5.Visible = False
        trkKriteria3Alternatif4Alternatif5.Visible = False

        lblKriteria3Alternatif1Alternatif4.Visible = False
        lblKriteria3Alternatif2Alternatif4.Visible = False
        lblKriteria3Alternatif3Alternatif4.Visible = False
        lblKriteria3Alternatif3.Visible = False


        lblKriteria3Alternatif4Alternatif5.Visible = False
        lblKriteria3Alternatif1Alternatif5.Visible = False
        lblKriteria3Alternatif2Alternatif5.Visible = False
        lblKriteria3Alternatif3Alternatif5.Visible = False
        lblKriteria3Alternatif4Alternatif5.Visible = False
        lblKriteria3Alternatif1Alternatif5.Visible = False
        lblKriteria3Alternatif4.Visible = False

        'kriteria4
        trkKriteria4Alternatif1Alternatif4.Visible = False
        trkKriteria4Alternatif2Alternatif4.Visible = False
        trkKriteria4Alternatif3Alternatif4.Visible = False

        trkKriteria4Alternatif1Alternatif5.Visible = False
        trkKriteria4Alternatif2Alternatif5.Visible = False
        trkKriteria4Alternatif3Alternatif5.Visible = False
        trkKriteria4Alternatif4Alternatif5.Visible = False

        lblKriteria4Alternatif1Alternatif4.Visible = False
        lblKriteria4Alternatif2Alternatif4.Visible = False
        lblKriteria4Alternatif3Alternatif4.Visible = False
        lblKriteria4Alternatif3.Visible = False

        lblKriteria4Alternatif4Alternatif5.Visible = False
        lblKriteria4Alternatif1Alternatif5.Visible = False
        lblKriteria4Alternatif2Alternatif5.Visible = False
        lblKriteria4Alternatif3Alternatif5.Visible = False
        lblKriteria4Alternatif4Alternatif5.Visible = False
        lblKriteria4Alternatif1Alternatif5.Visible = False
        lblKriteria4Alternatif4.Visible = False

        'kriteria5
        trkkriteria5Alternatif1Alternatif4.Visible = False
        trkkriteria5Alternatif2Alternatif4.Visible = False
        trkkriteria5Alternatif3Alternatif4.Visible = False

        trkkriteria5Alternatif1Alternatif5.Visible = False
        trkkriteria5Alternatif2Alternatif5.Visible = False
        trkkriteria5Alternatif3Alternatif5.Visible = False
        trkkriteria5Alternatif4Alternatif5.Visible = False

        lblkriteria5Alternatif1Alternatif4.Visible = False
        lblkriteria5Alternatif2Alternatif4.Visible = False
        lblkriteria5Alternatif3Alternatif4.Visible = False
        lblkriteria5Alternatif3.Visible = False

        lblkriteria5Alternatif4Alternatif5.Visible = False
        lblkriteria5Alternatif1Alternatif5.Visible = False
        lblkriteria5Alternatif2Alternatif5.Visible = False
        lblkriteria5Alternatif3Alternatif5.Visible = False
        lblkriteria5Alternatif4Alternatif5.Visible = False
        lblkriteria5Alternatif1Alternatif5.Visible = False
        lblkriteria5Alternatif4.Visible = False

        Select Case updnJumlahAlternatif.Value
            Case 3
                txtAlternatif1.Visible = True
                txtAlternatif2.Visible = True
                txtAlternatif3.Visible = True
            Case 4
                txtAlternatif1.Visible = True
                txtAlternatif2.Visible = True
                txtAlternatif3.Visible = True
                txtAlternatif4.Visible = True

                lblKriteria1Alternatif3.Visible = True

                


                'kriteria1
                trkKriteria1Alternatif1Alternatif4.Visible = True
                trkKriteria1Alternatif2Alternatif4.Visible = True
                trkKriteria1Alternatif3Alternatif4.Visible = True

                lblKriteria1Alternatif1Alternatif4.Visible = True
                lblKriteria1Alternatif2Alternatif4.Visible = True
                lblKriteria1Alternatif3Alternatif4.Visible = True

                'kriteria2
                trkKriteria2Alternatif1Alternatif4.Visible = True
                trkKriteria2Alternatif2Alternatif4.Visible = True
                trkKriteria2Alternatif3Alternatif4.Visible = True

                lblKriteria2Alternatif1Alternatif4.Visible = True
                lblKriteria2Alternatif2Alternatif4.Visible = True
                lblKriteria2Alternatif3Alternatif4.Visible = True
                lblKriteria2Alternatif3.Visible = True

                'kriteria3
                trkKriteria3Alternatif1Alternatif4.Visible = True
                trkKriteria3Alternatif2Alternatif4.Visible = True
                trkKriteria3Alternatif3Alternatif4.Visible = True

                lblKriteria3Alternatif1Alternatif4.Visible = True
                lblKriteria3Alternatif2Alternatif4.Visible = True
                lblKriteria3Alternatif3Alternatif4.Visible = True
                lblKriteria3Alternatif3.Visible = True

                'kriteria4
                trkKriteria4Alternatif1Alternatif4.Visible = True
                trkKriteria4Alternatif2Alternatif4.Visible = True
                trkKriteria4Alternatif3Alternatif4.Visible = True

                lblKriteria4Alternatif1Alternatif4.Visible = True
                lblKriteria4Alternatif2Alternatif4.Visible = True
                lblKriteria4Alternatif3Alternatif4.Visible = True
                lblKriteria4Alternatif3.Visible = True

                'kriteria 5
                trkKriteria5Alternatif1Alternatif4.Visible = True
                trkKriteria5Alternatif2Alternatif4.Visible = True
                lblKriteria5Alternatif2Alternatif4.Visible = True
                lblKriteria5Alternatif3Alternatif4.Visible = True
                trkKriteria5Alternatif3Alternatif4.Visible = True
                lblKriteria5Alternatif3.Visible = True
                lblKriteria5Alternatif1Alternatif4.Visible = True
            Case 5
                txtAlternatif1.Visible = True
                txtAlternatif2.Visible = True
                txtAlternatif3.Visible = True
                txtAlternatif4.Visible = True
                txtAlternatif5.Visible = True

                lblKriteria1Alternatif3.Visible = True
                lblKriteria1Alternatif4.Visible = True
                lblKriteria1Alternatif1Alternatif4.Visible = True
                lblKriteria1Alternatif2Alternatif4.Visible = True
                lblKriteria1Alternatif3Alternatif4.Visible = True

                lblKriteria1Alternatif4Alternatif5.Visible = True
                lblKriteria1Alternatif1Alternatif5.Visible = True
                lblKriteria1Alternatif2Alternatif5.Visible = True
                lblKriteria1Alternatif3Alternatif5.Visible = True
                lblKriteria1Alternatif4Alternatif5.Visible = True

                lblKriteria1Alternatif1Alternatif4.Visible = True
                lblKriteria1Alternatif2Alternatif4.Visible = True
                lblKriteria1Alternatif3Alternatif4.Visible = True

                trkKriteria1Alternatif1Alternatif4.Visible = True
                trkKriteria1Alternatif1Alternatif5.Visible = True
                trkKriteria1Alternatif2Alternatif5.Visible = True
                trkKriteria1Alternatif2Alternatif4.Visible = True
                trkKriteria1Alternatif3Alternatif4.Visible = True
                trkKriteria1Alternatif3Alternatif5.Visible = True
                trkKriteria1Alternatif4Alternatif5.Visible = True

                'kriteria2

                lblKriteria2Alternatif4Alternatif5.Visible = True
                lblKriteria2Alternatif1Alternatif5.Visible = True
                lblKriteria2Alternatif2Alternatif5.Visible = True
                lblKriteria2Alternatif3Alternatif5.Visible = True
                lblKriteria2Alternatif4Alternatif5.Visible = True
                lblKriteria2Alternatif1Alternatif5.Visible = True
                lblKriteria2Alternatif4.Visible = True

                trkKriteria2Alternatif1Alternatif5.Visible = True
                trkKriteria2Alternatif2Alternatif5.Visible = True
                trkKriteria2Alternatif3Alternatif5.Visible = True
                trkKriteria2Alternatif4Alternatif5.Visible = True
                trkKriteria2Alternatif1Alternatif4.Visible = True
                trkKriteria2Alternatif2Alternatif4.Visible = True
                lblKriteria2Alternatif2Alternatif4.Visible = True
                lblKriteria2Alternatif3Alternatif4.Visible = True
                trkKriteria2Alternatif3Alternatif4.Visible = True
                lblKriteria2Alternatif3.Visible = True

                'kriteria3

                lblKriteria3Alternatif4Alternatif5.Visible = True
                lblKriteria3Alternatif1Alternatif5.Visible = True
                lblKriteria3Alternatif2Alternatif5.Visible = True
                lblKriteria3Alternatif3Alternatif5.Visible = True
                lblKriteria3Alternatif4Alternatif5.Visible = True
                lblKriteria3Alternatif1Alternatif5.Visible = True
                lblKriteria3Alternatif4.Visible = True

                trkKriteria3Alternatif1Alternatif5.Visible = True
                trkKriteria3Alternatif2Alternatif5.Visible = True
                trkKriteria3Alternatif3Alternatif5.Visible = True
                trkKriteria3Alternatif4Alternatif5.Visible = True
                trkKriteria3Alternatif1Alternatif4.Visible = True
                trkKriteria3Alternatif2Alternatif4.Visible = True
                lblKriteria3Alternatif2Alternatif4.Visible = True
                lblKriteria3Alternatif3Alternatif4.Visible = True
                trkKriteria3Alternatif3Alternatif4.Visible = True
                lblKriteria3Alternatif3.Visible = True

                'kriteria4

                'kriteria4
                trkKriteria4Alternatif1Alternatif4.Visible = True
                trkKriteria4Alternatif2Alternatif4.Visible = True
                trkKriteria4Alternatif3Alternatif4.Visible = True

                lblKriteria4Alternatif1Alternatif4.Visible = True
                lblKriteria4Alternatif2Alternatif4.Visible = True
                lblKriteria4Alternatif3Alternatif4.Visible = True
                lblKriteria4Alternatif3.Visible = True

                lblKriteria4Alternatif4Alternatif5.Visible = True
                lblKriteria4Alternatif1Alternatif5.Visible = True
                lblKriteria4Alternatif2Alternatif5.Visible = True
                lblKriteria4Alternatif3Alternatif5.Visible = True
                lblKriteria4Alternatif4Alternatif5.Visible = True
                lblKriteria4Alternatif1Alternatif5.Visible = True
                lblKriteria4Alternatif4.Visible = True

                trkKriteria4Alternatif1Alternatif5.Visible = True
                trkKriteria4Alternatif2Alternatif5.Visible = True
                trkKriteria4Alternatif3Alternatif5.Visible = True
                trkKriteria4Alternatif4Alternatif5.Visible = True
                trkKriteria4Alternatif1Alternatif4.Visible = True
                trkKriteria4Alternatif2Alternatif4.Visible = True
                lblKriteria4Alternatif2Alternatif4.Visible = True
                lblKriteria4Alternatif3Alternatif4.Visible = True
                trkKriteria4Alternatif3Alternatif4.Visible = True
                lblKriteria4Alternatif3.Visible = True

                'kriteria5

                lblkriteria5Alternatif4Alternatif5.Visible = True
                lblkriteria5Alternatif1Alternatif5.Visible = True
                lblkriteria5Alternatif2Alternatif5.Visible = True
                lblkriteria5Alternatif3Alternatif5.Visible = True
                lblkriteria5Alternatif4Alternatif5.Visible = True
                lblkriteria5Alternatif1Alternatif5.Visible = True
                lblkriteria5Alternatif4.Visible = True

                trkkriteria5Alternatif1Alternatif5.Visible = True
                trkkriteria5Alternatif2Alternatif5.Visible = True
                trkkriteria5Alternatif3Alternatif5.Visible = True
                trkkriteria5Alternatif4Alternatif5.Visible = True
                trkkriteria5Alternatif1Alternatif4.Visible = True
                trkkriteria5Alternatif2Alternatif4.Visible = True
                lblkriteria5Alternatif2Alternatif4.Visible = True
                lblkriteria5Alternatif3Alternatif4.Visible = True
                trkkriteria5Alternatif3Alternatif4.Visible = True
                lblKriteria5Alternatif3.Visible = True
                lblKriteria5Alternatif1Alternatif4.Visible = True
        End Select
        'txtKriteria1.Focus()
    End Sub
    Private Sub updnJumlahAlternatif_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles updnJumlahAlternatif.ValueChanged

        prosesAhpModel()
    End Sub

    Private Sub prosesAhpModel()

        validateIt()

        trckKriteria1Kriteria4.Visible = False
        trckKriteria1Kriteria5.Visible = False

        trckKriteria2Kriteria4.Visible = False
        trckKriteria2Kriteria5.Visible = False

        trckKriteria3Kriteria4.Visible = False
        trckKriteria3Kriteria5.Visible = False

        trckKriteria4Kriteria5.Visible = False

        lblKriteria1Kriteria4.Visible = False
        lblKriteria1Kriteria5.Visible = False

        lblKriteria2Kriteria4.Visible = False
        lblKriteria2Kriteria5.Visible = False

        lblKriteria3.Visible = False
        lblKriteria3Kriteria4.Visible = False
        lblKriteria3Kriteria5.Visible = False

        lblKriteria4.Visible = False
        lblKriteria4Kriteria5.Visible = False


        tabCtlAlternatif.SizeMode = TabSizeMode.Normal
        tabCtlAlternatif.TabPages.Remove(tabKriteria5)
        tabCtlAlternatif.TabPages.Remove(tabKriteria4)
        Select Case updnJumlahKriteria.Value
            Case 4
                trckKriteria1Kriteria4.Visible = True
                trckKriteria2Kriteria4.Visible = True
                trckKriteria3Kriteria4.Visible = True

                lblKriteria3.Visible = True
                lblKriteria1Kriteria4.Visible = True
                lblKriteria2Kriteria4.Visible = True
                lblKriteria3Kriteria4.Visible = True

                tabCtlAlternatif.TabPages.Add(tabKriteria4)
            Case 5
                trckKriteria1Kriteria4.Visible = True
                trckKriteria2Kriteria4.Visible = True
                trckKriteria3Kriteria4.Visible = True

                trckKriteria1Kriteria5.Visible = True
                trckKriteria2Kriteria5.Visible = True
                trckKriteria3Kriteria5.Visible = True
                trckKriteria4Kriteria5.Visible = True

                lblKriteria1Kriteria4.Visible = True
                lblKriteria2Kriteria4.Visible = True
                lblKriteria3.Visible = True
                lblKriteria3Kriteria4.Visible = True

                lblKriteria1Kriteria5.Visible = True
                lblKriteria2Kriteria5.Visible = True
                lblKriteria3Kriteria5.Visible = True
                lblKriteria4.Visible = True
                lblKriteria4Kriteria5.Visible = True

                tabCtlAlternatif.TabPages.Add(tabKriteria4)
                tabCtlAlternatif.TabPages.Add(tabKriteria5)
        End Select

    End Sub

    Private Sub FormUtama_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        prosesAhpModel()
    End Sub

End Class
