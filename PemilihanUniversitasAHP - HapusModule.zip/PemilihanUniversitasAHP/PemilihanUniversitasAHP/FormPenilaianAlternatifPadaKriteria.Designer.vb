﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormPenilaianAlternatifPadaKriteria
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.TrackBar2 = New System.Windows.Forms.TrackBar
        Me.Label10 = New System.Windows.Forms.Label
        Me.TrackBar5 = New System.Windows.Forms.TrackBar
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.TrackBar1 = New System.Windows.Forms.TrackBar
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.TrackBar4 = New System.Windows.Forms.TrackBar
        Me.TrackBar3 = New System.Windows.Forms.TrackBar
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.TrackBar6 = New System.Windows.Forms.TrackBar
        Me.Label6 = New System.Windows.Forms.Label
        Me.TrackBar7 = New System.Windows.Forms.TrackBar
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.TrackBar8 = New System.Windows.Forms.TrackBar
        Me.Label12 = New System.Windows.Forms.Label
        Me.TrackBar9 = New System.Windows.Forms.TrackBar
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.TrackBar10 = New System.Windows.Forms.TrackBar
        Me.Label15 = New System.Windows.Forms.Label
        Me.TrackBar11 = New System.Windows.Forms.TrackBar
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.TrackBar12 = New System.Windows.Forms.TrackBar
        Me.Label18 = New System.Windows.Forms.Label
        Me.TrackBar13 = New System.Windows.Forms.TrackBar
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.TrackBar14 = New System.Windows.Forms.TrackBar
        Me.Label21 = New System.Windows.Forms.Label
        Me.TrackBar15 = New System.Windows.Forms.TrackBar
        Me.Label22 = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.TrackBar16 = New System.Windows.Forms.TrackBar
        Me.Label24 = New System.Windows.Forms.Label
        Me.TrackBar17 = New System.Windows.Forms.TrackBar
        Me.Label25 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.TrackBar18 = New System.Windows.Forms.TrackBar
        Me.Label27 = New System.Windows.Forms.Label
        Me.TrackBar19 = New System.Windows.Forms.TrackBar
        Me.Label28 = New System.Windows.Forms.Label
        Me.Label29 = New System.Windows.Forms.Label
        Me.TrackBar20 = New System.Windows.Forms.TrackBar
        Me.Label30 = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        CType(Me.TrackBar2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar18, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar19, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar20, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.TrackBar17)
        Me.GroupBox1.Controls.Add(Me.Label25)
        Me.GroupBox1.Controls.Add(Me.Label26)
        Me.GroupBox1.Controls.Add(Me.TrackBar18)
        Me.GroupBox1.Controls.Add(Me.Label27)
        Me.GroupBox1.Controls.Add(Me.TrackBar19)
        Me.GroupBox1.Controls.Add(Me.Label28)
        Me.GroupBox1.Controls.Add(Me.Label29)
        Me.GroupBox1.Controls.Add(Me.TrackBar20)
        Me.GroupBox1.Controls.Add(Me.Label30)
        Me.GroupBox1.Controls.Add(Me.TrackBar13)
        Me.GroupBox1.Controls.Add(Me.Label19)
        Me.GroupBox1.Controls.Add(Me.Label20)
        Me.GroupBox1.Controls.Add(Me.TrackBar14)
        Me.GroupBox1.Controls.Add(Me.Label21)
        Me.GroupBox1.Controls.Add(Me.TrackBar15)
        Me.GroupBox1.Controls.Add(Me.Label22)
        Me.GroupBox1.Controls.Add(Me.Label23)
        Me.GroupBox1.Controls.Add(Me.TrackBar16)
        Me.GroupBox1.Controls.Add(Me.Label24)
        Me.GroupBox1.Controls.Add(Me.TrackBar9)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.TrackBar10)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.TrackBar11)
        Me.GroupBox1.Controls.Add(Me.Label16)
        Me.GroupBox1.Controls.Add(Me.Label17)
        Me.GroupBox1.Controls.Add(Me.TrackBar12)
        Me.GroupBox1.Controls.Add(Me.Label18)
        Me.GroupBox1.Controls.Add(Me.TrackBar3)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.TrackBar6)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.TrackBar7)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.TrackBar8)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.TrackBar4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.TrackBar2)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.TrackBar5)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.TrackBar1)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 23)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(822, 680)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Penilaian Alternatif pada Kriteria"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(305, 190)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(54, 13)
        Me.Label1.TabIndex = 23
        Me.Label1.Text = "Alternatif5"
        '
        'TrackBar2
        '
        Me.TrackBar2.Location = New System.Drawing.Point(58, 190)
        Me.TrackBar2.Maximum = 17
        Me.TrackBar2.Minimum = 1
        Me.TrackBar2.Name = "TrackBar2"
        Me.TrackBar2.Size = New System.Drawing.Size(241, 42)
        Me.TrackBar2.TabIndex = 22
        Me.TrackBar2.Value = 9
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(305, 142)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(54, 13)
        Me.Label10.TabIndex = 21
        Me.Label10.Text = "Alternatif4"
        '
        'TrackBar5
        '
        Me.TrackBar5.Location = New System.Drawing.Point(58, 142)
        Me.TrackBar5.Maximum = 17
        Me.TrackBar5.Minimum = 1
        Me.TrackBar5.Name = "TrackBar5"
        Me.TrackBar5.Size = New System.Drawing.Size(241, 42)
        Me.TrackBar5.TabIndex = 20
        Me.TrackBar5.Value = 9
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(305, 94)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(54, 13)
        Me.Label9.TabIndex = 19
        Me.Label9.Text = "Alternatif3"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(305, 51)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(54, 13)
        Me.Label7.TabIndex = 18
        Me.Label7.Text = "Alternatif2"
        '
        'TrackBar1
        '
        Me.TrackBar1.Location = New System.Drawing.Point(58, 51)
        Me.TrackBar1.Maximum = 17
        Me.TrackBar1.Minimum = 1
        Me.TrackBar1.Name = "TrackBar1"
        Me.TrackBar1.Size = New System.Drawing.Size(241, 42)
        Me.TrackBar1.TabIndex = 17
        Me.TrackBar1.Value = 9
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 51)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(54, 13)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "Alternatif1"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(9, 20)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(45, 13)
        Me.Label3.TabIndex = 24
        Me.Label3.Text = "Kriteria1"
        '
        'TrackBar4
        '
        Me.TrackBar4.Location = New System.Drawing.Point(58, 94)
        Me.TrackBar4.Maximum = 17
        Me.TrackBar4.Minimum = 1
        Me.TrackBar4.Name = "TrackBar4"
        Me.TrackBar4.Size = New System.Drawing.Size(241, 42)
        Me.TrackBar4.TabIndex = 25
        Me.TrackBar4.Value = 9
        '
        'TrackBar3
        '
        Me.TrackBar3.Location = New System.Drawing.Point(448, 94)
        Me.TrackBar3.Maximum = 17
        Me.TrackBar3.Minimum = 1
        Me.TrackBar3.Name = "TrackBar3"
        Me.TrackBar3.Size = New System.Drawing.Size(241, 42)
        Me.TrackBar3.TabIndex = 35
        Me.TrackBar3.Value = 9
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(399, 20)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(45, 13)
        Me.Label4.TabIndex = 34
        Me.Label4.Text = "Kriteria2"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(695, 190)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(54, 13)
        Me.Label5.TabIndex = 33
        Me.Label5.Text = "Alternatif5"
        '
        'TrackBar6
        '
        Me.TrackBar6.Location = New System.Drawing.Point(448, 190)
        Me.TrackBar6.Maximum = 17
        Me.TrackBar6.Minimum = 1
        Me.TrackBar6.Name = "TrackBar6"
        Me.TrackBar6.Size = New System.Drawing.Size(241, 42)
        Me.TrackBar6.TabIndex = 32
        Me.TrackBar6.Value = 9
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(695, 142)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(54, 13)
        Me.Label6.TabIndex = 31
        Me.Label6.Text = "Alternatif4"
        '
        'TrackBar7
        '
        Me.TrackBar7.Location = New System.Drawing.Point(448, 142)
        Me.TrackBar7.Maximum = 17
        Me.TrackBar7.Minimum = 1
        Me.TrackBar7.Name = "TrackBar7"
        Me.TrackBar7.Size = New System.Drawing.Size(241, 42)
        Me.TrackBar7.TabIndex = 30
        Me.TrackBar7.Value = 9
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(695, 94)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(54, 13)
        Me.Label8.TabIndex = 29
        Me.Label8.Text = "Alternatif3"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(695, 51)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(54, 13)
        Me.Label11.TabIndex = 28
        Me.Label11.Text = "Alternatif2"
        '
        'TrackBar8
        '
        Me.TrackBar8.Location = New System.Drawing.Point(448, 51)
        Me.TrackBar8.Maximum = 17
        Me.TrackBar8.Minimum = 1
        Me.TrackBar8.Name = "TrackBar8"
        Me.TrackBar8.Size = New System.Drawing.Size(241, 42)
        Me.TrackBar8.TabIndex = 27
        Me.TrackBar8.Value = 9
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(396, 51)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(54, 13)
        Me.Label12.TabIndex = 26
        Me.Label12.Text = "Alternatif1"
        '
        'TrackBar9
        '
        Me.TrackBar9.Location = New System.Drawing.Point(64, 322)
        Me.TrackBar9.Maximum = 17
        Me.TrackBar9.Minimum = 1
        Me.TrackBar9.Name = "TrackBar9"
        Me.TrackBar9.Size = New System.Drawing.Size(241, 42)
        Me.TrackBar9.TabIndex = 45
        Me.TrackBar9.Value = 9
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(15, 248)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(45, 13)
        Me.Label13.TabIndex = 44
        Me.Label13.Text = "Kriteria3"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(311, 418)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(54, 13)
        Me.Label14.TabIndex = 43
        Me.Label14.Text = "Alternatif5"
        '
        'TrackBar10
        '
        Me.TrackBar10.Location = New System.Drawing.Point(64, 418)
        Me.TrackBar10.Maximum = 17
        Me.TrackBar10.Minimum = 1
        Me.TrackBar10.Name = "TrackBar10"
        Me.TrackBar10.Size = New System.Drawing.Size(241, 42)
        Me.TrackBar10.TabIndex = 42
        Me.TrackBar10.Value = 9
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(311, 370)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(54, 13)
        Me.Label15.TabIndex = 41
        Me.Label15.Text = "Alternatif4"
        '
        'TrackBar11
        '
        Me.TrackBar11.Location = New System.Drawing.Point(64, 370)
        Me.TrackBar11.Maximum = 17
        Me.TrackBar11.Minimum = 1
        Me.TrackBar11.Name = "TrackBar11"
        Me.TrackBar11.Size = New System.Drawing.Size(241, 42)
        Me.TrackBar11.TabIndex = 40
        Me.TrackBar11.Value = 9
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(311, 322)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(54, 13)
        Me.Label16.TabIndex = 39
        Me.Label16.Text = "Alternatif3"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(311, 279)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(54, 13)
        Me.Label17.TabIndex = 38
        Me.Label17.Text = "Alternatif2"
        '
        'TrackBar12
        '
        Me.TrackBar12.Location = New System.Drawing.Point(64, 279)
        Me.TrackBar12.Maximum = 17
        Me.TrackBar12.Minimum = 1
        Me.TrackBar12.Name = "TrackBar12"
        Me.TrackBar12.Size = New System.Drawing.Size(241, 42)
        Me.TrackBar12.TabIndex = 37
        Me.TrackBar12.Value = 9
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(12, 279)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(54, 13)
        Me.Label18.TabIndex = 36
        Me.Label18.Text = "Alternatif1"
        '
        'TrackBar13
        '
        Me.TrackBar13.Location = New System.Drawing.Point(448, 322)
        Me.TrackBar13.Maximum = 17
        Me.TrackBar13.Minimum = 1
        Me.TrackBar13.Name = "TrackBar13"
        Me.TrackBar13.Size = New System.Drawing.Size(241, 42)
        Me.TrackBar13.TabIndex = 55
        Me.TrackBar13.Value = 9
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(399, 248)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(45, 13)
        Me.Label19.TabIndex = 54
        Me.Label19.Text = "Kriteria4"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(695, 418)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(54, 13)
        Me.Label20.TabIndex = 53
        Me.Label20.Text = "Alternatif5"
        '
        'TrackBar14
        '
        Me.TrackBar14.Location = New System.Drawing.Point(448, 418)
        Me.TrackBar14.Maximum = 17
        Me.TrackBar14.Minimum = 1
        Me.TrackBar14.Name = "TrackBar14"
        Me.TrackBar14.Size = New System.Drawing.Size(241, 42)
        Me.TrackBar14.TabIndex = 52
        Me.TrackBar14.Value = 9
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(695, 370)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(54, 13)
        Me.Label21.TabIndex = 51
        Me.Label21.Text = "Alternatif4"
        '
        'TrackBar15
        '
        Me.TrackBar15.Location = New System.Drawing.Point(448, 370)
        Me.TrackBar15.Maximum = 17
        Me.TrackBar15.Minimum = 1
        Me.TrackBar15.Name = "TrackBar15"
        Me.TrackBar15.Size = New System.Drawing.Size(241, 42)
        Me.TrackBar15.TabIndex = 50
        Me.TrackBar15.Value = 9
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(695, 322)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(54, 13)
        Me.Label22.TabIndex = 49
        Me.Label22.Text = "Alternatif3"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(695, 279)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(54, 13)
        Me.Label23.TabIndex = 48
        Me.Label23.Text = "Alternatif2"
        '
        'TrackBar16
        '
        Me.TrackBar16.Location = New System.Drawing.Point(448, 279)
        Me.TrackBar16.Maximum = 17
        Me.TrackBar16.Minimum = 1
        Me.TrackBar16.Name = "TrackBar16"
        Me.TrackBar16.Size = New System.Drawing.Size(241, 42)
        Me.TrackBar16.TabIndex = 47
        Me.TrackBar16.Value = 9
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(396, 279)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(54, 13)
        Me.Label24.TabIndex = 46
        Me.Label24.Text = "Alternatif1"
        '
        'TrackBar17
        '
        Me.TrackBar17.Location = New System.Drawing.Point(267, 537)
        Me.TrackBar17.Maximum = 17
        Me.TrackBar17.Minimum = 1
        Me.TrackBar17.Name = "TrackBar17"
        Me.TrackBar17.Size = New System.Drawing.Size(241, 42)
        Me.TrackBar17.TabIndex = 65
        Me.TrackBar17.Value = 9
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(218, 463)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(45, 13)
        Me.Label25.TabIndex = 64
        Me.Label25.Text = "Kriteria5"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(514, 633)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(54, 13)
        Me.Label26.TabIndex = 63
        Me.Label26.Text = "Alternatif5"
        '
        'TrackBar18
        '
        Me.TrackBar18.Location = New System.Drawing.Point(267, 633)
        Me.TrackBar18.Maximum = 17
        Me.TrackBar18.Minimum = 1
        Me.TrackBar18.Name = "TrackBar18"
        Me.TrackBar18.Size = New System.Drawing.Size(241, 42)
        Me.TrackBar18.TabIndex = 62
        Me.TrackBar18.Value = 9
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(514, 585)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(54, 13)
        Me.Label27.TabIndex = 61
        Me.Label27.Text = "Alternatif4"
        '
        'TrackBar19
        '
        Me.TrackBar19.Location = New System.Drawing.Point(267, 585)
        Me.TrackBar19.Maximum = 17
        Me.TrackBar19.Minimum = 1
        Me.TrackBar19.Name = "TrackBar19"
        Me.TrackBar19.Size = New System.Drawing.Size(241, 42)
        Me.TrackBar19.TabIndex = 60
        Me.TrackBar19.Value = 9
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(514, 537)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(54, 13)
        Me.Label28.TabIndex = 59
        Me.Label28.Text = "Alternatif3"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(514, 494)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(54, 13)
        Me.Label29.TabIndex = 58
        Me.Label29.Text = "Alternatif2"
        '
        'TrackBar20
        '
        Me.TrackBar20.Location = New System.Drawing.Point(267, 494)
        Me.TrackBar20.Maximum = 17
        Me.TrackBar20.Minimum = 1
        Me.TrackBar20.Name = "TrackBar20"
        Me.TrackBar20.Size = New System.Drawing.Size(241, 42)
        Me.TrackBar20.TabIndex = 57
        Me.TrackBar20.Value = 9
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(215, 494)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(54, 13)
        Me.Label30.TabIndex = 56
        Me.Label30.Text = "Alternatif1"
        '
        'FormPenilaianAlternatifPadaKriteria
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(866, 716)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "FormPenilaianAlternatifPadaKriteria"
        Me.Text = "FormPenilaianAlternatifPadaKriteria"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.TrackBar2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar18, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar19, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar20, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TrackBar2 As System.Windows.Forms.TrackBar
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TrackBar5 As System.Windows.Forms.TrackBar
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TrackBar1 As System.Windows.Forms.TrackBar
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TrackBar17 As System.Windows.Forms.TrackBar
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents TrackBar18 As System.Windows.Forms.TrackBar
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents TrackBar19 As System.Windows.Forms.TrackBar
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents TrackBar20 As System.Windows.Forms.TrackBar
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents TrackBar13 As System.Windows.Forms.TrackBar
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents TrackBar14 As System.Windows.Forms.TrackBar
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents TrackBar15 As System.Windows.Forms.TrackBar
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents TrackBar16 As System.Windows.Forms.TrackBar
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents TrackBar9 As System.Windows.Forms.TrackBar
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents TrackBar10 As System.Windows.Forms.TrackBar
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents TrackBar11 As System.Windows.Forms.TrackBar
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents TrackBar12 As System.Windows.Forms.TrackBar
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents TrackBar3 As System.Windows.Forms.TrackBar
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents TrackBar6 As System.Windows.Forms.TrackBar
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TrackBar7 As System.Windows.Forms.TrackBar
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents TrackBar8 As System.Windows.Forms.TrackBar
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents TrackBar4 As System.Windows.Forms.TrackBar
End Class
